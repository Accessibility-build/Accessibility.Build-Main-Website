<?php
/**
 * Plugin Name: Build with Accessibility
 * Description: Free, local accessibility monitoring, axe-core scans, manual review records, and guided content repairs. Manual testing is still required. By Accessibility.build.
 * Version: 0.5.1
 * Requires at least: 6.6
 * Requires PHP: 8.0
 * Author: Accessibility.build
 * Author URI: https://accessibility.build
 * Update URI: false
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: build-with-accessibility
 */

defined( 'ABSPATH' ) || exit;

define( 'BWA_VERSION', '0.5.1' );
define( 'BWA_AXE_VERSION', '4.14.0' );
define( 'BWA_FILE', __FILE__ );
define( 'BWA_DIR', __DIR__ );

require_once __DIR__ . '/includes/class-bwa-images.php';
require_once __DIR__ . '/includes/class-bwa-repairs.php';
require_once __DIR__ . '/includes/class-bwa-content.php';
require_once __DIR__ . '/includes/class-bwa-plugin.php';
require_once __DIR__ . '/includes/class-bwa-cache.php';
require_once __DIR__ . '/includes/class-bwa-audits.php';
require_once __DIR__ . '/includes/class-bwa-monitoring.php';
require_once __DIR__ . '/includes/class-bwa-manual.php';
require_once __DIR__ . '/includes/class-bwa-admin.php';

add_action( 'plugins_loaded', array( 'BWA_Plugin', 'init' ) );
add_action( 'plugins_loaded', array( 'BWA_Audits', 'init' ) );
add_action( 'plugins_loaded', array( 'BWA_Monitoring', 'init' ) );
add_action( 'plugins_loaded', array( 'BWA_Manual', 'init' ) );
add_action( 'plugins_loaded', array( 'BWA_Admin', 'init' ) );
register_activation_hook( __FILE__, array( 'BWA_Audits', 'install' ) );
