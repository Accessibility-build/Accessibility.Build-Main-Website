import { manualHtml, manualCsv, outcomeLabels } from "./manual-export.js";
const { useEffect, useRef, useState } = wp.element;
const { Modal } = wp.components;
const t = (text) => wp.i18n.__(text, "build-with-accessibility");
const api = (path, options = {}) => wp.apiFetch({ path: `/bwa/v1${path}`, ...options });
const date = (value) => value ? new Date(value.replace(" ", "T")).toLocaleString() : t("Not recorded");
const reasonLabels = {
  manual_changed: "Tracked page or site changes require manual review",
  manual_due: "Manual review date reached",
  manual_open: "Manual steps are untested, blocked, or have an issue",
};
function uuid() {
  return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) => (Number(c) ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (Number(c) / 4)))).toString(16));
}
function Button({ children, secondary, ...props }) { return <button type="button" className={`bwa-button${secondary ? " bwa-button--secondary" : ""}`} {...props}>{children}</button>; }
function ErrorNotice({ message }) { return message ? <p className="bwa-alert bwa-alert--error" role="alert">{message}</p> : null; }
function useResource(path, tick) {
  const [state, setState] = useState({ path: "", data: null, loading: true, error: "" });
  useEffect(() => {
    let active = true;
    setState({ path, data: null, loading: true, error: "" });
    api(path).then((data) => { if (active) setState({ path, data, loading: false, error: "" }); }).catch((error) => { if (active) setState({ path, data: null, loading: false, error: error.message }); });
    return () => { active = false; };
  }, [path, tick]);
  // A newly selected page must never render or act on the previous page's data,
  // even during the render before its fetching effect runs.
  return state.path === path ? state : { data: null, loading: true, error: "" };
}
function Pager({ page, pages, change, label }) {
  return pages > 1 ? <nav className="bwa-pagination" aria-label={label}><Button secondary disabled={page <= 1} onClick={() => change(page - 1)}>{t("Previous")}</Button><span>{t("Page")} {page} / {pages}</span><Button secondary disabled={page >= pages} onClick={() => change(page + 1)}>{t("Next")}</Button></nav> : null;
}
function SessionDetails({ session, headingLevel = 4 }) {
  const Heading = `h${headingLevel}`;
  const e = session.evidence;
  return <div className="bwa-session-evidence">
    <dl><dt>{t("Tester")}</dt><dd>{e.tester} · #{session.author}</dd><dt>{t("Recorded")}</dt><dd>{date(session.created_at)}</dd><dt>{t("Page at testing")}</dt><dd>{e.target_title}</dd><dt>{t("Browser, device and display settings")}</dt><dd>{e.browser || t("Not recorded")}</dd><dt>{t("Assistive technology")}</dt><dd>{e.assistive_technology || t("Not recorded")}</dd><dt>{t("Guide version")}</dt><dd>{e.guide.version}</dd></dl>
    <ol className="bwa-session-steps">{e.steps.map((step) => <li key={step.id}><Heading>{step.title}</Heading><p>{step.instruction}</p><p><strong>{t("Expected:")}</strong> {step.expected}</p><p><strong>{t(outcomeLabels[step.outcome])}</strong></p><p className="bwa-preserve">{step.note || t("No observation recorded.")}</p></li>)}</ol>
    {e.notes && <><Heading>{t("Session notes")}</Heading><p className="bwa-preserve">{e.notes}</p></>}
    {e.references && <><Heading>{t("Evidence references")}</Heading><p className="bwa-preserve">{e.references}</p></>}
    <p className="bwa-muted">{e.limitation}</p>
  </div>;
}

function SessionForm({ initial, guideId, previous, legacyCheck, close, saved }) {
  const [context, setContext] = useState(initial);
  const [prior, setPrior] = useState(previous);
  const [reviewKey] = useState(() => previous?.review_key || uuid());
  const guide = context.guides[guideId];
  const [scope, setScope] = useState(previous?.evidence.scope || "");
  const [browser, setBrowser] = useState("");
  const [at, setAt] = useState("");
  const [reviewDate, setReviewDate] = useState("");
  const [notes, setNotes] = useState("");
  const [references, setReferences] = useState("");
  const [steps, setSteps] = useState(() => Object.fromEntries(guide.steps.map((step) => [step.id, { outcome: "not_tested", note: "" }])));
  const [confirmed, setConfirmed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [conflict, setConflict] = useState(false);
  const [message, setMessage] = useState("");
  const pending = useRef(null);
  const hasResults = Object.values(steps).some((step) => step.outcome !== "not_tested");
  const dirty = scope !== (previous?.evidence.scope || "") || browser || at || reviewDate || notes || references || hasResults || Object.values(steps).some((step) => step.note);
  useEffect(() => {
    const protect = (event) => { if (dirty) { event.preventDefault(); event.returnValue = ""; } };
    window.addEventListener("beforeunload", protect);
    return () => window.removeEventListener("beforeunload", protect);
  }, [dirty]);
  function requestClose() { if (!busy && (!dirty || window.confirm(t("Discard this unsaved session? Saved history will remain unchanged.")))) close(); }
  async function reload() {
    setBusy(true); setError("");
    try {
      const next = await api(`/manual-sessions/${context.target.key}?review_key=${reviewKey}`);
      const latest = next.reviews.find((row) => row.review_key === reviewKey);
      setContext(next); setPrior(latest || null); setConfirmed(false); setConflict(false); pending.current = null;
      setSteps((old) => Object.fromEntries(next.guides[guideId].steps.map((step) => [step.id, { outcome: "not_tested", note: old[step.id]?.note || "" }])));
      setMessage(t("Current page context loaded. Previous observations remain as notes, but every outcome has been reset. Repeat the affected tests before recording new results."));
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function save(event) {
    event.preventDefault(); if (busy) return;
    setBusy(true); setError(""); setMessage("");
    const body = { guide: guideId, guide_version: guide.version, review_key: reviewKey, previous_id: prior?.id || 0, legacy_check: prior?.evidence.legacy_check || legacyCheck || "", scope, browser, assistive_technology: at, review_date: reviewDate, notes, references, steps, confirmed, source_hash: context.target.source_hash, environment_hash: context.environment_hash };
    const signature = JSON.stringify(body);
    if (pending.current?.signature !== signature) pending.current = { signature, key: uuid() };
    try {
      const record = await api(`/manual-sessions/${context.target.key}`, { method: "POST", data: { ...body, request_key: pending.current.key } });
      saved(record);
    } catch (e) { setError(e.message); setConflict(e.data?.status === 409); }
    finally { setBusy(false); }
  }
  return <Modal title={prior ? t("Repeat manual testing") : t("New manual testing session")} className="bwa-admin bwa-session-modal" onRequestClose={requestClose} shouldCloseOnClickOutside={false}>
    <form onSubmit={save} className="bwa-session-form">
      <h2>{guide.title}</h2><p><strong>{context.target.title}</strong></p>
      <p>{t("Work through the steps yourself. Save untested steps to create a review task, or record only what you actually observed. Each save adds a new history entry.")}</p>
      <p className="bwa-scope-note">{t("Freshness tracks this primary page and known site settings. Other pages, remote content and later interaction states need separate review. This guide is a starting point, not a complete audit.")}</p>
      <ErrorNotice message={error} />{message && <p role="status" className="bwa-alert">{message}</p>}
      {conflict && <Button secondary disabled={busy} onClick={reload}>{t("Reload context for retesting")}</Button>}
      <fieldset disabled={busy}>
        <legend className="screen-reader-text">{t("Testing context and observations")}</legend>
        <label htmlFor="bwa-session-scope">{t("Page state or task to test")}</label><input id="bwa-session-scope" required maxLength={300} value={scope} readOnly={!!prior} onChange={(e) => setScope(e.target.value)} aria-describedby="bwa-session-scope-help" />
        <p id="bwa-session-scope-help" className="bwa-muted">{t("For example: Contact form with validation errors, signed out, on staging. Create a separate review for a different state or task.")}</p>
        <div className="bwa-session-context-grid">
          <div><label htmlFor="bwa-session-browser">{t("Browser, device and display settings")}</label><input id="bwa-session-browser" maxLength={300} required={hasResults} value={browser} onChange={(e) => setBrowser(e.target.value)} /><p className="bwa-muted">{t("Include browser version, operating system, viewport and zoom where relevant.")}</p></div>
          <div><label htmlFor="bwa-session-at">{t("Assistive technology")}</label><input id="bwa-session-at" maxLength={300} required={hasResults} value={at} onChange={(e) => setAt(e.target.value)} /><p className="bwa-muted">{t("Record the name and version, or enter None if none was used.")}</p></div>
        </div>
        <ol className="bwa-session-steps">{guide.steps.map((step) => <li key={step.id}><h3>{step.title}</h3><p>{step.instruction}</p><p><strong>{t("Expected:")}</strong> {step.expected}</p>
          <label htmlFor={`bwa-step-${step.id}`}>{t("Outcome")} · {step.title}</label><select id={`bwa-step-${step.id}`} value={steps[step.id].outcome} onChange={(e) => { setConfirmed(false); setSteps((old) => ({ ...old, [step.id]: { ...old[step.id], outcome: e.target.value } })); }}>{Object.entries(outcomeLabels).map(([value, label]) => <option key={value} value={value}>{t(label)}</option>)}</select>
          <label htmlFor={`bwa-observation-${step.id}`}>{t("Observation or reason")} · {step.title}</label><textarea id={`bwa-observation-${step.id}`} rows={3} maxLength={2000} required={steps[step.id].outcome !== "not_tested"} value={steps[step.id].note} onChange={(e) => setSteps((old) => ({ ...old, [step.id]: { ...old[step.id], note: e.target.value } }))} />
        </li>)}</ol>
        <label htmlFor="bwa-session-notes">{t("Session notes and remaining work")}</label><textarea id="bwa-session-notes" rows={3} maxLength={3000} value={notes} onChange={(e) => setNotes(e.target.value)} />
        <label htmlFor="bwa-session-references">{t("Evidence references (optional)")}</label><textarea id="bwa-session-references" rows={2} maxLength={2000} value={references} onChange={(e) => setReferences(e.target.value)} /><p className="bwa-muted">{t("Reference a private test document or recording. References are stored as text; no files are uploaded or fetched. Do not include passwords or personal customer data.")}</p>
        <label htmlFor="bwa-session-review-date">{t("Next review date (optional)")}</label><input id="bwa-session-review-date" type="date" value={reviewDate} onChange={(e) => setReviewDate(e.target.value)} /><p className="bwa-muted">{t("Due from the start of this date in the site's current timezone:")} {context.timezone}. {t("Review tasks are checked when the workspace is opened or refreshed. No email or background reminders are sent.")}</p>
        {hasResults && <label className="bwa-session-confirm"><input type="checkbox" required checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} /> {t("These outcomes describe my human observations in the recorded context. They do not certify the page or website.")}</label>}
      </fieldset>
      <div className="bwa-inline"><Button type="submit" disabled={busy || conflict}>{busy ? t("Saving…") : t("Save session")}</Button><Button secondary disabled={busy} onClick={requestClose}>{t("Cancel")}</Button></div>
    </form>
  </Modal>;
}

function download(name, content, type) {
  const url = URL.createObjectURL(new Blob([content], { type })); const anchor = document.createElement("a");
  anchor.href = url; anchor.download = name; document.body.appendChild(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function ManualExports({ targetKey, disabled = false }) {
  const [busy, setBusy] = useState(false); const [error, setError] = useState(""); const [message, setMessage] = useState("");
  async function exportHistory(format) {
    if (busy) return; setBusy(true); setError(""); setMessage("");
    try {
      let data = await api(`/manual-sessions/${targetKey}/export`);
      const result = { ...data, sessions: [...data.sessions] };
      while (data.next_after !== null) {
        data = await api(`/manual-sessions/${targetKey}/export?through=${result.through}&after=${data.next_after}`);
        if (data.target.source_hash !== result.target.source_hash || data.environment_hash !== result.environment_hash || data.today !== result.today || data.timezone !== result.timezone || data.total !== result.total) throw new Error(t("The page, site context or review date changed during export. Try again to get a consistent report."));
        result.sessions.push(...data.sessions);
      }
      if (result.sessions.length !== result.total) throw new Error(t("The complete history could not be exported. Refresh and try again."));
      delete result.next_after;
      const latest = new Map(result.sessions.map((row) => [row.review_key, row.id]));
      result.sessions = result.sessions.map((row) => ({ ...row, latest_in_export: latest.get(row.review_key) === row.id }));
      const name = `accessibility-manual-${targetKey}.${format}`;
      if (format === "html") download(name, manualHtml(result, document.documentElement.lang), "text/html;charset=utf-8");
      else if (format === "csv") download(name, manualCsv(result), "text/csv;charset=utf-8");
      else download(name, JSON.stringify(result, null, 2), "application/json");
      setMessage(t("Manual testing history exported. It includes the saved sessions and earlier notes for this page, with their scope and limitations."));
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  return <div className="bwa-manual-exports bwa-no-print"><div className="bwa-inline">{["html", "json", "csv"].map((format) => <Button secondary key={format} disabled={busy || disabled} onClick={() => exportHistory(format)}>{t("Export manual")} {format.toUpperCase()}</Button>)}</div>{busy && <p role="status">{t("Collecting complete manual history…")}</p>}<ErrorNotice message={error} />{message && <p role="status">{message}</p>}</div>;
}

export function ManualSessions({ targetKey, setTargetKey, tick, changed }) {
  const [search, setSearch] = useState(""); const [historyPage, setHistoryPage] = useState(1); const [reviewPage, setReviewPage] = useState(1);
  const [form, setForm] = useState(null); const [message, setMessage] = useState(""); const heading = useRef(null);
  const pages = useResource(`/targets?per_page=100&search=${encodeURIComponent(search)}`, tick);
  const { data, loading, error } = useResource(`/manual-sessions/${targetKey}?page=${historyPage}&review_page=${reviewPage}`, tick);
  useEffect(() => { setHistoryPage(1); setReviewPage(1); setMessage(""); }, [targetKey]);
  useEffect(() => { if (data && data.target.key !== targetKey) setTargetKey(data.target.key); }, [data, targetKey]);
  function start(guideId, previous = null, legacyCheck = "") { setForm({ guideId, previous, legacyCheck, initial: data }); setMessage(""); }
  function saved(record) { setForm(null); setHistoryPage(1); setReviewPage(1); setMessage(`${t("Session saved as history entry")} #${record.id}. ${t("Only a person can complete manual-review tasks.")}`); changed(); wp.a11y.speak(t("Manual testing session saved. Earlier history is preserved.")); requestAnimationFrame(() => heading.current?.focus()); }
  return <>
    <div className="bwa-toolbar">
      <label>{t("Find a page to review")}<input type="search" value={search} onChange={(e) => setSearch(e.target.value)} /></label>
      <label>{t("Page")}<select value={targetKey} onChange={(e) => setTargetKey(e.target.value)}><option value={targetKey}>{data?.target.title || t("Selected page")}</option>{pages.data?.items.filter((item) => item.key !== targetKey).map((item) => <option key={item.key} value={item.key}>{item.title}</option>)}</select></label>
      {data && <a className="bwa-button bwa-button--secondary" href={data.target.url} target="_blank" rel="noopener noreferrer">{t("Open page for review")} ↗</a>}
    </div>
    <p className="bwa-section-description">{t("Plan and record human testing, repeat reviews after changes, and keep earlier observations. These eight guides are a starting point, not a complete WCAG audit. A completed scan cannot complete a manual test.")}</p>
    {pages.data?.pages > 1 && <p className="bwa-muted">{t("Showing the first 100 page matches. Narrow your search or open Manual review from the Pages table.")}</p>}
    <ErrorNotice message={error || pages.error} />
    <h2 ref={heading} tabIndex="-1">{t("Reviews for this page")}</h2>{message && <p role="status" className="bwa-alert">{message}</p>}
    {loading && <p role="status">{t("Loading manual testing history…")}</p>}
    {data && <>
      <p>{t("Reviews needing attention:")} <strong>{data.tasks.count}</strong> · {t("Saved sessions:")} <strong>{data.total}</strong> · {t("Review dates use:")} {data.timezone}</p>
      <p className="bwa-scope-note">{t("Only reviews you create and earlier recorded notes appear as manual tasks. An empty list does not mean all manual tests have been performed. Review dates and tracked changes are evaluated when you open or refresh the workspace.")}</p>
      {!!data.reviews.length && <div className="bwa-review-list">{data.reviews.map((session) => <article className="bwa-surface bwa-manual-review" key={session.id}><h3>{session.evidence.guide.title} · {session.evidence.scope}</h3><p><strong>{t(outcomeLabels[session.outcome])}</strong> · {date(session.created_at)}</p><p>{t("Next review:")} {session.review_date || t("Not scheduled")}</p>{session.reasons.length ? <ul>{session.reasons.map((reason) => <li key={reason}>{t(reasonLabels[reason])}</li>)}</ul> : <p>{t("No pending task for this recorded review. Other tests and untracked changes still need attention.")}</p>}<Button secondary onClick={() => start(session.guide, session)}>{t("Repeat this review")}</Button><details><summary>{t("Inspect latest session")}</summary><SessionDetails session={session} /></details></article>)}</div>}
      {!data.reviews.length && <p>{t("No guided reviews yet. Choose a guide below and describe the page state or task you want to check.")}</p>}
      <Pager page={data.review_page} pages={data.review_pages} change={setReviewPage} label={t("Guided review pages")} />
      <h2>{t("Start a guided review")}</h2><div className="bwa-manual-grid">{Object.values(data.guides).map((guide) => <section className="bwa-surface bwa-manual-check" key={guide.id}><h3>{guide.title}</h3><p>{guide.steps.map((step) => step.title).join(" · ")}</p><Button secondary onClick={() => start(guide.id)} aria-label={`${t("Start review:")} ${guide.title}`}>{t("Start session")}</Button></section>)}</div>
      <section className="bwa-manual-history" aria-labelledby="bwa-manual-history-title"><h2 id="bwa-manual-history-title">{t("Session history")}</h2><p>{t("Saved sessions are preserved. Repeating a review adds a new entry; it never overwrites the earlier observations. History is independent of scan retention.")}</p>
        <ManualExports key={targetKey} targetKey={targetKey} disabled={!data.total && !Object.keys(data.legacy).length} />
        {data.items.length ? <ol className="bwa-session-history-list">{data.items.map((session) => <li key={session.id}><details><summary>#{session.id} · {session.evidence.guide.title} · {session.evidence.scope} · {date(session.created_at)}</summary><p>{t(outcomeLabels[session.outcome])} · {t("Recorded next review:")} {session.review_date || t("Not scheduled")}</p><p>{session.fresh ? t("Matches the currently tracked page/site state; this is not an accessibility approval.") : t("Tracked page/site state changed after this session.")}</p><SessionDetails session={session} headingLevel={3} /></details></li>)}</ol> : <p>{t("No saved sessions for this page.")}</p>}
        <Pager page={data.page} pages={data.pages} change={setHistoryPage} label={t("Manual session history pages")} />
      </section>
      {!!Object.keys(data.legacy).length && <section className="bwa-surface"><h2>{t("Earlier review notes")}</h2><p>{t("These notes are preserved from the earlier checklist. Their exact steps and testing environment were not structured fields. Start a guided session to follow up a note; its original text remains here and in exports.")}</p>{Object.entries(data.legacy).map(([check, record]) => <div className="bwa-report-node" key={check}><h3>{data.guides[check]?.title || check}</h3><p>{record.state.replaceAll("_", " ")} · {date(record.updated_at)}</p><p className="bwa-preserve">{record.note}</p>{data.guides[check] && <Button secondary onClick={() => start(check, null, check)}>{t("Follow up this earlier note")}</Button>}</div>)}</section>}
    </>}
    {form && <SessionForm {...form} close={() => setForm(null)} saved={saved} />}
  </>;
}
