<?php
return array( 'dependencies' => array( 'wp-api-fetch', 'wp-components', 'wp-element', 'wp-i18n', 'wp-a11y' ), 'version' => 'b61ff0f8916b' );
