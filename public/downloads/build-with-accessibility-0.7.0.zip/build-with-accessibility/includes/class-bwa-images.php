<?php
/** Native core/image source handling. No changes to attachment-wide alternative text. */
defined( 'ABSPATH' ) || exit;

final class BWA_Images {
    public static function hash( string $content ): string {
        return hash( 'sha256', trim( $content ) );
    }

    /** Match the editor's indexes: whitespace between named blocks is not an editor block. */
    private static function indexes( array $blocks ): array {
        return array_keys( array_filter( $blocks, static function ( $block ) {
            return null !== $block['blockName'] || '' !== trim( $block['innerHTML'] );
        } ) );
    }

    public static function valid_path( $path ): bool {
        return is_array( $path ) && count( $path ) > 0 && count( $path ) <= 20
            && array_keys( $path ) === range( 0, count( $path ) - 1 ) && count( array_filter( $path, static fn( $i ) => is_int( $i ) && $i >= 0 && $i <= 10000 ) ) === count( $path );
    }

    public static function at( array $blocks, array $path ): ?array {
        $index = array_shift( $path );
        $indexes = self::indexes( $blocks );
        if ( ! isset( $indexes[ $index ] ) ) {
            return null;
        }
        $block = $blocks[ $indexes[ $index ] ];
        // A shared or dynamic entity is not owned by this post's source.
        if ( in_array( $block['blockName'], array( 'core/block', 'core/template-part', 'core/query', 'core/post-template', 'core/navigation' ), true ) || str_starts_with( (string) $block['blockName'], 'woocommerce/' ) ) {
            return null;
        }
        return empty( $path ) ? $block : self::at( $block['innerBlocks'], $path );
    }

    public static function replace( array $blocks, array $path, array $replacement ): array {
        $index = array_shift( $path );
        $indexes = self::indexes( $blocks );
        if ( ! isset( $indexes[ $index ] ) ) {
            return $blocks;
        }
        $key = $indexes[ $index ];
        if ( empty( $path ) ) {
            $blocks[ $key ] = $replacement;
        } else {
            $blocks[ $key ]['innerBlocks'] = self::replace( $blocks[ $key ]['innerBlocks'], $path, $replacement );
        }
        return $blocks;
    }

    public static function image( ?array $block ) {
        if ( ! $block || 'core/image' !== $block['blockName'] || ! empty( $block['innerBlocks'] ) || ! empty( $block['attrs']['metadata']['bindings'] ) ) {
            return new WP_Error( 'bwa_unsupported', __( 'This repair supports native Image blocks in this post’s static content. Images in shared patterns, templates, or Query Loops need manual review in this alpha.', 'build-with-accessibility' ), array( 'status' => 422 ) );
        }
        $html = new WP_HTML_Tag_Processor( $block['innerHTML'] );
        $image = null;
        $inside_link = false;
        while ( $html->next_tag( array( 'tag_closers' => 'visit' ) ) ) {
            if ( 'A' === $html->get_tag() ) {
                $inside_link = ! $html->is_tag_closer();
            }
            if ( 'IMG' !== $html->get_tag() ) {
                continue;
            }
            if ( null !== $image ) {
                return new WP_Error( 'bwa_ambiguous', __( 'This block contains more than one image. Edit it manually.', 'build-with-accessibility' ), array( 'status' => 422 ) );
            }
            $image = array(
                'alt' => $html->get_attribute( 'alt' ),
                'src' => $html->get_attribute( 'src' ),
                'linked' => $inside_link || ! empty( $block['attrs']['lightbox']['enabled'] ),
                'overridden' => null !== $html->get_attribute( 'aria-label' ) || null !== $html->get_attribute( 'aria-labelledby' ) || ( null !== $html->get_attribute( 'role' ) && ! ( ! empty( $block['attrs']['isDecorative'] ) && 'none' === $html->get_attribute( 'role' ) ) ) || null !== $html->get_attribute( 'aria-hidden' ),
            );
        }
        return $image ?? new WP_Error( 'bwa_no_image', __( 'The saved Image block does not contain an image.', 'build-with-accessibility' ), array( 'status' => 422 ) );
    }

    /** Only alt and the native decorative flag/role may change; preserve other markup and siblings. */
    public static function validate_change( string $before_content, string $after_content, array $path, string $purpose ) {
        $before = self::at( parse_blocks( $before_content ), $path );
        $after = self::at( parse_blocks( $after_content ), $path );
        $old = self::image( $before );
        $new = self::image( $after );
        if ( is_wp_error( $old ) || is_wp_error( $new ) ) {
            return is_wp_error( $old ) ? $old : $new;
        }
        if ( $old['overridden'] || $new['overridden'] ) {
            return new WP_Error( 'bwa_override', __( 'This image has custom accessibility attributes. Review those manually before using this repair.', 'build-with-accessibility' ), array( 'status' => 422 ) );
        }
        if ( ! is_string( $new['alt'] ) || strlen( $new['alt'] ) > 4000 || ! in_array( $purpose, array( 'informative', 'decorative' ), true ) ) {
            return new WP_Error( 'bwa_alt', __( 'Choose the image purpose and provide valid alternative text.', 'build-with-accessibility' ), array( 'status' => 422 ) );
        }
        if ( ( 'informative' === $purpose && ( '' === trim( $new['alt'] ) || ! empty( $after['attrs']['isDecorative'] ) ) ) || ( 'decorative' === $purpose && ( '' !== $new['alt'] || $old['linked'] ) ) ) {
            return new WP_Error( 'bwa_purpose', __( 'Informative images need a description. Linked or lightbox images cannot be marked decorative with this repair.', 'build-with-accessibility' ), array( 'status' => 422 ) );
        }
        // Compare parsed tokens so native attribute order/spacing does not look
        // like an unrelated edit. All text and non-repair attributes still match.
        $normalized = array( self::signature( $before['innerHTML'] ), self::signature( $after['innerHTML'] ) );
        $before_attrs = $before['attrs'];
        $after_attrs = $after['attrs'];
        unset( $before_attrs['isDecorative'], $after_attrs['isDecorative'] );
        if ( null === $normalized[0] || null === $normalized[1] || $normalized[0] !== $normalized[1] || $before_attrs !== $after_attrs ) {
            return new WP_Error( 'bwa_scope', __( 'The proposed change affects more than the image alternative. Save other changes first, then review the image again.', 'build-with-accessibility' ), array( 'status' => 409 ) );
        }
        $expected = serialize_blocks( self::replace( parse_blocks( $before_content ), $path, $after ) );
        if ( self::hash( $expected ) !== self::hash( $after_content ) ) {
            return new WP_Error( 'bwa_scope', __( 'Other content changed during this repair. Save your work and try again.', 'build-with-accessibility' ), array( 'status' => 409 ) );
        }
        return array( 'before' => serialize_block( $before ), 'after' => serialize_block( $after ), 'alt' => $new['alt'] );
    }

    private static function signature( string $html ): ?array {
        $p = new WP_HTML_Tag_Processor( $html );
        $tokens = array();
        while ( $p->next_token() ) {
            $attributes = array();
            foreach ( $p->get_attribute_names_with_prefix( '' ) ?? array() as $name ) {
                if ( 'IMG' === $p->get_tag() && in_array( $name, array( 'alt', 'role' ), true ) ) {
                    continue;
                }
                $attributes[ $name ] = $p->get_attribute( $name );
            }
            ksort( $attributes );
            $tokens[] = array( $p->get_token_type(), $p->get_token_name(), $p->is_tag_closer(), $p->has_self_closing_flag(), $attributes, $p->get_modifiable_text() );
        }
        return $p->paused_at_incomplete_token() ? null : $tokens;
    }

    public static function is_current( WP_Post $post, array $record ): bool {
        if ( BWA_Compatibility::owner( $post->ID ) ) { return false; }
        $block = self::at( parse_blocks( $post->post_content ), $record['path'] );
        return $block && self::hash( serialize_block( $block ) ) === self::hash( $record['after'] );
    }

    public static function mark( string $content, array $record, string $marker ): string {
        $blocks = parse_blocks( $content );
        $block = self::at( $blocks, $record['path'] );
        if ( ! $block || self::hash( serialize_block( $block ) ) !== self::hash( $record['after'] ) ) {
            return $content;
        }
        $p = new WP_HTML_Tag_Processor( $block['innerHTML'] );
        if ( ! $p->next_tag( 'IMG' ) ) {
            return $content;
        }
        $p->set_attribute( 'data-bwa-image', $marker );
        $block['innerHTML'] = $p->get_updated_html();
        $block['innerContent'] = array( $block['innerHTML'] );
        return serialize_blocks( self::replace( $blocks, $record['path'], $block ) );
    }
}
