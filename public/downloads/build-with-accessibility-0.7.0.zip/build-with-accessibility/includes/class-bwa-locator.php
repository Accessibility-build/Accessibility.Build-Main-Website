<?php
/** Private, read-only element inspection; no content writes or accessibility decisions. */
defined( 'ABSPATH' ) || exit;

final class BWA_Locator {
    public static function init(): void {
        add_action( 'template_redirect', array( __CLASS__, 'diagnostic' ), 0 );
        add_action( 'rest_api_init', static function () {
            register_rest_route( 'bwa/v1', '/issues/(?P<id>\d+)/locate', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'start' ), 'permission_callback' => array( 'BWA_Audits', 'permission' ) ) );
            register_rest_route( 'bwa/v1', '/locate-runs/(?P<token>[a-f0-9-]{36})/source', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'source' ), 'permission_callback' => array( 'BWA_Audits', 'permission' ) ) );
        } );
    }

    public static function start( WP_REST_Request $request ) {
        $issue = BWA_Audits::inspection_issue( (int) $request['id'] );
        if ( is_wp_error( $issue ) ) { return $issue; }
        $token = wp_generate_uuid4();
        set_transient( 'bwa_locate_' . $token, array( 'actor' => get_current_user_id(), 'id' => (int) $issue['id'], 'scan_id' => $issue['scan_id'] ), 5 * MINUTE_IN_SECONDS );
        return array(
            'token' => $token,
            'url' => add_query_arg( array( 'bwa_locate' => $token, '_bwa_locate_nonce' => wp_create_nonce( 'bwa_locate_' . $token ) ), $issue['target']['url'] ),
            'width' => 'mobile' === $issue['viewport'] ? 390 : 1366,
            'height' => 'mobile' === $issue['viewport'] ? 844 : 900,
        );
    }

    private static function ticket( string $token ) {
        $ticket = get_transient( 'bwa_locate_' . $token );
        if ( ! is_array( $ticket ) || $ticket['actor'] !== get_current_user_id() ) {
            return new WP_Error( 'bwa_locate', __( 'This inspection expired. Locate the element again.', 'build-with-accessibility' ), array( 'status' => 409 ) );
        }
        $issue = BWA_Audits::inspection_issue( $ticket['id'] );
        if ( is_wp_error( $issue ) ) { return $issue; }
        if ( $issue['scan_id'] !== $ticket['scan_id'] ) {
            return new WP_Error( 'bwa_locate', __( 'A newer scan is available. Open its finding before locating the element.', 'build-with-accessibility' ), array( 'status' => 409 ) );
        }
        return $issue;
    }

    /** DOM context is a clue. Editor links additionally require an existing editable source. */
    public static function source( WP_REST_Request $request ) {
        $issue = self::ticket( (string) $request['token'] );
        if ( is_wp_error( $issue ) ) { return $issue; }
        $kind = $request->get_param( 'kind' );
        if ( ! in_array( $kind, array( 'gutenberg', 'elementor', 'woocommerce', 'cf7', 'wpforms', 'unknown' ), true ) ) {
            return new WP_Error( 'bwa_locate', __( 'Choose a supported repair guide.', 'build-with-accessibility' ), array( 'status' => 422 ) );
        }
        $id = absint( $request->get_param( 'document_id' ) );
        $target = $issue['target'];
        $url = ''; $label = ''; $verified = false;
        if ( $id && get_post( $id ) ) {
            $type = get_post_type( $id );
            if ( 'cf7' === $kind && 'wpcf7_contact_form' === $type && current_user_can( 'wpcf7_edit_contact_form', $id ) ) {
                $url = add_query_arg( array( 'page' => 'wpcf7', 'post' => $id, 'action' => 'edit' ), admin_url( 'admin.php' ) );
                $label = __( 'Open Contact Form 7 editor', 'build-with-accessibility' ); $verified = true;
            } elseif ( 'wpforms' === $kind && 'wpforms' === $type && function_exists( 'wpforms_current_user_can' ) && wpforms_current_user_can( 'edit_forms', $id ) ) {
                $url = add_query_arg( array( 'page' => 'wpforms-builder', 'view' => 'fields', 'form_id' => $id ), admin_url( 'admin.php' ) );
                $label = __( 'Open WPForms editor', 'build-with-accessibility' ); $verified = true;
            } elseif ( 'elementor' === $kind && current_user_can( 'edit_post', $id ) && 'Elementor' === BWA_Compatibility::owner( $id ) ) {
                $url = add_query_arg( array( 'post' => $id, 'action' => 'elementor' ), admin_url( 'post.php' ) );
                $label = __( 'Open Elementor editor', 'build-with-accessibility' ); $verified = true;
            }
        }
        if ( in_array( $kind, array( 'gutenberg', 'woocommerce', 'unknown' ), true ) && $target['edit_url'] ) {
            $url = $target['edit_url']; $label = 'product' === $target['type'] ? __( 'Open product editor', 'build-with-accessibility' ) : __( 'Open page editor', 'build-with-accessibility' );
        }
        return array( 'kind' => $kind, 'edit_url' => $url, 'edit_label' => $label, 'verified_document' => $verified );
    }

    public static function diagnostic(): void {
        if ( ! BWA_Audits::permission() || ! is_string( $_GET['bwa_locate'] ?? null ) || ! is_string( $_GET['_bwa_locate_nonce'] ?? null ) ) { return; }
        $token = sanitize_text_field( wp_unslash( $_GET['bwa_locate'] ) );
        if ( ! preg_match( '/^[a-f0-9-]{36}$/', $token ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwa_locate_nonce'] ) ), 'bwa_locate_' . $token ) ) { return; }
        $issue = self::ticket( $token );
        BWA_Compatibility::diagnostic();
        $config = array( 'token' => $token );
        if ( is_wp_error( $issue ) ) {
            $config['error'] = $issue->get_error_message();
        } else {
            $target = $issue['target'];
            if ( 'home' === $target['key'] ? ! is_front_page() : get_queried_object_id() !== $target['id'] ) { return; }
            if ( function_exists( 'is_checkout' ) && is_checkout() && function_exists( 'WC' ) && WC()->cart && WC()->cart->is_empty() ) {
                $config['error'] = __( 'Checkout has an empty cart in this browser. Prepare a cart on your staging store, then scan and locate again.', 'build-with-accessibility' );
                add_filter( 'woocommerce_checkout_redirect_empty_cart', '__return_false' );
            }
            BWA_Audits::mark_diagnostic_content( $target );
            $config['target'] = $issue['details']['target'];
            $config['html'] = $issue['details']['html'];
            $config['settle_ms'] = BWA_Audits::settings()['settle_ms'];
            $config['post_id'] = $target['id'];
            $config['product'] = 'product' === $target['type'];
        }
        add_action( 'wp_enqueue_scripts', static function () use ( $config ) {
            wp_enqueue_script( 'bwa-locate', plugins_url( 'assets/locate.js', BWA_FILE ), array( 'wp-i18n' ), BWA_VERSION, true );
            wp_add_inline_script( 'bwa-locate', 'window.bwaLocate=' . wp_json_encode( $config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ';', 'before' );
        } );
    }
}
