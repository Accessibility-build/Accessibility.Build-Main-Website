<?php
/** Track published builder sources and keep private diagnostics out of optimizers. */
defined( 'ABSPATH' ) || exit;

final class BWA_Compatibility {
    private const SOURCE_KEYS = array( '_elementor_edit_mode', '_elementor_data', '_elementor_page_settings', '_fl_builder_enabled', '_fl_builder_data', '_fl_builder_data_settings', 'panels_data', 'brizy_enabled', 'brizy', 'brizy-compiled-sections', '_wp_page_template', '_thumbnail_id' );
    private const SHARED_TYPES = array( 'elementor_library', 'fl-builder-template', 'editor-template', 'brizy-global-block', 'wpcf7_contact_form', 'wpforms' );
    private const FORM_KEYS = array( '_form', '_messages', '_additional_settings', '_locale', '_hash' );
    private const PRODUCT_KEYS = array( '_price', '_regular_price', '_sale_price', '_sale_price_dates_from', '_sale_price_dates_to', '_stock', '_stock_status', '_manage_stock', '_backorders', '_sold_individually', '_virtual', '_downloadable', '_product_attributes', '_default_attributes', '_product_image_gallery', '_thumbnail_id', '_sku', '_tax_status', '_tax_class', '_weight', '_length', '_width', '_height', '_purchase_note', '_button_text', '_product_url' );
    private const STORE_OPTIONS = array( 'woocommerce_cart_page_id', 'woocommerce_checkout_page_id', 'woocommerce_myaccount_page_id', 'woocommerce_shop_page_id', 'woocommerce_terms_page_id', 'woocommerce_enable_guest_checkout', 'woocommerce_enable_checkout_login_reminder', 'woocommerce_enable_signup_and_login_from_checkout', 'woocommerce_checkout_phone_field', 'woocommerce_checkout_company_field', 'woocommerce_checkout_address_2_field', 'woocommerce_checkout_privacy_policy_text', 'woocommerce_registration_privacy_policy_text', 'woocommerce_currency', 'woocommerce_currency_pos', 'woocommerce_price_num_decimals', 'woocommerce_price_decimal_sep', 'woocommerce_price_thousand_sep', 'woocommerce_calc_taxes', 'woocommerce_prices_include_tax', 'woocommerce_tax_display_shop', 'woocommerce_tax_display_cart', 'woocommerce_store_address', 'woocommerce_store_address_2', 'woocommerce_store_city', 'woocommerce_store_postcode', 'wp_page_for_privacy_policy', 'woocommerce_default_country', 'woocommerce_default_customer_address', 'woocommerce_allowed_countries', 'woocommerce_specific_allowed_countries', 'woocommerce_ship_to_countries', 'woocommerce_specific_ship_to_countries', 'woocommerce_shipping_cost_requires_address', 'woocommerce_shipping_hide_rates_when_free', 'woocommerce_ship_to_destination', 'woocommerce_cod_settings', 'woocommerce_bacs_settings', 'woocommerce_cheque_settings' );

    public static function init(): void {
        // Autoptimize decides whether to buffer before template_redirect. Opt out
        // early only for a nonce-protected editor/admin preview. The full ticket,
        // actor, source and queried-page guards still run before loading scripts.
        add_filter( 'autoptimize_filter_noptimize', static function ( $skip ) { return $skip || self::private_preview(); } );
        foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
            add_action( $hook, array( __CLASS__, 'changed_meta' ), 10, 3 );
        }
        add_action( 'save_post', array( __CLASS__, 'changed_shared' ) );
        add_action( 'before_delete_post', array( __CLASS__, 'changed_shared' ) );
        foreach ( array( 'added_option', 'updated_option', 'deleted_option' ) as $hook ) {
            add_action( $hook, static function ( $option ) {
                if ( in_array( $option, array( 'elementor_active_kit', 'elementor_css_print_method', 'siteorigin_panels_settings', 'wpforms_settings', 'wpcf7' ), true ) ) { self::changed_environment(); }
                if ( in_array( $option, self::STORE_OPTIONS, true ) || preg_match( '/^woocommerce_(?:flat_rate|free_shipping|local_pickup)_\d+_settings$/D', $option ) ) { self::changed_catalog(); }
            } );
        }
        foreach ( array( 'woocommerce_shipping_zone_method_added', 'woocommerce_shipping_zone_method_deleted', 'woocommerce_shipping_zone_method_status_toggled', 'woocommerce_shipping_zone_saved', 'woocommerce_shipping_zone_deleted', 'woocommerce_tax_rate_added', 'woocommerce_tax_rate_updated', 'woocommerce_tax_rate_deleted' ) as $hook ) { add_action( $hook, array( __CLASS__, 'changed_catalog' ) ); }
        add_action( 'set_object_terms', static function ( $object_id, $terms, $tt_ids, $taxonomy ) {
            if ( in_array( get_post_type( $object_id ), array( 'product', 'product_variation' ), true ) && ( in_array( $taxonomy, array( 'product_type', 'product_cat', 'product_tag', 'product_visibility', 'product_shipping_class' ), true ) || str_starts_with( $taxonomy, 'pa_' ) ) ) { self::changed_catalog(); }
        }, 10, 4 );
    }

    /** Only published source fields: draft layouts, generated CSS and repair receipts are excluded. */
    public static function source( int $post_id ): array {
        $values = array();
        foreach ( self::SOURCE_KEYS as $key ) {
            if ( metadata_exists( 'post', $post_id, $key ) ) { $values[ $key ] = get_post_meta( $post_id, $key, true ); }
        }
        if ( in_array( get_post_type( $post_id ), array( 'product', 'product_variation' ), true ) ) {
            foreach ( self::PRODUCT_KEYS as $key ) { if ( metadata_exists( 'post', $post_id, $key ) ) { $values[ $key ] = get_post_meta( $post_id, $key, true ); } }
        }
        // No customer, order, submission or payment-token data enters a fingerprint.
        if ( self::commerce_page( $post_id, $values ) ) { $values['bwa_catalog_revision'] = get_option( 'bwa_catalog_revision', '' ); }
        return $values;
    }

    public static function changed_meta( $meta_id, int $post_id, string $key ): void {
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) { return; }
        $type = get_post_type( $post_id );
        if ( 'wpcf7_contact_form' === $type && in_array( $key, self::FORM_KEYS, true ) ) { self::changed_environment(); }
        if ( in_array( $type, array( 'product', 'product_variation' ), true ) && in_array( $key, self::PRODUCT_KEYS, true ) ) { self::changed_catalog(); }
        if ( ! in_array( $key, self::SOURCE_KEYS, true ) ) { return; }
        BWA_Audits::changed_home_content( $post_id );
        self::changed_shared( $post_id );
    }

    public static function changed_shared( int $post_id ): void {
        if ( in_array( get_post_type( $post_id ), self::SHARED_TYPES, true ) && 'auto-draft' !== get_post_status( $post_id ) ) { self::changed_environment(); }
        if ( in_array( get_post_type( $post_id ), array( 'product', 'product_variation', 'shop_coupon' ), true ) && 'auto-draft' !== get_post_status( $post_id ) ) { self::changed_catalog(); }
        if ( class_exists( 'WooCommerce', false ) && in_array( $post_id, array( (int) get_option( 'woocommerce_terms_page_id' ), (int) get_option( 'wp_page_for_privacy_policy' ) ), true ) ) { self::changed_catalog(); }
    }

    public static function changed_catalog(): void {
        update_option( 'bwa_catalog_revision', wp_generate_uuid4(), false );
        // Prevent an inbox assembled across a catalog edit from mixing revisions.
        update_option( 'bwa_home_content_revision', wp_generate_uuid4(), false );
    }

    private static function commerce_page( int $post_id, array $source ): bool {
        if ( ! class_exists( 'WooCommerce', false ) ) { return false; }
        if ( in_array( get_post_type( $post_id ), array( 'product', 'product_variation' ), true ) ) { return true; }
        foreach ( array( 'cart', 'checkout', 'myaccount', 'shop' ) as $page ) { if ( $post_id === (int) get_option( 'woocommerce_' . $page . '_page_id' ) ) { return true; } }
        $content = (string) get_post_field( 'post_content', $post_id ) . wp_json_encode( $source );
        return (bool) preg_match( '~woocommerce(?:/|\\\\/)\w|\[(?:woocommerce_\w+|products?|product_page|product_category|product_categories|add_to_cart|add_to_cart_url)(?:\s|\])~', $content );
    }

    /** Context guidance only; detection never executes a shortcode or submits a form. */
    public static function review_notice( int $post_id ): string {
        $source = self::source( $post_id );
        $notices = array();
        if ( self::commerce_page( $post_id, $source ) ) {
            $notices[] = __( 'WooCommerce content needs a journey review. A page-load scan does not test a populated cart, variations, checkout errors, payment, order confirmation or customer accounts. Use a staging store and test payment method, check signed-out and customer states, and record the exact journey in Manual checks. Edit generated store fields in WooCommerce.', 'build-with-accessibility' );
        }
        $content = (string) get_post_field( 'post_content', $post_id ) . wp_json_encode( $source );
        if ( preg_match( '~\[(?:contact-form-7|wpforms)(?:\s|\])|(?:contact-form-7|wpforms)(?:/|\\\\/)(?:contact-form-selector|form-selector)~', $content ) ) {
            $notices[] = __( 'This page embeds a form managed by Contact Form 7 or WPForms. Edit generated fields in that form plugin. A page-load scan does not submit the form or test validation, consent, confirmation or delivery; record those states in Manual checks. Shared form changes conservatively request another review across the site.', 'build-with-accessibility' );
        }
        return implode( ' ', $notices );
    }

    private static function changed_environment(): void {
        update_option( 'bwa_compatibility_revision', wp_generate_uuid4(), false );
    }

    public static function render_context( int $post_id ): string {
        return hash( 'sha256', wp_json_encode( array( self::source( $post_id ), BWA_Audits::environment() ) ) );
    }

    public static function owner( int $post_id ): string {
        if ( 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true ) ) { return 'Elementor'; }
        if ( get_post_meta( $post_id, '_fl_builder_enabled', true ) ) { return 'Beaver Builder'; }
        $panels = get_post_meta( $post_id, 'panels_data', true );
        if ( is_array( $panels ) && ! empty( $panels['widgets'] ) ) { return 'SiteOrigin'; }
        if ( get_post_meta( $post_id, 'brizy_enabled', true ) ) { return 'Brizy'; }
        return '';
    }

    public static function repair_notice( int $post_id ): string {
        $owner = self::owner( $post_id );
        /* translators: %s: the page builder that owns the rendered content. */
        return $owner ? sprintf( __( '%s controls this page’s content. Make repairs in that builder, then run a new page scan and any relevant manual checks. Native block repairs and undo are paused to protect the builder’s content.', 'build-with-accessibility' ), $owner ) : '';
    }

    public static function guard( int $post_id ) {
        $notice = self::repair_notice( $post_id );
        return $notice ? new WP_Error( 'bwa_builder_owned', $notice, array( 'status' => 409 ) ) : true;
    }

    private static function private_preview(): bool {
        if ( current_user_can( 'manage_options' ) && is_string( $_GET['bwa_locate'] ?? null ) && is_string( $_GET['_bwa_locate_nonce'] ?? null ) ) {
            $token = sanitize_text_field( wp_unslash( $_GET['bwa_locate'] ) );
            if ( preg_match( '/^[a-f0-9-]{36}$/', $token ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwa_locate_nonce'] ) ), 'bwa_locate_' . $token ) ) { return true; }
        }
        if ( current_user_can( 'manage_options' ) && is_string( $_GET['bwa_audit'] ?? null ) && is_string( $_GET['_bwa_audit_nonce'] ?? null ) ) {
            $token = sanitize_text_field( wp_unslash( $_GET['bwa_audit'] ) );
            if ( preg_match( '/^[a-f0-9-]{36}$/', $token ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwa_audit_nonce'] ) ), 'bwa_audit_' . $token ) ) { return true; }
        }
        if ( is_string( $_GET['bwa_check'] ?? null ) && is_string( $_GET['bwa_post'] ?? null ) && is_string( $_GET['_bwa_nonce'] ?? null ) ) {
            $id = sanitize_text_field( wp_unslash( $_GET['bwa_check'] ) );
            if ( preg_match( '/^[a-f0-9-]{36}$/', $id ) && current_user_can( 'edit_post', absint( $_GET['bwa_post'] ) ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwa_nonce'] ) ), 'bwa_check_' . $id ) ) { return true; }
        }
        return false;
    }

    /** Capability and nonce checks must pass. A valid ticket is still required to run axe. */
    public static function diagnostic(): void {
        if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
        if ( ! defined( 'DONOTMINIFY' ) ) { define( 'DONOTMINIFY', true ); }
        if ( ! defined( 'LITESPEED_NO_PAGEOPTM' ) ) { define( 'LITESPEED_NO_PAGEOPTM', true ); }
        add_filter( 'autoptimize_filter_noptimize', '__return_true' );
        do_action( 'litespeed_control_set_nocache', 'Authenticated accessibility diagnostic' );
        if ( function_exists( 'wpfc_exclude_current_page' ) ) { wpfc_exclude_current_page(); }
        nocache_headers();
        header( 'Referrer-Policy: same-origin' );
    }
}
