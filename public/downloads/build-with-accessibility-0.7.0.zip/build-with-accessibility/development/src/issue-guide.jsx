const { useEffect, useRef, useState } = wp.element;
const t = (text) => wp.i18n.__(text, "build-with-accessibility");
const api = (path, options = {}) => wp.apiFetch({ path: `/bwa/v1${path}`, ...options });
const labels = () => ({ unknown: t("Theme, plugin or other content"), gutenberg: t("Gutenberg"), elementor: t("Elementor"), woocommerce: t("WooCommerce"), cf7: t("Contact Form 7"), wpforms: t("WPForms Lite") });

function sourceSteps(kind) {
  switch (kind) {
    case "gutenberg": return t("Use the mapped repair button when one is available. Otherwise open the page editor and use List View to find the block. Check whether it belongs to a synced pattern or template before editing a shared source.");
    case "elementor": return t("Open the Elementor document and use Structure (called Navigator in some versions) to select the widget. Inspect its content and style settings. A header, footer or template may belong to a separate document. Embedded forms still belong to their form plugin.");
    case "woocommerce": return t("For product content, open the product editor. For cart or checkout content, identify whether it comes from a WooCommerce block, a theme template or an extension. Change the owning source; this plugin does not rewrite generated checkout fields. Use a staging store for journey testing.");
    case "cf7": return t("Open Contact → Contact Forms and select the embedded form. In its Form tab, find the field or text shown in the evidence. Edit the form template, keeping field names, validation and mail-tag mappings intact. Shared forms may appear on several pages.");
    case "wpforms": return t("Open WPForms → All Forms and edit the embedded form. Select the field in the builder, then review Field Options. Save the form itself; editing the page's embed does not change generated field labels. Shared forms may appear on several pages.");
    default: return t("Use the highlighted location and recorded evidence to identify the owning block, theme template or plugin. Headers and footers often live outside the page editor. If the owner is unclear, give the evidence to the site maintainer before changing code.");
  }
}

export function repairAdvice(rule, kind) {
  if (["image-alt", "input-image-alt", "svg-img-alt", "bwa-filename-alt", "role-img-alt"].includes(rule)) return t("Decide what the image communicates in this placement. Give informative images a useful alternative; use an intentionally empty alternative only for decorative images. For linked images, describe the link's purpose. In Elementor or a product image, check whether changing Media Library alt text affects other placements, then verify the rendered result.");
  if (["heading-order", "empty-heading", "page-has-heading-one"].includes(rule)) return t("Read the surrounding headings as an outline. Give the heading meaningful text and choose a level that fits the section hierarchy. In Gutenberg use the Heading block level; in Elementor use the heading's HTML tag setting. Keep visual font size separate from heading level.");
  if (["link-name", "bwa-link-purpose", "button-name", "input-button-name"].includes(rule)) return t("Give the link or button a name that explains its destination or action. Prefer clear visible wording and preserve its destination and behavior. Check icon-only controls and image links with a screen reader. Generic wording is a review prompt; its surrounding context may already explain the purpose.");
  if (["label", "select-name", "label-title-only", "form-field-multiple-labels", "aria-input-field-name"].includes(rule)) {
    if (kind === "cf7") return t("Add a visible label associated with this field. For one text field, wrap its form-tag in a label, or connect a label's for attribute to the form-tag's unique id option. Give checkbox/radio groups an appropriate group description and each choice its own label. A placeholder is not a replacement for a label.");
    if (kind === "wpforms") return t("Enter a meaningful Label in the field's options and keep it visible. Review Advanced options if Hide Label is enabled. Check sublabels and checkbox/radio choice labels too. Use descriptions for extra instructions; a placeholder is not a replacement for a label.");
    if (kind === "woocommerce") return t("Check the field's label in the block, checkout extension or template that creates it. Preserve its field key, required state and checkout validation. Do not replace generated checkout HTML with a static field. A placeholder is not a replacement for a label.");
    return t("Provide a visible label connected to the correct field with a unique id, or a valid wrapping label. Review group descriptions for related choices. Preserve the field's name, required state and submission behavior. A placeholder is not a replacement for a label.");
  }
  if (rule.startsWith("color-contrast")) return t("Check the text's actual foreground and background, including images, gradients, hover and focus states. Adjust the owning block, widget or theme style and verify the applicable contrast threshold. Do not fix contrast by hiding the text or removing its meaning.");
  if (["frame-title", "frame-title-unique"].includes(rule)) return t("Give the embedded frame a concise title describing its purpose, using the owning embed or widget settings. Check that similar frames have distinguishable titles. A frame title does not evaluate the accessibility of the embedded content.");
  return t("Read the rule explanation below and inspect the element in context. Make the smallest appropriate change in the owning source. Do not hide meaningful content or add ARIA simply to silence a rule. If the correct change is unclear, record what needs a maintainer's review.");
}

function Preview({ item, onSource }) {
  const frame = useRef(null), stage = useRef(null), ticketRef = useRef(null), navigated = useRef(null);
  const [attempt, setAttempt] = useState(0);
  const [ticket, setTicket] = useState(null);
  const [result, setResult] = useState(null);
  const [scale, setScale] = useState(1);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (!attempt) return;
    let alive = true, timer, verifying = false, context = null, validation = 0;
    ticketRef.current = null; setTicket(null); setResult(null); setLoading(true); onSource(null);
    async function verify(data) {
      if (!alive || verifying || !ticketRef.current) return;
      verifying = true;
      const currentValidation = ++validation;
      try {
        const source = await api(`/locate-runs/${ticketRef.current.token}/source`, { method: "POST", data });
        if (!alive || currentValidation !== validation) return;
        clearTimeout(timer);
        setResult({ status: "located", message: t("Matching element highlighted in purple. This is a read-only view of the current page state.") });
        onSource(source);
      } catch (error) {
        if (alive && currentValidation === validation) { clearTimeout(timer); setResult({ status: "unavailable", message: error.message }); setTicket(null); ticketRef.current = null; onSource(null); }
      } finally { verifying = false; if (alive && currentValidation === validation) setLoading(false); }
    }
    const receive = (event) => {
      const current = ticketRef.current;
      if (!alive || !current || event.origin !== location.origin || event.source !== frame.current?.contentWindow || event.data?.source !== "bwa-locate" || event.data.token !== current.token) return;
      if (event.data.status === "located" && event.data.context) { context = event.data.context; verify(context); }
      if (event.data.status === "unavailable") { ++validation; clearTimeout(timer); context = null; setResult({ status: "unavailable", message: event.data.message }); setLoading(false); setTicket(null); ticketRef.current = null; onSource(null); }
    };
    const checkOnReturn = () => { if (context) verify(context); };
    navigated.current = () => {
      if (!alive || !context) return;
      ++validation; clearTimeout(timer); context = null; ticketRef.current = null;
      setTicket(null); setLoading(false); onSource(null);
      setResult({ status: "unavailable", message: t("The preview navigated away from the matched page. Locate the element again after recreating the intended page state.") });
    };
    window.addEventListener("message", receive);
    window.addEventListener("focus", checkOnReturn);
    api(`/issues/${item.id}/locate`, { method: "POST" }).then((value) => {
      if (!alive) return;
      if (new URL(value.url).origin !== location.origin) throw new Error(t("The site and admin use different origins. Open administration on the site's origin to inspect this page."));
      ticketRef.current = value; setTicket(value);
      timer = setTimeout(() => {
        if (!alive) return;
        ++validation;
        ticketRef.current = null; setTicket(null); setLoading(false);
        setResult({ status: "unavailable", message: t("The preview did not respond. A frame policy, cache, slow page or missing theme hook may have blocked inspection. Use the source guide or retry; no match was confirmed.") });
      }, 30000);
    }).catch((error) => { if (alive) { setLoading(false); setResult({ status: "unavailable", message: error.message }); } });
    return () => { alive = false; clearTimeout(timer); ticketRef.current = null; navigated.current = null; window.removeEventListener("message", receive); window.removeEventListener("focus", checkOnReturn); };
  }, [attempt, item.id]);
  useEffect(() => {
    if (!ticket || !stage.current) return;
    const measure = () => setScale(Math.min(1, stage.current.clientWidth / ticket.width));
    const resize = new ResizeObserver(measure); resize.observe(stage.current); measure();
    return () => resize.disconnect();
  }, [ticket]);
  return <div className="bwa-locate">
    <div className="bwa-detail-actions">
      <button type="button" className="bwa-button" disabled={!item.fresh || loading} onClick={() => setAttempt((n) => n + 1)}>{attempt ? t("Reload element preview") : t("Locate element")}</button>
      {result?.status === "located" && ticket && <button type="button" className="bwa-button bwa-button--secondary" onClick={() => frame.current?.contentWindow?.postMessage({ source: "bwa-locate-command", token: ticket.token, action: "recenter" }, location.origin)}>{t("Center highlight")}</button>}
    </div>
    {!item.fresh && <p className="bwa-alert">{t("This page has changed. Rescan it before locating the element or using a mapped repair.")}</p>}
    <p role="status" className={result?.status === "unavailable" ? "bwa-alert" : "bwa-locate-status"}>{loading ? t("Loading a private preview and matching the recorded element…") : result?.message || t("Locate the recorded element in a private preview. The preview does not save changes, submit forms or mark an issue fixed.")}</p>
    {ticket && <>
      <div className="bwa-locate-stage" ref={stage} style={{ height: ticket.height * scale }}>
        <div inert="" aria-hidden="true" style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          <iframe ref={frame} onLoad={() => navigated.current?.()} title={t("Read-only highlighted page preview")} tabIndex="-1" sandbox="allow-scripts allow-same-origin" referrerPolicy="same-origin" src={ticket.url} width={ticket.width} height={ticket.height} style={{ width: ticket.width, height: ticket.height, transform: `scale(${scale})`, transformOrigin: "top left", maxWidth: "none", border: 0, pointerEvents: "none" }} />
        </div>
      </div>
      <p className="bwa-muted">{wp.i18n.sprintf(t("Preview viewport: %1$d × %2$d, scaled to fit. The visual highlight is also described above; all repair controls are outside the preview."), ticket.width, ticket.height)}</p>
    </>}
  </div>;
}

export function IssueGuide({ item, actions, rescan, manual }) {
  const native = !!(item.repair_url || item.content_repair);
  const [source, setSource] = useState(null);
  const [selected, setSelected] = useState("");
  const kind = selected || source?.kind || (native ? "gutenberg" : "unknown");
  const verified = source?.kind === kind && source.verified_document;
  return <section className="bwa-issue-guide" aria-labelledby="bwa-guide-title">
    <h3 id="bwa-guide-title">{t("Repair guide")}</h3>
    <ol className="bwa-guide-steps">
      <li><h4>{t("Locate the element")}</h4><Preview item={item} onSource={setSource} /></li>
      <li><h4>{t("Find its owning source")}</h4>
        <label htmlFor="bwa-guide-source">{t("Repair instructions for")}</label>
        <select id="bwa-guide-source" value={kind} onChange={(event) => setSelected(event.target.value)}>{Object.entries(labels()).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>
        {source && <p className="bwa-muted">{wp.i18n.sprintf(t("Detected context: %s. This is a source clue, not permission to rewrite generated content. Choose another guide if needed."), labels()[source.kind])}</p>}
        <p>{sourceSteps(kind)}</p>
        <p className="bwa-muted">{t("Editor links open in a new tab so you can return to this finding after saving.")}</p>
        <div className="bwa-detail-actions">{actions}{verified && source.edit_url && <a className="bwa-button bwa-button--secondary" href={source.edit_url} target="_blank" rel="noopener noreferrer">{source.edit_label} {t("(new tab)")}</a>}</div>
      </li>
      <li><h4>{t("Make a focused change")}</h4><p>{repairAdvice(item.rule_id, kind)}</p><p className="bwa-muted">{t("Built-in repair undo applies only to changes recorded by this plugin. For changes made in another editor, use that tool's revision or undo controls.")}</p></li>
      <li><h4>{t("Save, recheck and test")}</h4><p>{t("Save in the owning editor, return here and rescan the page. For a built-in repair, also run its focused recheck. Inspect the new report before deciding whether the finding is resolved.")}</p>
        <p>{["cf7", "wpforms", "woocommerce"].includes(kind) ? t("On a staging site, test keyboard use, visible labels, required fields, invalid input and recovery, then confirmation. For checkout, also test a populated cart and a test payment method. A page-load scan does not exercise these journeys.") : t("Check the changed content with a keyboard and screen reader, and at zoom. Review meaning and relevant interactive states. A highlight or a clear automated scan is not proof of accessibility.")}</p>
        <div className="bwa-detail-actions"><button type="button" className="bwa-button bwa-button--secondary" onClick={rescan}>{t("Rescan page")}</button><button type="button" className="bwa-button bwa-button--secondary" onClick={manual}>{t("Record manual testing")}</button></div>
      </li>
    </ol>
  </section>;
}
