// Review prompts, not WCAG determinations. No image interpretation or generated copy.
export function editorialReview(doc, selectorFor, snippet) {
  const rules = [
    { id: "bwa-filename-alt", selector: "img[alt]", matches: (el) => /(?:\.(?:jpe?g|png|gif|webp|avif|svg|heic|bmp|tiff?)|^(?:img|dsc|pxl)[_ -]?\d+)$/i.test(el.getAttribute("alt").trim()) },
    { id: "bwa-link-purpose", selector: "a[href]", matches: (el) => {
      // Author-provided accessible names need a human assessment of their own.
      if (el.hasAttribute("aria-label") || el.hasAttribute("aria-labelledby") || el.querySelector("img")) return false;
      return /^(?:click here|here|read more|learn more|more|link|details)[.!…]?$/i.test(el.textContent.trim().replace(/\s+/g, " "));
    } },
  ];
  return rules.map((rule) => ({ id: rule.id, nodes: [...doc.querySelectorAll(rule.selector)]
    .filter((el) => !el.closest('#wpadminbar, [hidden], [inert], [aria-hidden="true"]') && el.getClientRects().length && getComputedStyle(el).visibility === "visible" && rule.matches(el))
    .map((el) => {
      const path = el.getAttribute("data-bwa-block-path");
      return { target: [selectorFor(el)], html: snippet(el.outerHTML), impact: "unknown", block_path: /^\d+(\.\d+)*$/.test(path || "") ? path.split(".").map(Number) : null, repair_target: el.getAttribute("data-bwa-repair-target") };
    }) })).filter((rule) => rule.nodes.length);
}
