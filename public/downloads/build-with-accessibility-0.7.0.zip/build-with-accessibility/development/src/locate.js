/* Loaded only in an authorized inspection. This never repairs or submits a page. */
const config = window.bwaLocate;
const t = (text) => wp.i18n.__(text, "build-with-accessibility");
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const send = (status, message, context = null) => window.parent.postMessage({ source: "bwa-locate", token: config.token, status, message, context }, location.origin);

function canonical(html) {
  // Parsing in an inert template never inserts recorded markup into the live page.
  const template = document.createElement("template");
  template.innerHTML = html;
  if (template.content.childElementCount !== 1) return null;
  for (const element of template.content.querySelectorAll("*")) {
    for (const attribute of [...element.attributes]) {
      if (attribute.name.startsWith("data-bwa-") || (element.localName === "input" && attribute.name === "value")) element.removeAttribute(attribute.name);
    }
    if (element.localName === "textarea") element.textContent = "";
    const attributes = [...element.attributes].map(({ name, value }) => [name, value]).sort(([a], [b]) => a.localeCompare(b));
    for (const { name } of [...element.attributes]) element.removeAttribute(name);
    for (const [name, value] of attributes) element.setAttribute(name, value);
  }
  return template.innerHTML;
}

function contextFor(element) {
  const cf7 = element.closest(".wpcf7");
  if (cf7) return { kind: "cf7", document_id: Number(cf7.id.match(/^wpcf7-f(\d+)/)?.[1] || cf7.getAttribute("data-wpcf7-id")) || 0 };
  const form = element.closest('form[id^="wpforms-form-"]');
  if (form) return { kind: "wpforms", document_id: Number(form.id.match(/^wpforms-form-(\d+)$/)?.[1]) || 0 };
  if (element.closest(".woocommerce, .wc-block-checkout, .wc-block-cart, .wc-block-components-form") || (config.product && element.closest(".product"))) return { kind: "woocommerce", document_id: config.post_id };
  const builder = element.closest("[data-elementor-id]");
  if (builder) return { kind: "elementor", document_id: Number(builder.getAttribute("data-elementor-id")) || 0 };
  if (element.closest("[data-bwa-block-path], [data-bwa-repair-target]") || element.querySelector("img[data-bwa-block-path]")) return { kind: "gutenberg", document_id: config.post_id };
  return { kind: "unknown", document_id: config.post_id };
}

async function locate() {
  if (!config || window.parent === window) return;
  if (config.error) return send("unavailable", config.error);
  if (!Array.isArray(config.target) || config.target.length !== 1 || typeof config.target[0] !== "string") {
    return send("unavailable", t("This finding is inside a frame or shadow root. Inspect it in its owning tool using the recorded evidence; this preview will not highlight a different element."));
  }
  if (!config.html || config.html.length >= 6000) return send("unavailable", t("The recorded element evidence is incomplete. Inspect the source manually; no element has been highlighted."));
  if (document.readyState !== "complete") await new Promise((resolve) => window.addEventListener("load", resolve, { once: true }));
  if (document.fonts?.ready) await Promise.race([document.fonts.ready, wait(5000)]);
  await wait(config.settle_ms || 500);
  const expected = canonical(config.html);
  if (!expected) return send("unavailable", t("The recorded element could not be matched safely. Rescan and try again."));
  let node;
  try {
    const matches = document.querySelectorAll(config.target[0]);
    if (matches.length !== 1) return send("unavailable", matches.length ? t("The selector now matches more than one element. Rescan to record an unambiguous location.") : t("The element is not present in this page state. It may have moved or require a different cart, login, menu or form state. Recreate that state and rescan."));
    node = matches[0];
  } catch { return send("unavailable", t("The recorded selector cannot be used in this preview. Inspect the evidence and rescan.")); }
  if (node.closest("#wpadminbar")) return send("unavailable", t("WordPress administration controls are outside this preview's inspection scope."));

  const ring = document.createElement("div");
  ring.setAttribute("data-bwa-highlight", "");
  ring.setAttribute("aria-hidden", "true");
  ring.style.cssText = "position:fixed;pointer-events:none;z-index:2147483647;border:4px solid #5b21b6;box-shadow:0 0 0 3px #fff,0 0 0 5px #111827;box-sizing:border-box;display:none;";
  // Outside body: the diagnostic cannot change content selectors or evidence.
  document.documentElement.append(ring);
  let active = true;
  let lastStatus = "";
  const context = contextFor(node);
  function report(status, message) {
    if (lastStatus === status) return;
    lastStatus = status;
    send(status, message, status === "located" ? context : null);
  }
  function stop(message) {
    active = false;
    ring.remove();
    observer.disconnect();
    resize.disconnect();
    report("unavailable", message);
  }
  function update() {
    if (!active) return;
    const current = document.querySelectorAll(config.target[0]);
    if (current.length !== 1 || current[0] !== node) return stop(t("The element's location became ambiguous or changed. The highlight was removed. Rescan before continuing."));
    if (!node.isConnected || canonical(node.outerHTML) !== expected) return stop(t("The live element no longer matches the recorded evidence. The highlight was removed. Rescan this page state before continuing."));
    for (let parent = node; parent; parent = parent.parentElement) {
      const style = getComputedStyle(parent);
      if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse" || Number(style.opacity) === 0 || parent.hidden) return stop(t("The element is hidden in this page state. Open the relevant state on your staging site and rescan; no hidden element is presented as visible."));
    }
    if (!node.getClientRects().length) return stop(t("The element has no visible box in this page state. Inspect it manually and rescan the relevant state."));
    const rect = node.getBoundingClientRect();
    ring.style.left = `${rect.left - 6}px`;
    ring.style.top = `${rect.top - 6}px`;
    ring.style.width = `${Math.max(rect.width, 12) + 12}px`;
    ring.style.height = `${Math.max(rect.height, 12) + 12}px`;
    ring.style.display = "block";
    report("located", t("Matching element highlighted. The preview is read-only; use the repair guide to change its source."));
  }
  let pending;
  const observer = new MutationObserver(() => { clearTimeout(pending); pending = setTimeout(update, 150); });
  const resize = new ResizeObserver(update);
  observer.observe(document.body, { subtree: true, childList: true, attributes: true, characterData: true });
  resize.observe(node);
  window.addEventListener("scroll", update, { passive: true, capture: true });
  window.addEventListener("resize", update);
  window.addEventListener("message", (event) => {
    if (!active || event.origin !== location.origin || event.source !== window.parent || event.data?.source !== "bwa-locate-command" || event.data.token !== config.token || event.data.action !== "recenter") return;
    node.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); update();
  });
  node.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
  update();
  setTimeout(() => stop(t("This inspection expired. Locate the element again for a fresh preview.")), 5 * 60 * 1000);
}
locate().catch(() => send("unavailable", t("The page could not complete its inspection. A page policy, missing theme hook or changed element may be responsible. Rescan or inspect the source manually.")));
