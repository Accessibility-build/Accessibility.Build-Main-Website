<?php
return array( 'dependencies' => array( 'wp-api-fetch', 'wp-components', 'wp-element', 'wp-i18n', 'wp-a11y' ), 'version' => 'd15941909297' );
