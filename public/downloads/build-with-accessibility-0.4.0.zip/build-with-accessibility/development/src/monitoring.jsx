const { useEffect, useRef, useState } = wp.element;
const t = (text) => wp.i18n.__(text, "build-with-accessibility");
const api = (path, options = {}) => wp.apiFetch({ path: `/bwa/v1${path}`, ...options });
const date = (value) => value ? new Date(value.replace(" ", "T")).toLocaleString() : t("Not yet scanned");
const profileName = (profile) => profile === "all" ? t("All enabled axe rules") : t("WCAG 2.2 A / AA");
const categories = [
  ["new", "Newly detected"],
  ["changed", "Changed findings"],
  ["continuing", "Still detected"],
  ["not_detected", "No longer detected"],
  ["unverified", "Unverified changes"],
];
const reasons = [
  ["page_changed", "Page content or publishing details changed"],
  ["site_changed", "Theme, plugins, or site configuration changed"],
  ["failed", "Latest scan attempt failed"],
  ["unscanned", "No completed scan for these settings"],
  ["scan_context", "Scan settings, browser, account, or saved scan format changed"],
  ["coverage", "Some embedded frames could not be checked"],
];
function Button({ children, secondary, ...props }) {
  return <button type="button" className={`bwa-button${secondary ? " bwa-button--secondary" : ""}`} {...props}>{children}</button>;
}
function ErrorNotice({ message }) {
  return message ? <p className="bwa-alert bwa-alert--error" role="alert">{message}</p> : null;
}
function useResource(path, tick) {
  const [state, setState] = useState({ data: null, loading: true, error: "" });
  useEffect(() => {
    let alive = true;
    setState((old) => ({ ...old, loading: true, error: "" }));
    api(path).then((data) => { if (alive) setState({ data, loading: false, error: "" }); })
      .catch((error) => { if (alive) setState({ data: null, loading: false, error: error.message }); });
    return () => { alive = false; };
  }, [path, tick]);
  return state;
}

export function RecheckInbox({ tick, enqueue, busy, viewReport, reviewPage }) {
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [reason, setReason] = useState("");
  const [refresh, setRefresh] = useState(0);
  const [selected, setSelected] = useState({});
  const [state, setState] = useState({ items: [], loading: true, error: "", page: 0, has_more: false, checked: 0 });
  const requestId = useRef(0);
  const stateRef = useRef(state);
  stateRef.current = state;
  async function load(reset = false) {
    const id = ++requestId.current;
    const previous = stateRef.current;
    setState((old) => ({ ...(reset ? { items: [], page: 0, has_more: false, checked: 0 } : old), loading: true, error: "" }));
    if (reset) setSelected({});
    try {
      const data = await api(`/recheck-inbox?page=${reset ? 1 : previous.page + 1}&search=${encodeURIComponent(query)}&reason=${reason}`);
      if (id !== requestId.current) return;
      if (!reset && (data.inventory_revision !== previous.inventory_revision || data.environment_hash !== previous.environment_hash || ["profile", "viewport", "settle_ms"].some((key) => data.settings[key] !== previous.settings[key]))) {
        throw new Error(t("Pages, site settings, or scan settings changed while loading more pages. Refresh the inbox before continuing."));
      }
      const byKey = new Map((reset ? [] : previous.items).map((item) => [item.target.key, item]));
      data.items.forEach((item) => byKey.set(item.target.key, item));
      setState({ ...data, items: [...byKey.values()], checked: (reset ? 0 : previous.checked) + data.checked, loading: false, error: "" });
    } catch (error) {
      if (id === requestId.current) setState((old) => ({ ...old, loading: false, error: error.message }));
    }
  }
  useEffect(() => {
    load(true);
    return () => { requestId.current++; };
  }, [tick, query, reason, refresh]);
  const items = state.items;
  return <>
    <p className="bwa-section-description">{t("See which pages need a fresh automated check after saved content or tracked site changes. Run the selected scans here, then review their baseline comparisons in Reports.")}</p>
    <p className="bwa-scope-note">{t("This inbox checks saved page and site records when opened or refreshed. It cannot detect every external stylesheet, cache, custom plugin setting, or interactive state. An empty inbox is not evidence of accessibility or compliance; manual testing is still required.")}</p>
    <div className="bwa-toolbar">
      <form role="search" onSubmit={(event) => { event.preventDefault(); setQuery(search); setRefresh((value) => value + 1); }}>
        <label htmlFor="bwa-inbox-search">{t("Find pages to recheck")}</label>
        <div className="bwa-inline"><input id="bwa-inbox-search" type="search" value={search} onChange={(event) => setSearch(event.target.value)} /><Button secondary type="submit">{t("Search")}</Button></div>
      </form>
      <div><label htmlFor="bwa-inbox-reason">{t("Reason to recheck")}</label><select id="bwa-inbox-reason" value={reason} onChange={(event) => setReason(event.target.value)}><option value="">{t("All reasons")}</option>{reasons.map(([value, label]) => <option key={value} value={value}>{t(label)}</option>)}</select></div>
      <Button secondary disabled={state.loading} onClick={() => setRefresh((value) => value + 1)}>{t("Refresh inbox")}</Button>
    </div>
    {state.settings && <p>{profileName(state.settings.profile)} · {state.settings.viewport} · {t("Checked")} {date(state.checked_at)}</p>}
    <ErrorNotice message={state.error} />
    <div className="bwa-toolbar">
      <p role="status">{state.loading ? t("Checking page changes…") : `${t("Needs attention:")} ${items.length} · ${t("Pages checked:")} ${state.checked}`}</p>
      <div className="bwa-inline">
        <Button disabled={busy || state.loading || !Object.keys(selected).length} onClick={() => { enqueue(Object.values(selected)); setSelected({}); }}>{t("Scan selected")} ({Object.keys(selected).length})</Button>
        <Button secondary disabled={busy || state.loading || !items.length} onClick={() => enqueue(items.map((item) => item.target))}>{t("Scan listed pages")}</Button>
      </div>
    </div>
    {!!items.length && <div className="bwa-table-wrap" aria-busy={state.loading}><table className="bwa-table bwa-inbox-table">
      <caption>{t("Pages needing another automated check for the current scan settings")}</caption>
      <thead><tr><th scope="col"><input type="checkbox" aria-label={t("Select all listed pages")} checked={items.every((item) => selected[item.target.key])} onChange={(event) => setSelected(event.target.checked ? Object.fromEntries(items.map((item) => [item.target.key, item.target])) : {})} /></th><th scope="col">{t("Page")}</th><th scope="col">{t("Why check again")}</th><th scope="col">{t("Last attempt")}</th><th scope="col">{t("Actions")}</th></tr></thead>
      <tbody>{items.map((item) => <tr key={item.target.key}>
        <td><input type="checkbox" aria-label={`${t("Select")} ${item.target.title}`} checked={!!selected[item.target.key]} onChange={(event) => setSelected((old) => { const next = { ...old }; if (event.target.checked) next[item.target.key] = item.target; else delete next[item.target.key]; return next; })} /></td>
        <th scope="row">{item.target.title}<span className="bwa-cell-meta">{item.target.type} · {item.target.status}</span></th>
        <td><ul className="bwa-recheck-reasons">{item.reasons.map((code) => <li key={code}>{t(reasons.find(([value]) => value === code)?.[1] || code)}</li>)}</ul></td>
        <td>{date(item.last_attempt?.created_at)}{item.last_attempt?.status === "failed" && <span className="bwa-cell-meta">{t("Could not complete")}</span>}</td>
        <td><div className="bwa-table-actions"><Button secondary disabled={busy || state.loading} onClick={() => enqueue([item.target])}>{t("Scan page")}</Button>{item.last_attempt && <Button secondary onClick={() => viewReport(item.last_attempt.id)}>{t("Report & comparison")}</Button>}<Button secondary onClick={() => reviewPage(item.target.key)}>{t("Manual review")}</Button></div></td>
      </tr>)}</tbody>
    </table></div>}
    {!state.loading && !state.error && !items.length && <div className="bwa-empty"><h2>{state.has_more ? t("No matching pages in this batch") : t("No pages need rechecking in this search")}</h2><p>{state.has_more ? t("Continue checking the remaining inventory before drawing conclusions.") : t("Tracked records are up to date for these settings. Continue manual testing and rescan after changes this plugin cannot track.")}</p></div>}
    {state.has_more && <div className="bwa-toolbar"><p>{t("More pages remain in the inventory. Counts above cover only the pages checked so far.")}</p><Button secondary disabled={state.loading} onClick={() => load()}>{t("Check more pages")}</Button></div>}
  </>;
}

function Evidence({ title, finding }) {
  return <div><h4>{title}</h4>{finding ? <><p>{finding.kind === "incomplete" ? t("Needs human review") : t("Automated finding")} · {finding.impact}</p><pre tabIndex="0"><code>{JSON.stringify(finding.target)}{"\n"}{finding.html}</code></pre><p className="bwa-preserve">{finding.explanation}</p></> : <p>{t("Not present in this scan's stored findings. This alone does not prove a fix.")}</p>}</div>;
}

export function BaselineComparison({ report, tick, changed }) {
  const [category, setCategory] = useState("");
  const [page, setPage] = useState(1);
  const [form, setForm] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [saveError, setSaveError] = useState("");
  const focus = useRef(null);
  const action = useRef(null);
  const heading = useRef(null);
  const { data, loading, error } = useResource(`/comparisons/${report.id}?category=${category}&page=${page}`, tick);
  useEffect(() => { if (form) focus.current?.focus(); }, [form]);
  let canPin = false;
  try { canPin = report.status === "completed" && JSON.parse(report.comparison_context || "{}").schema === 1; } catch { /* Older reports require a new scan. */ }
  async function save(remove = false) {
    setSaving(true); setSaveError(""); setMessage("");
    try {
      await api(`/baselines/${report.target.key}`, { method: remove ? "DELETE" : "PUT", data: { profile: report.profile, viewport: report.viewport, expected_revision: data.baseline?.revision || "", scan_id: Number(report.id), note } });
      const text = remove ? t("Baseline removed. Future comparisons need a new reference.") : t("Baseline saved. Later matching scans will compare against this reference.");
      setForm(""); setNote(""); setMessage(text); setPage(1); changed(); wp.a11y.speak(text); heading.current?.focus();
    } catch (error) { setSaveError(error.message); }
    finally { setSaving(false); }
  }
  return <section className="bwa-surface bwa-report-section bwa-baseline" aria-labelledby={`bwa-baseline-title-${report.id}`}>
    <h3 id={`bwa-baseline-title-${report.id}`} tabIndex="-1" ref={heading}>{t("Baseline comparison")}</h3>
    <p>{t("A baseline is a scan you choose as a reference, not a certification or a completed manual audit. Each page can keep a separate reference for each rule profile and viewport. Pinned references are kept in addition to normal scan history.")}</p>
    <ErrorNotice message={error || saveError} />
    {message && <p className="bwa-alert" role="status">{message}</p>}
    {loading && <p role="status">{t("Loading comparison…")}</p>}
    {data && <>
      {data.baseline && <div className="bwa-baseline-reference"><strong>{t("Pinned reference")} #{data.baseline.scan_id}</strong><p>{data.baseline.scan ? date(data.baseline.scan.created_at) : t("Saved reference scan")} · {report.viewport} · {profileName(report.profile)}</p><p className="bwa-preserve">{data.baseline.note}</p></div>}
      <p className={data.status === "incompatible" || data.status === "failed" ? "bwa-alert" : "bwa-scope-note"}>{data.message}</p>
      {data.warnings.map((warning) => <p className="bwa-alert" key={warning}>{warning}</p>)}
      <div className="bwa-no-print">
        <div className="bwa-inline" style={form ? { display: "none" } : undefined}>
          {canPin && data.baseline?.scan_id !== Number(report.id) && <Button secondary disabled={loading} onClick={(event) => { action.current = event.currentTarget; setForm("save"); setMessage(""); setSaveError(""); }}>{data.baseline ? t("Replace baseline with this scan") : t("Use this scan as baseline")}</Button>}
          {data.baseline && <Button secondary disabled={loading} onClick={(event) => { action.current = event.currentTarget; setForm("remove"); setMessage(""); setSaveError(""); }}>{t("Remove baseline")}</Button>}
        </div>
        {!canPin && report.status === "completed" && <p>{t("Run a new scan to create a baseline with complete comparison context. Older reports remain available as historical evidence.")}</p>}
        {form && <form className="bwa-baseline-form" onSubmit={(event) => { event.preventDefault(); save(form === "remove"); }}>
          <h4 tabIndex="-1" ref={focus}>{form === "remove" ? t("Remove this reference?") : t("Choose a reference for future scans")}</h4>
          <p>{form === "remove" ? t("The baseline snapshot will be removed. Its scan report becomes subject to the normal history limit. Saved content repairs remain in place.") : t("Review this scan's scope and findings. Record why you chose it, known barriers, and any separate manual testing evidence. Replacing a baseline releases the old report to normal history cleanup.")}</p>
          {form === "save" && <><label htmlFor={`bwa-baseline-note-${report.id}`}>{t("Baseline note")}</label><textarea id={`bwa-baseline-note-${report.id}`} rows="3" maxLength="2000" required value={note} onChange={(event) => setNote(event.target.value)} /></>}
          <div className="bwa-inline"><Button type="submit" disabled={saving || (form === "save" && !note.trim())}>{saving ? t("Saving…") : form === "remove" ? t("Confirm removal") : t("Save baseline")}</Button><Button secondary disabled={saving} onClick={() => { setForm(""); requestAnimationFrame(() => action.current?.focus()); }}>{t("Cancel")}</Button></div>
        </form>}
      </div>
      {data.counts && <>
        <div className="bwa-comparison-counts">{categories.map(([value, label]) => <div key={value}><strong>{data.counts[value]}</strong><span>{t(label)}</span></div>)}</div>
        <div className="bwa-no-print"><label htmlFor={`bwa-comparison-filter-${report.id}`}>{t("Findings to show")}</label><select id={`bwa-comparison-filter-${report.id}`} value={category} onChange={(event) => { setCategory(event.target.value); setPage(1); }}><option value="">{t("All changes")}</option>{categories.map(([value, label]) => <option key={value} value={value}>{t(label)}</option>)}</select></div>
        <p role="status">{t("Matching findings:")} {data.total}</p>
        <ul className="bwa-comparison-findings">{data.items.map((item) => <li key={item.key}><span className="bwa-badge">{t(categories.find(([value]) => value === item.category)[1])}</span><h4>{(item.after || item.before).help}</h4><p className="bwa-mono">{(item.after || item.before).rule_id}</p><details><summary>{t("Inspect comparison")}</summary><div className="bwa-repair-diff"><Evidence title={t("Baseline evidence")} finding={item.before} /><Evidence title={t("This scan")} finding={item.after} /></div></details></li>)}</ul>
        {data.pages > 1 && <nav className="bwa-pagination bwa-no-print" aria-label={t("Comparison result pages")}><Button secondary disabled={page <= 1} onClick={() => setPage((value) => value - 1)}>{t("Previous")}</Button><span>{t("Page")} {data.page} / {data.pages}</span><Button secondary disabled={page >= data.pages} onClick={() => setPage((value) => value + 1)}>{t("Next")}</Button></nav>}
      </>}
    </>}
  </section>;
}
