<?php
/** Pinned scan references, conservative comparisons, and a bounded recheck inbox. */
defined( 'ABSPATH' ) || exit;

final class BWA_Monitoring {
    public static function init(): void {
        add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
    }

    public static function install( string $charset ): void {
        global $wpdb;
        dbDelta( "CREATE TABLE {$wpdb->prefix}bwa_baselines (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            target_key varchar(40) NOT NULL,
            profile varchar(20) NOT NULL,
            viewport varchar(20) NOT NULL,
            scan_id bigint(20) unsigned NOT NULL,
            revision varchar(36) NOT NULL,
            note text NOT NULL,
            author bigint(20) unsigned NOT NULL,
            created_at datetime NOT NULL,
            snapshot longtext NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY target_profile_viewport (target_key,profile,viewport),
            KEY scan_id (scan_id)
        ) $charset;" );
    }

    public static function routes(): void {
        foreach ( array(
            '/baselines/(?P<target>home|\d+)' => array( 'GET,PUT,DELETE', 'baseline' ),
            '/comparisons/(?P<id>\d+)' => array( 'GET', 'comparison' ),
            '/recheck-inbox' => array( 'GET', 'inbox' ),
        ) as $path => $route ) {
            register_rest_route( 'bwa/v1', $path, array( 'methods' => $route[0], 'callback' => array( __CLASS__, $route[1] ), 'permission_callback' => array( 'BWA_Audits', 'permission' ) ) );
        }
    }

    private static function error( string $message, int $status = 422 ): WP_Error {
        return new WP_Error( 'bwa_monitoring', $message, array( 'status' => $status ) );
    }

    public static function context( array $settings, array $target ): array {
        $browser = isset( $_SERVER['HTTP_USER_AGENT'] ) && is_string( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
        return array(
            'schema' => 1, 'engine' => BWA_AXE_VERSION, 'actor' => get_current_user_id(),
            'browser' => substr( $browser, 0, 500 ),
            'profile' => $settings['profile'], 'viewport' => $settings['viewport'],
            'width' => 'mobile' === $settings['viewport'] ? 390 : 1366,
            'height' => 'mobile' === $settings['viewport'] ? 844 : 900,
            'settle_ms' => (int) $settings['settle_ms'], 'page_context' => $target['context'],
            'scope' => 'signed-in-initial-document-without-admin-toolbar-v1',
            'selector_version' => 1,
        );
    }

    private static function scan_row( int $id ): ?array {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM %i WHERE id=%d AND status IN ('completed','failed')", $wpdb->prefix . 'bwa_scans', $id ), ARRAY_A );
    }

    private static function reference( string $key, string $profile, string $viewport ): ?array {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE target_key=%s AND profile=%s AND viewport=%s', $wpdb->prefix . 'bwa_baselines', $key, $profile, $viewport ), ARRAY_A );
    }

    private static function reference_meta( ?array $row ): ?array {
        if ( ! $row ) { return null; }
        return array( 'scan_id' => (int) $row['scan_id'], 'revision' => $row['revision'], 'note' => $row['note'], 'author' => (int) $row['author'], 'created_at' => $row['created_at'] . 'Z', 'profile' => $row['profile'], 'viewport' => $row['viewport'] );
    }

    private static function scan_meta( array $row, array $target, string $environment ): array {
        return array( 'id' => (int) $row['id'], 'created_at' => $row['created_at'] . 'Z', 'status' => $row['status'], 'profile' => $row['profile'], 'viewport' => $row['viewport'], 'fresh' => $row['source_hash'] === $target['source_hash'] && $row['environment_hash'] === $environment );
    }

    public static function baseline( WP_REST_Request $request ) {
        global $wpdb;
        $key = (string) $request['target'];
        $target = BWA_Audits::target( $key );
        if ( is_wp_error( $target ) ) { return $target; }
        $profile = $request->get_param( 'profile' ) ?? BWA_Audits::settings()['profile'];
        $viewport = $request->get_param( 'viewport' ) ?? BWA_Audits::settings()['viewport'];
        if ( ! in_array( $profile, array( 'all', 'wcag22aa' ), true ) || ! in_array( $viewport, array( 'desktop', 'mobile' ), true ) ) { return self::error( __( 'Choose a valid scan profile and viewport.', 'build-with-accessibility' ) ); }
        $reference = self::reference( $key, $profile, $viewport );
        if ( 'GET' !== $request->get_method() ) {
            if ( $request->get_param( 'expected_revision' ) !== ( $reference['revision'] ?? '' ) ) { return self::error( __( 'Someone changed this baseline. Refresh before changing it again.', 'build-with-accessibility' ), 409 ); }
            if ( 'DELETE' === $request->get_method() ) {
                if ( $reference && 1 !== $wpdb->delete( $wpdb->prefix . 'bwa_baselines', array( 'id' => $reference['id'], 'revision' => $reference['revision'] ) ) ) { return self::error( __( 'The baseline changed or could not be removed. Refresh and try again.', 'build-with-accessibility' ), 409 ); }
            } else {
                $id = $request->get_param( 'scan_id' );
                $note = $request->get_param( 'note' );
                if ( ! is_int( $id ) || $id < 1 || ! is_string( $note ) || '' === trim( $note ) || mb_strlen( $note ) > 2000 ) { return self::error( __( 'Choose a saved scan and add a baseline note of at most 2,000 characters.', 'build-with-accessibility' ) ); }
                $note = sanitize_textarea_field( $note );
                if ( '' === trim( $note ) ) { return self::error( __( 'Add a plain-text note describing this baseline.', 'build-with-accessibility' ) ); }
                $scan = self::scan_row( $id );
                if ( ! $scan || $scan['target_key'] !== $key || $scan['profile'] !== $profile || $scan['viewport'] !== $viewport || 'completed' !== $scan['status'] ) { return self::error( __( 'Choose a completed scan for this page, profile, and viewport.', 'build-with-accessibility' ) ); }
                if ( 1 !== ( json_decode( $scan['comparison_context'] ?? '', true )['schema'] ?? null ) ) { return self::error( __( 'This older report lacks comparison context. Run a new scan before choosing a baseline.', 'build-with-accessibility' ) ); }
                unset( $scan['run_token'] );
                $data = array( 'target_key' => $key, 'profile' => $profile, 'viewport' => $viewport, 'scan_id' => $id, 'revision' => wp_generate_uuid4(), 'note' => $note, 'author' => get_current_user_id(), 'created_at' => current_time( 'mysql', true ), 'snapshot' => wp_json_encode( $scan ) );
                // The unique key and revision precondition protect competing selections.
                // An independent snapshot also survives a simultaneous history cleanup.
                $saved = $reference ? $wpdb->update( $wpdb->prefix . 'bwa_baselines', $data, array( 'id' => $reference['id'], 'revision' => $reference['revision'] ) ) : $wpdb->insert( $wpdb->prefix . 'bwa_baselines', $data );
                if ( 1 !== $saved ) { return self::error( __( 'The baseline changed or could not be saved. Refresh and try again.', 'build-with-accessibility' ), 409 ); }
            }
            BWA_Audits::prune( $key );
            $reference = self::reference( $key, $profile, $viewport );
        }
        return array( 'baseline' => self::reference_meta( $reference ), 'target' => $target );
    }

    private static function coverage( array $report ): array {
        $ids = array();
        foreach ( array( 'violations', 'incomplete', 'passes', 'inapplicable' ) as $kind ) {
            foreach ( $report[ $kind ] ?? array() as $rule ) { $ids[ $rule['id'] ] = true; }
        }
        $ids = array_keys( $ids ); sort( $ids, SORT_STRING );
        return $ids;
    }

    private static function findings( array $report ): array {
        $findings = array();
        foreach ( array( 'violations', 'incomplete' ) as $kind ) {
            foreach ( $report[ $kind ] ?? array() as $rule ) {
                foreach ( $rule['nodes'] as $node ) {
                    // Deliberately exclude result kind: a violation becoming incomplete
                    // is uncertain evidence for the same element, not a fixed issue.
                    $key = hash( 'sha256', $rule['id'] . ':' . wp_json_encode( $node['target'] ) );
                    $findings[ $key ] = array( 'rule_id' => $rule['id'], 'help' => $rule['help'], 'kind' => $kind, 'target' => $node['target'], 'html' => $node['html'], 'impact' => $node['impact'], 'explanation' => $node['failureSummary'] );
                }
            }
        }
        return $findings;
    }

    public static function comparison( WP_REST_Request $request ) {
        global $wpdb;
        $current = self::scan_row( (int) $request['id'] );
        if ( ! $current ) { return self::error( __( 'This scan is no longer available.', 'build-with-accessibility' ), 404 ); }
        $target = BWA_Audits::target( $current['target_key'] );
        if ( is_wp_error( $target ) ) { return $target; }
        $reference = self::reference( $current['target_key'], $current['profile'], $current['viewport'] );
        $revision = $request->get_param( 'baseline_revision' );
        if ( null !== $revision && $revision !== ( $reference['revision'] ?? '' ) ) { return self::error( __( 'The baseline changed. Refresh this comparison.', 'build-with-accessibility' ), 409 ); }
        $environment = BWA_Audits::environment();
        $result = array( 'status' => 'no_baseline', 'message' => __( 'Choose a reference scan to compare changes over time.', 'build-with-accessibility' ), 'target' => $target, 'current' => self::scan_meta( $current, $target, $environment ), 'baseline' => self::reference_meta( $reference ), 'counts' => null, 'items' => array(), 'total' => 0, 'pages' => 1, 'page' => 1, 'warnings' => array() );
        if ( 'completed' !== $current['status'] ) { $result['status'] = 'failed'; $result['message'] = __( 'This attempt failed. It cannot show new or cleared findings. Run the page scan again.', 'build-with-accessibility' ); return $result; }
        if ( ! $reference ) { return $result; }
        $before = json_decode( $reference['snapshot'], true );
        if ( ! is_array( $before ) ) { return self::error( __( 'The baseline snapshot is unavailable. Choose a new reference scan.', 'build-with-accessibility' ), 409 ); }
        $result['baseline']['scan'] = self::scan_meta( $before, $target, $environment );
        if ( (int) $current['id'] <= (int) $before['id'] ) {
            $result['status'] = (int) $current['id'] === (int) $before['id'] ? 'baseline' : 'before_baseline';
            $result['message'] = 'baseline' === $result['status'] ? __( 'This is the pinned reference. Run another scan to compare later results.', 'build-with-accessibility' ) : __( 'This report predates the selected baseline. Open a newer report to compare.', 'build-with-accessibility' );
            return $result;
        }
        $old_context = json_decode( $before['comparison_context'] ?? '', true );
        $new_context = json_decode( $current['comparison_context'] ?? '', true );
        $old_report = json_decode( $before['report'], true );
        $new_report = json_decode( $current['report'], true );
        if ( ! is_array( $old_context ) || ! is_array( $new_context ) || 1 !== ( $old_context['schema'] ?? null ) || $old_context !== $new_context || empty( self::coverage( $old_report ) ) || self::coverage( $old_report ) !== self::coverage( $new_report ) ) {
            $result['status'] = 'incompatible';
            $result['message'] = __( 'These scans have different or missing engine, rule coverage, browser, signed-in user, page scope, viewport, or wait settings. Use matching settings and run again, or deliberately choose a new baseline. No improvement counts are inferred.', 'build-with-accessibility' );
            return $result;
        }
        $uncertain = ! empty( $new_report['incomplete'] ) || ! empty( $old_report['frames']['unavailable'] ) || ! empty( $new_report['frames']['unavailable'] ) || ( $old_report['frames']['total'] ?? 0 ) !== ( $new_report['frames']['total'] ?? 0 );
        if ( $uncertain ) { $result['warnings'][] = __( 'Incomplete rule results or changed/unavailable frames prevent confirming absent findings. Those findings remain unverified.', 'build-with-accessibility' ); }
        if ( ! $result['current']['fresh'] ) { $result['warnings'][] = __( 'The page or tracked site configuration changed after this scan. This is a historical comparison; scan again for current evidence.', 'build-with-accessibility' ); }
        $last_attempt = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(id) FROM %i WHERE target_key=%s AND profile=%s AND viewport=%s AND status IN ('completed','failed')", $wpdb->prefix . 'bwa_scans', $current['target_key'], $current['profile'], $current['viewport'] ) );
        if ( $last_attempt > (int) $current['id'] ) { $result['warnings'][] = __( 'A newer scan attempt exists. This comparison describes the selected historical report; review the latest attempt as well.', 'build-with-accessibility' ); }
        $old = self::findings( $old_report ); $new = self::findings( $new_report );
        $counts = array_fill_keys( array( 'new', 'changed', 'continuing', 'not_detected', 'unverified' ), 0 );
        $items = array();
        foreach ( array_unique( array_merge( array_keys( $new ), array_keys( $old ) ) ) as $key ) {
            $a = $old[ $key ] ?? null; $b = $new[ $key ] ?? null;
            if ( ! $a ) { $category = 'new'; }
            elseif ( ! $b ) { $category = $uncertain || 'incomplete' === $a['kind'] ? 'unverified' : 'not_detected'; }
            elseif ( 'violations' === $a['kind'] && 'incomplete' === $b['kind'] ) { $category = 'unverified'; }
            else { $category = $a === $b ? 'continuing' : 'changed'; }
            ++$counts[ $category ];
            $items[] = array( 'key' => $key, 'category' => $category, 'before' => $a, 'after' => $b );
        }
        $filter = $request->get_param( 'category' );
        if ( is_string( $filter ) && isset( $counts[ $filter ] ) ) { $items = array_values( array_filter( $items, static fn( $item ) => $filter === $item['category'] ) ); }
        $page = max( 1, (int) $request->get_param( 'page' ) );
        $size = max( 1, min( 200, (int) ( $request->get_param( 'per_page' ) ?: 25 ) ) );
        $result['status'] = 'ready'; $result['message'] = __( 'Matched by rule and element selector. A moved or renamed element may appear as a new finding and an absent old finding. No longer detected does not mean fixed or compliant; verify the change manually.', 'build-with-accessibility' );
        $result['counts'] = $counts; $result['total'] = count( $items ); $result['page'] = $page; $result['pages'] = max( 1, (int) ceil( count( $items ) / $size ) ); $result['items'] = array_slice( $items, ( $page - 1 ) * $size, $size );
        return $result;
    }

    private static function state( array $target, array $settings, string $environment ): array {
        global $wpdb;
        // One profile/viewport at a time. A mobile scan must not clear a stale desktop result.
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,status,source_hash,environment_hash,comparison_context,summary,profile,viewport,created_at FROM %i WHERE target_key=%s AND profile=%s AND viewport=%s AND status IN ('completed','failed') ORDER BY id DESC LIMIT 2", $wpdb->prefix . 'bwa_scans', $target['key'], $settings['profile'], $settings['viewport'] ), ARRAY_A );
        $last = $rows[0] ?? null;
        $completed = null;
        foreach ( $rows as $row ) { if ( 'completed' === $row['status'] ) { $completed = $row; break; } }
        $reasons = array();
        if ( $last && 'failed' === $last['status'] ) { $reasons[] = 'failed'; }
        if ( ! $completed ) { $reasons[] = 'unscanned'; }
        else {
            if ( $completed['source_hash'] !== $target['source_hash'] ) { $reasons[] = 'page_changed'; }
            if ( $completed['environment_hash'] !== $environment ) { $reasons[] = 'site_changed'; }
            if ( json_decode( $completed['comparison_context'] ?? '', true ) !== self::context( $settings, $target ) ) { $reasons[] = 'scan_context'; }
            $summary = json_decode( $completed['summary'], true );
            if ( ! empty( $summary['unavailable_frames'] ) ) { $reasons[] = 'coverage'; }
        }
        return array( 'target' => $target, 'reasons' => $reasons, 'last_attempt' => $last ? self::scan_meta( $last, $target, $environment ) : null, 'completed_scan' => $completed ? self::scan_meta( $completed, $target, $environment ) : null );
    }

    public static function inbox( WP_REST_Request $request ): array {
        // Bounded inventory batches avoid loading an entire large site into one request.
        // Page numbers refer to inventory batches, not a misleading total of stale pages.
        $page = max( 1, (int) $request->get_param( 'page' ) );
        $search = $request->get_param( 'search' );
        $search = is_string( $search ) ? sanitize_text_field( $search ) : '';
        $reason = $request->get_param( 'reason' );
        $settings = BWA_Audits::settings();
        $inventory_revision = get_option( 'bwa_home_content_revision', '' );
        $query = new WP_Query( array( 'post_type' => array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment' ) ) ), 'post_status' => array( 'publish', 'private', 'draft', 'pending', 'future' ), 'posts_per_page' => 50, 'paged' => $page, 's' => $search, 'orderby' => 'ID', 'order' => 'ASC' ) );
        $targets = array();
        if ( 1 === $page && BWA_Audits::separate_home() && ( '' === $search || false !== stripos( __( 'Homepage', 'build-with-accessibility' ), $search ) ) ) { $targets[] = BWA_Audits::target( 'home' ); }
        foreach ( $query->posts as $post ) {
            $target = BWA_Audits::target( (string) $post->ID );
            if ( ! is_wp_error( $target ) ) { $targets[] = $target; }
        }
        $environment = BWA_Audits::environment(); $items = array();
        foreach ( $targets as $target ) {
            $state = self::state( $target, $settings, $environment );
            if ( $state['reasons'] && ( ! is_string( $reason ) || '' === $reason || in_array( $reason, $state['reasons'], true ) ) ) { $items[] = $state; }
        }
        return array( 'items' => $items, 'page' => $page, 'has_more' => $page < $query->max_num_pages, 'checked' => count( $targets ), 'settings' => $settings, 'environment_hash' => $environment, 'inventory_revision' => $inventory_revision, 'checked_at' => gmdate( 'c' ) );
    }
}
