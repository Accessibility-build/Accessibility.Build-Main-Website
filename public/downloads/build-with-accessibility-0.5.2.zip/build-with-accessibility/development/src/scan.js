/* Executed only in an authorized diagnostic page. No remote scanner or telemetry. */
const config = window.bwaScan;
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const send = (message) =>
  window.parent.postMessage(
    { source: "bwa-axe-scan", token: config.token, ...message },
    window.location.origin,
  );

async function prepareFrames(
  doc,
  depth = 0,
  counts = { total: 0, unavailable: 0 },
) {
  for (const frame of doc.querySelectorAll("iframe")) {
    counts.total++;
    try {
      if (
        depth > 4 ||
        !frame.contentDocument ||
        frame.contentWindow.location.origin !== window.location.origin
      )
        throw new Error("Unavailable frame");
      if (!frame.contentWindow.axe) {
        await Promise.race([
          new Promise((resolve, reject) => {
            const script = frame.contentDocument.createElement("script");
            script.src = config.axeUrl;
            script.onload = resolve;
            script.onerror = reject;
            frame.contentDocument.head.appendChild(script);
          }),
          wait(4000).then(() => {
            throw new Error("Frame timed out");
          }),
        ]);
      }
      await prepareFrames(frame.contentDocument, depth + 1, counts);
    } catch {
      counts.unavailable++;
    }
  }
  return counts;
}

function snippet(html) {
  const template = document.createElement("template");
  template.innerHTML = html;
  // Do not include filled form values in stored evidence or exports.
  template.content
    .querySelectorAll("input")
    .forEach((el) => el.removeAttribute("value"));
  template.content.querySelectorAll("textarea").forEach((el) => {
    el.textContent = "";
  });
  return template.innerHTML.slice(0, 6000);
}

function selectorFor(element) {
  const parts = [];
  for (let node = element; node?.nodeType === 1; node = node.parentElement) {
    if (
      node.id &&
      document.querySelectorAll(`#${CSS.escape(node.id)}`).length === 1
    ) {
      parts.unshift(`#${CSS.escape(node.id)}`);
      break;
    }
    const tag = node.localName;
    const siblings = node.parentElement
      ? [...node.parentElement.children].filter(
          (child) => child.localName === tag,
        )
      : [node];
    parts.unshift(
      siblings.length > 1
        ? `${tag}:nth-of-type(${siblings.indexOf(node) + 1})`
        : tag,
    );
  }
  return parts.join(" > ");
}

function compactRule(rule, includeNodes) {
  return {
    id: rule.id,
    help: rule.help,
    description: rule.description,
    tags: rule.tags,
    nodes_count: rule.nodes.length,
    nodes: includeNodes
      ? rule.nodes.map((node) => {
          let blockPath = null;
          const direct =
            node.element?.ownerDocument === document &&
            node.element.getRootNode() === document;
          // Verify local selectors against the actual element. Frame/shadow
          // findings retain axe's ancestry path and never get a repair link.
          const target = direct
            ? [selectorFor(node.element)]
            : node.ancestry || node.target;
          try {
            if (direct) {
              const element = node.element;
              const ownedImage =
                element?.tagName === "IMG"
                  ? element
                  : element?.tagName === "A" &&
                      element.querySelectorAll("img").length === 1
                    ? element.querySelector("img")
                    : null;
              const path = ownedImage?.getAttribute("data-bwa-block-path");
              if (/^\d+(\.\d+)*$/.test(path || ""))
                blockPath = path.split(".").map(Number);
            }
          } catch {
            /* An unmapped or shadow/frame target remains available for manual repair. */
          }
          const checks = [
            ...(node.any || []),
            ...(node.all || []),
            ...(node.none || []),
          ]
            .map((check) => check.message)
            .filter(Boolean);
          return {
            target,
            html: snippet(node.html),
            impact: node.impact,
            failureSummary: node.failureSummary || checks.join("\n"),
            block_path: blockPath,
            repair_target: direct ? node.element.getAttribute("data-bwa-repair-target") : null,
          };
        })
      : [],
  };
}

async function scan() {
  if (!config || window.parent === window) return;
  try {
    if (document.readyState !== "complete")
      await new Promise((resolve) =>
        window.addEventListener("load", resolve, { once: true }),
      );
    if (document.fonts?.ready)
      await Promise.race([document.fonts.ready, wait(5000)]);
    await wait(config.settings.settle_ms);
    const frames = await prepareFrames(document);
    send({ phase: "running" });
    const options = {
      iframes: true,
      elementRef: true,
      ancestry: true,
      selectors: true,
      absolutePaths: true,
      frameWaitTime: 10000,
    };
    if (config.settings.profile === "wcag22aa")
      options.runOnly = {
        type: "tag",
        values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa"],
      };
    const results = await window.axe.run(
      { exclude: [["#wpadminbar"]] },
      options,
    );
    send({
      status: "completed",
      report: {
        engine: results.testEngine,
        frames,
        violations: results.violations.map((rule) => compactRule(rule, true)),
        incomplete: results.incomplete.map((rule) => compactRule(rule, true)),
        passes: results.passes.map((rule) => compactRule(rule, false)),
        inapplicable: results.inapplicable.map((rule) =>
          compactRule(rule, false),
        ),
      },
    });
  } catch (error) {
    send({
      status: "failed",
      error: error?.message || "The page could not complete its axe-core scan.",
    });
  }
}
scan();
