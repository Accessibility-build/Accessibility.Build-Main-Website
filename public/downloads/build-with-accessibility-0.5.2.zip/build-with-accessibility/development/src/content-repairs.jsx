const { useEffect, useRef, useState } = wp.element;
const { Modal, Spinner } = wp.components;
const t = (text) => wp.i18n.__(text, "build-with-accessibility");
const api = (path, options = {}) =>
  wp.apiFetch({ path: `/bwa/v1${path}`, ...options });
const kindName = (kind) =>
  ({ heading: t("Heading"), link: t("Link"), label: t("Form label") })[kind] ||
  kind;
const Button = ({ children, secondary, buttonRef, ...props }) => (
  <button
    ref={buttonRef}
    type="button"
    className={`bwa-button ${secondary ? "bwa-button--secondary" : ""}`}
    {...props}
  >
    {children}
  </button>
);

function ContentRecheck({ postId, record, onDone, onBack }) {
  const frame = useRef(null);
  const heading = useRef(null);
  useEffect(() => { heading.current?.focus(); }, []);
  const [config, setConfig] = useState(null),
    [result, setResult] = useState(null),
    [error, setError] = useState("");
  useEffect(() => {
    let alive = true,
      accepted = false,
      timer,
      run;
    const save = async (value) => {
      if (!alive || accepted) return;
      accepted = true;
      clearTimeout(timer);
      try {
        const evidence = await api(
          `/posts/${postId}/repairs/${record.id}/recheck`,
          { method: "PUT", data: { token: run.token, result: value } },
        );
        if (alive) {
          setResult(evidence);
          onDone();
        }
      } catch (e) {
        if (alive) setError(e.message);
      }
    };
    const receive = (event) => {
      if (
        !run ||
        event.origin !== window.location.origin ||
        event.source !== frame.current?.contentWindow ||
        event.data?.source !== "bwa-content-recheck" ||
        event.data.token !== run.token
      )
        return;
      save(event.data.result);
    };
    window.addEventListener("message", receive);
    api(`/posts/${postId}/repairs/${record.id}/recheck`, { method: "POST" })
      .then((value) => {
        if (!alive) return;
        if (
          new URL(value.url, window.location.href).origin !==
          window.location.origin
        )
          throw new Error(
            t(
              "Use the same site address for WordPress administration and the page preview.",
            ),
          );
        run = value;
        setConfig(value);
        timer = setTimeout(
          () =>
            save({
              status: "inconclusive",
              reason: t(
                "The saved page did not finish its diagnostic. A cache, page policy, or slow resource may have blocked it. No pass was recorded.",
              ),
            }),
          25000,
        );
      })
      .catch((e) => {
        if (alive) setError(e.message);
      });
    return () => {
      alive = false;
      clearTimeout(timer);
      window.removeEventListener("message", receive);
    };
  }, [postId, record.id]);
  return (
    <section className="bwa-content-recheck">
      <h3 ref={heading} tabIndex="-1">{t("Recheck the saved repair")}</h3>
      <p>
        {t(
          "This opens the saved page as you, checks the approved change and relevant axe rules, and does not click links or submit forms. This preview uses a desktop viewport; use a full page scan for the mobile profile. A successful recheck does not establish full accessibility or compliance. Manual testing of meaning, other page states, and the rest of the page is still required.",
        )}
      </p>
      {error && (
        <p className="bwa-alert bwa-alert--error" role="alert">
          {error}
        </p>
      )}
      {!error && !result && (
        <p role="status">
          <Spinner />
          {t("Checking the rendered element…")}
        </p>
      )}
      {result && (
        <div className="bwa-repair-evidence" role="status">
          <h4>
            {result.status === "passed"
              ? t("Repair rechecked")
              : result.status === "failed"
                ? t("The rendered repair needs attention")
                : t("Recheck could not confirm the repair")}
          </h4>
          <p>{result.reason}</p>
          <p>
            {config.context === "saved draft preview"
              ? t("Saved draft preview")
              : t("Signed-in page")}
          </p>
        </div>
      )}
      <Button secondary onClick={onBack}>
        {t("Return to repairs")}
      </Button>
      {config && (
        <div className="bwa-scan-viewport">
          <iframe
            ref={frame}
            title={t("Saved page used for the repair recheck")}
            src={config.url}
            width="1366"
            height="900"
            style={{ width: 1366, minWidth: 1366, height: 900 }}
            referrerPolicy="same-origin"
          />
        </div>
      )}
    </section>
  );
}

export function ContentRepairs({
  target,
  hint,
  recordId,
  onClose,
  changed,
  rescan,
}) {
  const postId = target.id;
  const [data, setData] = useState(null),
    [selection, setSelection] = useState(null),
    [filter, setFilter] = useState(hint?.kind || "heading");
  const [value, setValue] = useState(""),
    [level, setLevel] = useState(2),
    [prepared, setPrepared] = useState(null);
  const [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [recheck, setRecheck] = useState(null);
  const reviewHeading = useRef(null),
    historyHeading = useRef(null),
    buttons = useRef({});
  const hintHandled = useRef(false);
  async function refresh() {
    const fresh = await api(`/posts/${postId}/content-targets`);
    if (data && fresh.source_hash !== data.source_hash) {
      setSelection(null);
      setPrepared(null);
    }
    setData(fresh);
    return fresh;
  }
  useEffect(() => {
    let alive = true;
    api(`/posts/${postId}/content-targets`)
      .then((fresh) => {
        if (!alive) return;
        setData(fresh);
        if (!hintHandled.current && hint) {
          hintHandled.current = true;
          const item = fresh.targets.find(
            (candidate) => candidate.key === hint.key,
          );
          if (fresh.source_hash === hint.source_hash && item?.editable)
            selectItem(item);
          else
            setError(
              t(
                "The page changed since this finding was recorded. Choose an element from the current repair list.",
              ),
            );
        }
        if (recordId)
          requestAnimationFrame(() => historyHeading.current?.focus());
      })
      .catch((e) => {
        if (alive) setError(e.message);
      });
    return () => {
      alive = false;
    };
  }, [postId]);
  useEffect(() => {
    if (selection) reviewHeading.current?.focus();
  }, [selection?.key]);
  function selectItem(item) {
    setSelection(item);
    setValue(item.text.trim());
    setLevel(item.level || 2);
    setPrepared(null);
    setError("");
    setNotice("");
  }
  function edit(setter, next) {
    setter(next);
    setPrepared(null);
    setNotice("");
  }
  async function preview() {
    if (busy) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      setPrepared(
        await api(`/posts/${postId}/content-repairs`, {
          method: "POST",
          data: {
            source_hash: data.source_hash,
            target: selection.key,
            text: value,
            level: Number(level),
          },
        }),
      );
    } catch (e) {
      setError(e.message);
      setPrepared(null);
    } finally {
      setBusy(false);
    }
  }
  async function write(operation) {
    await wp.apiFetch({
      path: data.rest_path,
      method: "POST",
      headers: { "X-BWA-Repair": operation.id, "X-BWA-Token": operation.token },
      data: { content: operation.after_content },
    });
  }
  async function save() {
    if (busy || !prepared) return;
    setBusy(true);
    setError("");
    const operation = prepared;
    try {
      await write(operation);
      const fresh = await refresh();
      if (
        !fresh.records.some(
          (record) => record.id === operation.id && record.state === "saved",
        )
      )
        throw new Error(
          t(
            "WordPress did not confirm the proposed repair. Reload the saved page before continuing.",
          ),
        );
      setSelection(null);
      setPrepared(null);
      setNotice(t("Repair saved in WordPress. Recheck the saved page next."));
      changed();
      requestAnimationFrame(() => historyHeading.current?.focus());
    } catch (e) {
      setError(e.message);
      setPrepared(null);
      await refresh().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  async function undo(record) {
    if (busy) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const operation = await api(
        `/posts/${postId}/content-repairs/${record.id}/undo`,
        { method: "POST", data: { source_hash: data.source_hash } },
      );
      await write(operation);
      const fresh = await refresh();
      if (
        !fresh.records.some(
          (item) => item.id === record.id && item.state === "undone",
        )
      )
        throw new Error(
          t(
            "WordPress did not confirm undo. Reload the repair list to inspect the saved page.",
          ),
        );
      setSelection(null);
      setPrepared(null);
      setNotice(
        t(
          "Repair undone. The earlier block is restored and other saved blocks are preserved.",
        ),
      );
      changed();
      requestAnimationFrame(() => historyHeading.current?.focus());
    } catch (e) {
      setError(e.message);
      await refresh().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  const items = data?.targets.filter((item) => item.kind === filter) || [];
  return (
    <Modal
      title={t("Repair saved content")}
      onRequestClose={() => {
        if (!busy) onClose();
      }}
      className="bwa-admin-modal bwa-content-modal"
    >
      <div className="bwa-admin bwa-detail" aria-busy={busy}>
        <p className="bwa-kicker">
          {target.title} · {t("Completely free")}
        </p>
        {recheck ? (
          <ContentRecheck
            postId={postId}
            record={recheck}
            onDone={() => {
              refresh().catch((e) => setError(e.message));
              changed();
            }}
            onBack={() => { setRecheck(null); requestAnimationFrame(() => historyHeading.current?.focus()); }}
          />
        ) : (
          <>
            <p>
              {t(
                "Review one saved element, preview its change, then save and recheck. Save any open editor work first. Repairs become part of your page content and remain after the plugin is removed.",
              )}
            </p>
            {error && (
              <p className="bwa-alert bwa-alert--error" role="alert">
                {error}
              </p>
            )}
            {notice && (
              <p className="bwa-repair-evidence" role="status">
                {notice}
              </p>
            )}
            {!data && (
              <p role="status">
                <Spinner />
                {t("Loading saved elements…")}
              </p>
            )}
            {data && (
              <>
                {selection ? (
                  <section className="bwa-content-review">
                    <Button
                      secondary
                      disabled={busy}
                      onClick={() => {
                        const key = selection.key;
                        setSelection(null);
                        setPrepared(null);
                        requestAnimationFrame(() =>
                          buttons.current[key]?.focus(),
                        );
                      }}
                    >
                      {t("Back to elements")}
                    </Button>
                    <h3 ref={reviewHeading} tabIndex="-1">
                      {t("Review")} {kindName(selection.kind).toLowerCase()}
                    </h3>
                    {selection.kind === "heading" && (
                      <>
                        <details className="bwa-outline">
                          <summary>
                            {t("Saved content heading outline")}
                          </summary>
                          <ol>
                            {data.targets
                              .filter((item) => item.kind === "heading")
                              .map((item) => (
                                <li key={item.key}>
                                  H{item.level} ·{" "}
                                  {item.text || t("(empty heading)")}
                                </li>
                              ))}
                          </ol>
                          <p>
                            {t(
                              "The theme may add a page-title heading. Choose a level for the section hierarchy, not its visual size.",
                            )}
                          </p>
                        </details>
                        <label htmlFor="bwa-repair-level">
                          {t("Heading level")}
                        </label>
                        <select
                          id="bwa-repair-level"
                          value={level}
                          disabled={busy}
                          onChange={(e) =>
                            edit(setLevel, Number(e.target.value))
                          }
                        >
                          {[1, 2, 3, 4, 5, 6].map((number) => (
                            <option key={number} value={number}>
                              H{number}
                            </option>
                          ))}
                        </select>
                      </>
                    )}
                    {selection.kind === "link" && (
                      <p className="bwa-link-destination">
                        <strong>{t("Destination stays the same:")}</strong>{" "}
                        <code>{selection.href}</code>
                      </p>
                    )}
                    {selection.kind === "label" && (
                      <p>
                        {t("Control:")}{" "}
                        {selection.field_name ||
                          selection.control_id ||
                          t("(no name or ID)")}{" "}
                        · {selection.field_type}
                        <br />
                        {t(
                          "This changes the visible label and its association. It preserves the control’s name, value, validation attributes, and form action.",
                        )}
                      </p>
                    )}
                    <label htmlFor="bwa-repair-text">
                      {selection.kind === "heading"
                        ? t("Heading text")
                        : selection.kind === "link"
                          ? t("Visible link text")
                          : t("Visible form label")}
                    </label>
                    <textarea
                      id="bwa-repair-text"
                      value={value}
                      maxLength={1000}
                      rows={3}
                      disabled={
                        busy ||
                        (selection.kind === "heading" && !selection.plain)
                      }
                      onChange={(e) => edit(setValue, e.target.value)}
                    />
                    <p className="bwa-muted">
                      {selection.kind === "heading" && !selection.plain
                        ? t(
                            "This heading contains formatting. You can change its level here; edit its wording in Gutenberg to preserve the formatting.",
                          )
                        : selection.kind === "link"
                          ? t(
                              "Describe the destination or action in context. Avoid generic wording such as “click here”.",
                            )
                          : selection.kind === "label"
                            ? t(
                                "Name the information the visitor should enter. A placeholder is not a substitute for a visible label.",
                              )
                            : t(
                                "Describe the section clearly. Heading structure and meaning need your judgment.",
                              )}
                    </p>
                    <div
                      className="bwa-repair-diff"
                      aria-label={t("Proposed repair")}
                    >
                      <div>
                        <h4>{t("Before")}</h4>
                        <p>
                          {selection.kind === "heading" &&
                            `H${selection.level} · `}
                          {selection.text || t("(empty)")}
                        </p>
                      </div>
                      <div>
                        <h4>{t("After")}</h4>
                        <p>
                          {selection.kind === "heading" && `H${level} · `}
                          {value || t("(enter text)")}
                        </p>
                      </div>
                    </div>
                    {prepared && (
                      <>
                        <p role="status">
                          {t(
                            "Preview ready. Only this block will change. Save to apply it.",
                          )}
                        </p>
                        <details>
                          <summary>
                            {t("Inspect the exact block change")}
                          </summary>
                          <h4>{t("Before")}</h4>
                          <pre tabIndex="0">{prepared.before}</pre>
                          <h4>{t("After")}</h4>
                          <pre tabIndex="0">{prepared.after}</pre>
                        </details>
                      </>
                    )}
                    <div className="bwa-detail-actions">
                      <Button
                        secondary
                        aria-disabled={busy}
                        disabled={!value.trim()}
                        onClick={preview}
                      >
                        {t("Preview repair")}
                      </Button>
                      {prepared && (
                        <Button aria-disabled={busy} onClick={save}>
                          {t("Save repair")}
                        </Button>
                      )}
                    </div>
                  </section>
                ) : (
                  <>
                    <div
                      className="bwa-repair-kinds"
                      role="group"
                      aria-label={t("Element type")}
                    >
                      {["heading", "link", "label"].map((kind) => (
                        <Button
                          key={kind}
                          secondary={filter !== kind}
                          aria-pressed={filter === kind}
                          onClick={() => setFilter(kind)}
                        >
                          {kindName(kind)} (
                          {
                            data.targets.filter((item) => item.kind === kind)
                              .length
                          }
                          )
                        </Button>
                      ))}
                    </div>
                    <ul className="bwa-content-targets">
                      {items.map((item) => (
                        <li key={item.key}>
                          <div>
                            <strong>
                              {item.kind === "heading" && `H${item.level} · `}
                              {item.text ||
                                (item.kind === "label"
                                  ? item.field_name ||
                                    item.control_id ||
                                    t("Unlabelled control")
                                  : t("Empty text"))}
                            </strong>
                            <p className="bwa-muted">
                              {item.kind === "link"
                                ? item.href
                                : item.kind === "label"
                                  ? item.field_type
                                  : item.block.replace("core/", "")}
                            </p>
                            {item.reason && <p>{item.reason}</p>}
                          </div>
                          <Button
                            secondary
                            buttonRef={(node) => {
                              buttons.current[item.key] = node;
                            }}
                            disabled={!item.editable || busy}
                            onClick={() => selectItem(item)}
                          >
                            {t("Review")} {kindName(item.kind).toLowerCase()}
                          </Button>
                        </li>
                      ))}
                    </ul>
                    {!items.length && (
                      <p>
                        {t(
                          "No supported elements of this type were found in this page’s saved blocks.",
                        )}
                      </p>
                    )}
                    <p className="bwa-scope-note">
                      {t(
                        "Supported: native Heading blocks, plain-text links in static blocks, and labels in Custom HTML forms. Shared patterns, templates, bound content, and plugin-generated forms need their owning editor. Rich links and wrapping labels are listed for manual review.",
                      )}
                    </p>
                  </>
                )}
                <section
                  className="bwa-content-history"
                  aria-labelledby="bwa-content-history-title"
                >
                  <h3
                    id="bwa-content-history-title"
                    ref={historyHeading}
                    tabIndex="-1"
                  >
                    {t("Saved repairs on this page")}
                  </h3>
                  {!data.records.length && (
                    <p>
                      {t(
                        "Your saved heading, link, and label repairs will appear here.",
                      )}
                    </p>
                  )}
                  {data.records.map((record) => {
                    const active = record.state === "saved" && record.current;
                    const fresh =
                      active &&
                      record.evidence?.source_hash === data.source_hash &&
                      record.evidence?.environment_hash ===
                        data.environment_hash;
                    return (
                      <article key={record.id} className="bwa-content-receipt">
                        <h4>
                          {kindName(record.kind)} · {record.summary}
                        </h4>
                        <p className="bwa-badge">
                          {record.state === "undone"
                            ? t("Undone")
                            : record.state === "save_changed"
                              ? t("Save needs review")
                              : !record.current
                                ? t("Block changed · undo paused")
                                : fresh
                                  ? record.evidence.status
                                  : t("Saved · needs recheck")}
                        </p>
                        <p className="bwa-muted">
                          {new Date(record.created).toLocaleString()}
                        </p>
                        {fresh && <p>{record.evidence.reason}</p>}
                        {active && (
                          <div className="bwa-detail-actions">
                            <Button
                              secondary
                              disabled={busy}
                              onClick={() => setRecheck(record)}
                            >
                              {t("Recheck saved page")}
                            </Button>
                            <Button
                              secondary
                              aria-disabled={busy}
                              onClick={() => undo(record)}
                            >
                              {t("Undo repair")}
                            </Button>
                          </div>
                        )}
                      </article>
                    );
                  })}
                </section>
                <div className="bwa-detail-actions">
                  <Button
                    secondary
                    disabled={busy}
                    onClick={() => {
                      onClose();
                      rescan([target]);
                    }}
                  >
                    {t("Run a full page scan")}
                  </Button>
                  <Button
                    secondary
                    aria-disabled={busy}
                    onClick={() => {
                      if (!busy) {
                        setSelection(null);
                        setPrepared(null);
                        refresh()
                          .then(() => setNotice(t("Repair list refreshed.")))
                          .catch((e) => setError(e.message));
                      }
                    }}
                  >
                    {t("Reload saved elements")}
                  </Button>
                </div>
              </>
            )}
          </>
        )}
      </div>
    </Modal>
  );
}
