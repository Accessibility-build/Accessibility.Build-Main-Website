<?php
return array( 'dependencies' => array( 'wp-api-fetch', 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-data', 'wp-editor', 'wp-element', 'wp-i18n', 'wp-plugins', 'wp-a11y' ), 'version' => 'aefeaef9d783' );
