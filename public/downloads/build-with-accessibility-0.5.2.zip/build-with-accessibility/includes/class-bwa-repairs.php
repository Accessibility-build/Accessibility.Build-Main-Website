<?php
/** Per-post, private repair receipts and optimistic guards around native REST saves. */
defined( 'ABSPATH' ) || exit;

final class BWA_Repairs {
    const PREFIX = '_bwa_repair_';

    public static function error( string $message, int $status = 409 ): WP_Error {
        return new WP_Error( 'bwa_conflict', $message, array( 'status' => $status ) );
    }

    public static function permission( WP_REST_Request $request ) {
        $post = get_post( (int) $request['post_id'] );
        if ( ! $post || ! in_array( $post->post_type, array( 'post', 'page' ), true ) || ! current_user_can( 'edit_post', $post->ID ) ) {
            return self::error( __( 'You do not have permission to repair this post.', 'build-with-accessibility' ), 403 );
        }
        return true;
    }

    public static function routes(): void {
        $base = '/posts/(?P<post_id>\d+)';
        $permission = array( __CLASS__, 'permission' );
        register_rest_route( 'bwa/v1', $base . '/repairs', array(
            array( 'methods' => 'GET', 'callback' => array( __CLASS__, 'listing' ), 'permission_callback' => $permission ),
            array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'prepare' ), 'permission_callback' => $permission ),
        ) );
        $record = $base . '/repairs/(?P<repair_id>[a-f0-9-]{36})';
        register_rest_route( 'bwa/v1', $record . '/undo', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'undo' ), 'permission_callback' => $permission ) );
        register_rest_route( 'bwa/v1', $record . '/recheck', array(
            array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'recheck' ), 'permission_callback' => $permission ),
            array( 'methods' => 'PUT', 'callback' => array( __CLASS__, 'evidence' ), 'permission_callback' => $permission ),
        ) );
    }

    public static function get( int $post_id, string $id ): ?array {
        $record = get_post_meta( $post_id, self::PREFIX . $id, true );
        return is_array( $record ) && isset( $record['id'] ) ? $record : null;
    }

    public static function put( int $post_id, array $record ): void {
        // Metadata APIs unslash input, including serialized HTML and JSON strings.
        update_post_meta( $post_id, self::PREFIX . $record['id'], wp_slash( $record ) );
    }

    public static function listing( WP_REST_Request $request ): array {
        $post = get_post( (int) $request['post_id'] );
        $records = array();
        foreach ( get_post_meta( $post->ID ) as $key => $values ) {
            if ( 0 !== strpos( $key, self::PREFIX ) ) {
                continue;
            }
            $record = maybe_unserialize( $values[0] );
            if ( ! is_array( $record ) || ! isset( $record['id'], $record['after'], $record['path'] ) ) {
                continue;
            }
            // A response lost after saving can be recovered from the actual saved block.
            if ( 'pending' === $record['state'] && BWA_Images::is_current( $post, $record ) && BWA_Images::hash( $post->post_content ) === $record['operation']['next'] ) {
                $record['state'] = 'saved';
                $record['operation'] = null;
                self::put( $post->ID, $record );
            }
            if ( 'pending' === $record['state'] ) {
                continue;
            }
            $record['current'] = BWA_Images::is_current( $post, $record );
            if ( 'saved' === $record['state'] && ! $record['current'] ) {
                $record['display_state'] = 'changed';
            } elseif ( ! empty( $record['evidence'] ) && ( $record['evidence']['source_hash'] !== BWA_Images::hash( $post->post_content ) || ( isset( $record['evidence']['environment_hash'] ) && $record['evidence']['environment_hash'] !== BWA_Audits::environment() ) ) ) {
                $record['display_state'] = 'needs_recheck';
            } else {
                $record['display_state'] = $record['state'];
            }
            unset( $record['operation'], $record['check'] );
            $records[] = $record;
        }
        usort( $records, static fn( $a, $b ) => strcmp( $b['created'], $a['created'] ) );
        return array( 'records' => $records, 'source_hash' => BWA_Images::hash( $post->post_content ) );
    }

    private static function saved_base( WP_REST_Request $request ) {
        $post = get_post( (int) $request['post_id'] );
        $before = $request->get_param( 'before_content' );
        if ( ! is_string( $before ) || strlen( $before ) > 2 * MB_IN_BYTES || BWA_Images::hash( $post->post_content ) !== BWA_Images::hash( $before ) ) {
            return self::error( __( 'The saved post and editor differ. Save existing edits, or reload if another author changed the post, then try again.', 'build-with-accessibility' ) );
        }
        if ( 'auto-draft' === $post->post_status ) {
            return self::error( __( 'Save this draft once before repairing an image.', 'build-with-accessibility' ) );
        }
        return $post;
    }

    public static function operation( string $mode, string $before, string $after ): array {
        return array( 'token' => wp_generate_uuid4(), 'mode' => $mode, 'actor' => get_current_user_id(), 'base' => BWA_Images::hash( $before ), 'next' => BWA_Images::hash( $after ), 'expires' => time() + 300 );
    }

    public static function prepare( WP_REST_Request $request ) {
        $post = self::saved_base( $request );
        if ( is_wp_error( $post ) ) {
            return $post;
        }
        $path = $request->get_param( 'path' );
        $after = $request->get_param( 'after_content' );
        $purpose = $request->get_param( 'purpose' );
        if ( ! BWA_Images::valid_path( $path ) || ! is_string( $after ) || strlen( $after ) > 2 * MB_IN_BYTES || ! is_string( $purpose ) ) {
            return self::error( __( 'The image repair request is incomplete or too large.', 'build-with-accessibility' ), 422 );
        }
        $change = BWA_Images::validate_change( $post->post_content, $after, $path, $purpose );
        if ( is_wp_error( $change ) ) {
            return $change;
        }
        $record = array(
            'id' => wp_generate_uuid4(), 'path' => $path, 'before' => $change['before'], 'after' => $change['after'],
            'purpose' => $purpose, 'alt' => $change['alt'], 'state' => 'pending', 'created' => gmdate( 'c' ),
            'author' => get_current_user_id(), 'evidence' => null,
            'operation' => self::operation( 'apply', $post->post_content, $after ),
        );
        $no_op = $record['operation']['base'] === $record['operation']['next'];
        if ( $no_op ) {
            $record['state'] = 'saved';
            $record['operation'] = null;
        }
        self::put( $post->ID, $record );
        return array( 'id' => $record['id'], 'token' => $record['operation']['token'] ?? null, 'no_op' => $no_op );
    }

    public static function undo( WP_REST_Request $request ) {
        $post = self::saved_base( $request );
        if ( is_wp_error( $post ) ) {
            return $post;
        }
        if ( ! is_string( $request->get_param( 'after_content' ) ) || strlen( $request->get_param( 'after_content' ) ) > 2 * MB_IN_BYTES ) {
            return self::error( __( 'Undo requires a valid proposed content change.', 'build-with-accessibility' ), 422 );
        }
        $record = self::get( $post->ID, (string) $request['repair_id'] );
        if ( ! $record || 'saved' !== $record['state'] || ! BWA_Images::is_current( $post, $record ) ) {
            return self::error( __( 'This image changed after the repair, or the repair was already undone. Undo is paused to protect newer work.', 'build-with-accessibility' ) );
        }
        $before = parse_blocks( $record['before'] )[0];
        $after_content = serialize_blocks( BWA_Images::replace( parse_blocks( $post->post_content ), $record['path'], $before ) );
        if ( BWA_Images::hash( (string) $request->get_param( 'after_content' ) ) !== BWA_Images::hash( $after_content ) ) {
            return self::error( __( 'Undo would change additional content. Reload the saved post and review the image again.', 'build-with-accessibility' ) );
        }
        $record['operation'] = self::operation( 'undo', $post->post_content, $after_content );
        $no_op = $record['operation']['base'] === $record['operation']['next'];
        if ( $no_op ) {
            $record['state'] = 'undone';
            $record['operation'] = null;
            $record['evidence'] = null;
        }
        self::put( $post->ID, $record );
        return array( 'id' => $record['id'], 'token' => $record['operation']['token'] ?? null, 'no_op' => $no_op );
    }

    public static function guard( $prepared, WP_REST_Request $request ) {
        if ( is_wp_error( $prepared ) || ! $request->get_header( 'x-bwa-repair' ) ) {
            return $prepared;
        }
        $id = (int) $request['id'];
        $record = self::get( $id, $request->get_header( 'x-bwa-repair' ) );
        $op = $record['operation'] ?? null;
        $post = get_post( $id );
        if ( ! $post || ! $op || $op['actor'] !== get_current_user_id() || $op['expires'] < time() || ! hash_equals( $op['token'], $request->get_header( 'x-bwa-token' ) ) ) {
            return self::error( __( 'This repair session expired. Review the element again.', 'build-with-accessibility' ) );
        }
        if ( ! empty( $record['kind'] ) ) {
            if ( ! function_exists( 'wp_check_post_lock' ) ) { require_once ABSPATH . 'wp-admin/includes/post.php'; }
            if ( wp_check_post_lock( $id ) || ( ! current_user_can( 'unfiltered_html' ) && isset( $prepared->post_content ) && wp_kses_post( $prepared->post_content ) !== $prepared->post_content ) ) { return self::error( __( 'The page is locked or your current role would remove markup. Reload the repair list before continuing.', 'build-with-accessibility' ) ); }
        }
        if ( BWA_Images::hash( $post->post_content ) !== $op['base'] || ! isset( $prepared->post_content ) || BWA_Images::hash( $prepared->post_content ) !== $op['next'] ) {
            return self::error( __( 'Content changed while the repair was being saved. Nothing was overwritten by this request. Review your current work before trying again.', 'build-with-accessibility' ) );
        }
        return $prepared;
    }

    public static function saved( WP_Post $post, WP_REST_Request $request ): void {
        if ( ! $request->get_header( 'x-bwa-repair' ) ) {
            return;
        }
        $record = self::get( $post->ID, $request->get_header( 'x-bwa-repair' ) );
        $op = $record['operation'] ?? null;
        if ( ! $op || ! hash_equals( $op['token'], $request->get_header( 'x-bwa-token' ) ) ) {
            return;
        }
        $fresh = get_post( $post->ID );
        $record['state'] = BWA_Images::hash( $fresh->post_content ) === $op['next'] ? ( 'undo' === $op['mode'] ? 'undone' : 'saved' ) : 'save_changed';
        $record['updated'] = gmdate( 'c' );
        $record['operation'] = null;
        $record['evidence'] = null;
        self::put( $post->ID, $record );
    }

    public static function recheck( WP_REST_Request $request ) {
        $post = get_post( (int) $request['post_id'] );
        $record = self::get( $post->ID, (string) $request['repair_id'] );
        if ( ! $record || 'saved' !== $record['state'] || ! BWA_Images::is_current( $post, $record ) ) {
            return self::error( __( 'The repaired block changed. Review its current content before rechecking.', 'build-with-accessibility' ) );
        }
        $record['check'] = array( 'token' => wp_generate_uuid4(), 'source_hash' => BWA_Images::hash( $post->post_content ), 'actor' => get_current_user_id(), 'expires' => time() + 300 );
        if ( ! empty( $record['kind'] ) ) { $record['check']['environment_hash'] = BWA_Audits::environment(); }
        self::put( $post->ID, $record );
        $url = is_post_publicly_viewable( $post ) ? get_permalink( $post ) : get_preview_post_link( $post );
        $url = add_query_arg( array(
            'bwa_post' => $post->ID, 'bwa_check' => $record['id'], 'bwa_run' => $record['check']['token'],
            '_bwa_nonce' => wp_create_nonce( 'bwa_check_' . $record['id'] ),
        ), $url );
        return array( 'url' => $url, 'token' => $record['check']['token'], 'context' => is_post_publicly_viewable( $post ) ? 'logged-in page' : 'saved draft preview' );
    }

    public static function evidence( WP_REST_Request $request ) {
        $post = get_post( (int) $request['post_id'] );
        $record = self::get( $post->ID, (string) $request['repair_id'] );
        $check = $record['check'] ?? null;
        if ( ! $check || ! is_string( $request->get_param( 'token' ) ) || $check['actor'] !== get_current_user_id() || $check['expires'] < time() || ! hash_equals( $check['token'], $request->get_param( 'token' ) ) || $check['source_hash'] !== BWA_Images::hash( $post->post_content ) || 'saved' !== $record['state'] ) {
            return self::error( __( 'The page changed or this recheck expired. Run the recheck again.', 'build-with-accessibility' ) );
        }
        $result = $request->get_param( 'result' );
        if ( isset( $check['environment_hash'] ) && $check['environment_hash'] !== BWA_Audits::environment() ) { return self::error( __( 'The site configuration changed during this recheck. Run it again.', 'build-with-accessibility' ) ); }
        if ( ! is_array( $result ) || ! is_string( $result['reason'] ?? null ) || ! in_array( $result['status'] ?? '', array( 'passed', 'failed', 'inconclusive' ), true ) ) {
            return self::error( __( 'The browser did not return a valid recheck.', 'build-with-accessibility' ), 422 );
        }
        $record['evidence'] = array(
            'status' => $result['status'], 'reason' => sanitize_text_field( substr( (string) ( $result['reason'] ?? '' ), 0, 1000 ) ),
            'source_hash' => $check['source_hash'], 'checked_at' => gmdate( 'c' ), 'method' => empty( $record['kind'] ) ? 'rendered_image_alternative' : 'rendered_' . $record['kind'],
            'context' => is_post_publicly_viewable( $post ) ? 'logged-in page' : 'saved draft preview',
        );
        $record['check'] = null;
        if ( isset( $check['environment_hash'] ) ) { $record['evidence']['environment_hash'] = $check['environment_hash']; }
        self::put( $post->ID, $record );
        return $record['evidence'];
    }
}
