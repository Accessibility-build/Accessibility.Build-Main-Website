import { ContentRepairs } from "./content-repairs.jsx";
import { BaselineComparison, RecheckInbox } from "./monitoring.jsx";
import { ManualSessions, ManualExports } from "./manual-sessions.jsx";
import { ScrollableTable } from "./scrollable-table.jsx";
const { useEffect, useMemo, useRef, useState, createRoot } = wp.element;
const { Modal, Spinner } = wp.components;
const api = (path, options = {}) =>
  wp.apiFetch({ path: `/bwa/v1${path}`, ...options });
const t = (text) => wp.i18n.__(text, "build-with-accessibility");
const date = (value) =>
  value
    ? new Date(value.replace(" ", "T")).toLocaleString()
    : t("Not yet scanned");
const profileName = (profile) =>
  profile === "all" ? t("All enabled axe rules") : t("WCAG 2.2 A / AA");
const queueKey = `bwa:queue:${bwaAdmin.siteUrl}:${bwaAdmin.userId}`;
const sections = [
  ["overview", "Overview"],
  ["pages", "Pages"],
  ["recheck", "Pages to recheck"],
  ["issues", "Issues"],
  ["manual", "Manual checks"],
  ["repairs", "Repair history"],
  ["reports", "Reports"],
  ["settings", "Settings"],
];
const manualChecks = [
  [
    "keyboard",
    "Keyboard operation",
    "Use Tab, Shift+Tab, Enter, Space, and arrow keys. Can you use navigation, menus, dialogs, and every essential control without a mouse? Check that focus never gets trapped.",
  ],
  [
    "focus",
    "Focus and reading order",
    "Follow the focus indicator through the page. It should stay visible, follow a meaningful order, and avoid being covered by sticky headers or dialogs.",
  ],
  [
    "zoom",
    "Zoom and reflow",
    "Zoom text to 200% and the page to 400% on a desktop browser. Check for clipped content, overlapping controls, and unnecessary horizontal scrolling.",
  ],
  [
    "screen_reader",
    "Screen-reader experience",
    "Use a screen reader to navigate headings, landmarks, links, and forms. Check names, order, status announcements, and whether the page makes sense without its visual layout.",
  ],
  [
    "forms",
    "Forms and error recovery",
    "Test labels, required fields, instructions, invalid input, and correction. Errors should be understandable and associated with the right field. Test safely without real purchases or submissions.",
  ],
  [
    "meaning",
    "Images, links, and meaning",
    "Review image alternatives in context, meaningful link text, headings, instructions, and information conveyed using color. Empty alternatives can be correct for decorative images.",
  ],
  [
    "media",
    "Media and motion",
    "Check captions and relevant audio descriptions for media. Check controls for motion, autoplay, and time limits, including reduced-motion preferences.",
  ],
  [
    "dynamic",
    "Menus, dialogs, and other states",
    "Open menus, dialogs, accordions, tabs, and validation messages. Check their keyboard behavior, names, and announcements. An initial-page scan does not exercise these states.",
  ],
];

function useResource(path, tick = 0) {
  const [state, setState] = useState({ data: null, loading: true, error: "" });
  useEffect(() => {
    let alive = true;
    setState((old) => ({ ...old, loading: true, error: "" }));
    api(path)
      .then((data) => {
        if (alive) setState({ data, loading: false, error: "" });
      })
      .catch((error) => {
        if (alive)
          setState({ data: null, loading: false, error: error.message });
      });
    return () => {
      alive = false;
    };
  }, [path, tick]);
  return state;
}

function Button({ children, secondary, subtle, danger, ...props }) {
  return (
    <button
      type="button"
      className={`bwa-button ${secondary ? "bwa-button--secondary" : ""} ${subtle ? "bwa-button--subtle" : ""} ${danger ? "bwa-button--danger" : ""}`}
      {...props}
    >
      {children}
    </button>
  );
}
function Badge({ children, tone = "" }) {
  return <span className={`bwa-badge bwa-badge--${tone}`}>{children}</span>;
}
function ErrorNotice({ message }) {
  return message ? (
    <div className="bwa-alert bwa-alert--error" role="alert">
      {message}
    </div>
  ) : null;
}
function Loading() {
  return (
    <p className="bwa-loading" role="status">
      <Spinner />
      {t("Loading…")}
    </p>
  );
}
function Empty({ title, children }) {
  return (
    <div className="bwa-empty">
      <h2>{title}</h2>
      <p>{children}</p>
    </div>
  );
}
function Pagination({ data, change }) {
  const requested = useRef(null);
  const status = useRef(null);
  useEffect(() => {
    if (requested.current !== null && data?.page === requested.current) {
      status.current?.focus();
      requested.current = null;
    }
  }, [data]);
  function go(page) { requested.current = page; change(page); }
  return (
    data?.pages > 1 && (
      <nav className="bwa-pagination" aria-label={t("Results pages")}>
        <Button
          secondary
          disabled={data.page <= 1}
          onClick={() => go(data.page - 1)}
        >
          {t("Previous")}
        </Button>
        <span ref={status} tabIndex="-1">
          {t("Page")} {data.page} / {data.pages}
        </span>
        <Button
          secondary
          disabled={data.page >= data.pages}
          onClick={() => go(data.page + 1)}
        >
          {t("Next")}
        </Button>
      </nav>
    )
  );
}
function Freshness({ fresh }) {
  return (
    <Badge tone={fresh ? "teal" : "amber"}>
      {fresh ? t("Recorded page state") : t("Changed · rescan")}
    </Badge>
  );
}
function Summary({ summary }) {
  return (
    <span>
      <strong>{summary.violations}</strong> {t("findings")}{" "}
      <span className="bwa-muted">
        · {summary.incomplete} {t("need review")}
      </span>
    </span>
  );
}

function Overview({ tick, navigate, queueAll, busy, openIssue, viewReport }) {
  const { data, loading, error } = useResource("/workspace", tick);
  if (!data) return error ? <ErrorNotice message={error} /> : <Loading />;
  const { totals } = data;
  return (
    <div aria-busy={loading}>
      <div className="bwa-overview-intro">
        <div>
          <p className="bwa-kicker">
            {t("Your site, one improvement at a time")}
          </p>
          <h2>
            {totals.scanned
              ? t("Turn findings into better experiences.")
              : t("Start with what your visitors experience.")}
          </h2>
          <p>
            {t(
              "Monitor saved pages for detectable barriers, review changes, and keep evidence of the repairs you verify.",
            )}
          </p>
        </div>
        <Button onClick={queueAll} disabled={busy}>
          {t("Scan all pages")}
        </Button>
      </div>
      <section className="bwa-scope-note" aria-labelledby="bwa-monitoring-scope">
        <h3 id="bwa-monitoring-scope">{t("Monitoring supports accessibility. It does not certify it.")}</h3>
        <p>{t("This plugin does not make a website fully accessible or compliant. If your site has already been evaluated and made accessible, repeat scans after changes can help catch detectable regressions. They cannot guarantee that it stays accessible.")}</p>
        <p>{t("Manual keyboard, screen-reader, zoom, content, and interaction testing are still required, even when a scan finds no issues. Establish a manual baseline and repeat the relevant tests after changes. Scans run while this admin tab is open; there is no unattended background monitor.")}</p>
        <Button secondary onClick={() => navigate("manual")}>{t("Plan and record manual testing")}</Button>
      </section>
      <div className="bwa-metrics" aria-label={t("Latest scan totals")}>
        {[
          [`${totals.scanned} / ${totals.pages}`, "Pages scanned"],
          [totals.violations, "Automated findings"],
          [totals.incomplete, "Need human review"],
          [totals.stale, "Pages need a rescan"],
        ].map(([value, label]) => (
          <div key={label}>
            <strong>{value}</strong>
            <span>{t(label)}</span>
          </div>
        ))}
      </div>
      <div className="bwa-coverage">
        <div>
          <Badge tone="blue">{t("Automated")}</Badge>
          <h3>{t("Find detectable barriers")}</h3>
          <p>
            axe-core {bwaAdmin.axeVersion} ·{" "}
            {profileName(data.settings.profile)}
          </p>
          <Button subtle onClick={() => navigate("pages")}>
            {t("Choose pages to scan")} →
          </Button>
        </div>
        <div>
          <Badge tone="amber">{t("Human review")}</Badge>
          <h3>{t("Check the lived experience")}</h3>
          <p>
            {t("Keyboard, screen reader, content meaning, and dynamic states.")}
          </p>
          <Button subtle onClick={() => navigate("manual")}>
            {t("Open guided manual testing")} →
          </Button>
        </div>
        <div>
          <Badge tone="teal">{t("Repair & verify")}</Badge>
          <h3>{t("Make changes that last")}</h3>
          <p>
            {t(
              "Guided image, heading, link, and form-label repairs with recheck and guarded undo.",
            )}
          </p>
          <Button subtle onClick={() => navigate("repairs")}>
            {t("View repair history")} →
          </Button>
        </div>
      </div>
      <section className="bwa-surface bwa-recheck-prompt">
        <div><h2>{t("Keep up with changes")}</h2><p>{t("Find pages that need another check after content, theme, plugin, or scan-setting changes. Compare later reports with a baseline you choose.")}</p></div>
        <Button secondary onClick={() => navigate("recheck")}>{t("Open pages to recheck")}</Button>
      </section>
      <div className="bwa-two-columns">
        <section className="bwa-surface">
          <div className="bwa-section-heading">
            <h2>{t("Where to focus next")}</h2>
            <Button subtle onClick={() => navigate("issues")}>
              {t("All issues")}
            </Button>
          </div>
          {data.priority.length ? (
            <ul className="bwa-priority-list">
              {data.priority.map((item) => (
                <li key={item.id}>
                  <Badge tone={item.impact}>{item.impact}</Badge>
                  <button type="button" onClick={() => openIssue(item)}>
                    <strong>{item.details.help}</strong>
                    <span>
                      {item.target.title} · {item.rule_id}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="bwa-muted">
              {totals.scanned
                ? t(
                    "No open findings in the latest stored scans. Continue with manual checks and other page states.",
                  )
                : t(
                    "Your first scan will bring the most important findings here.",
                  )}
            </p>
          )}
        </section>
        <section className="bwa-surface">
          <div className="bwa-section-heading">
            <h2>{t("Recent scans")}</h2>
            <Button subtle onClick={() => navigate("reports")}>
              {t("All reports")}
            </Button>
          </div>
          {data.recent.length ? (
            <ul className="bwa-recent-list">
              {data.recent.map((scan) => (
                <li key={scan.id}>
                  <button type="button" onClick={() => viewReport(scan.id)}>
                    <strong>{scan.target.title}</strong>
                    <span>{date(scan.created_at)}</span>
                  </button>
                  {scan.status === "failed" ? (
                    <Badge tone="critical">{t("Could not scan")}</Badge>
                  ) : (
                    <Summary summary={scan.summary} />
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <p className="bwa-muted">
              {t(
                "Scans are saved on this WordPress site. No account or credits are needed.",
              )}
            </p>
          )}
        </section>
      </div>
      <p className="bwa-scope-note">
        {t(
          "Counts describe the latest stored scan for each page, including stale results. Automated checks cannot establish complete accessibility or legal conformance.",
        )}
      </p>
    </div>
  );
}

function Pages({
  tick,
  enqueue,
  queueAll,
  busy,
  showIssues,
  reviewPage,
  viewReport,
  repairPage,
}) {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState({});
  const { data, loading, error } = useResource(
    `/targets?page=${page}&search=${encodeURIComponent(query)}`,
    tick,
  );
  const items = data?.items || [];
  return (
    <>
      <div className="bwa-toolbar">
        <form
          role="search"
          onSubmit={(event) => {
            event.preventDefault();
            setPage(1);
            setQuery(search);
          }}
        >
          <label htmlFor="bwa-page-search">{t("Find a page")}</label>
          <div className="bwa-inline">
            <input
              id="bwa-page-search"
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <Button secondary type="submit">
              {t("Search")}
            </Button>
          </div>
        </form>
        <div className="bwa-inline">
          <Button
            secondary
            disabled={!Object.keys(selected).length || busy}
            onClick={() => {
              enqueue(Object.values(selected));
              setSelected({});
            }}
          >
            {t("Scan selected")} ({Object.keys(selected).length})
          </Button>
          <Button disabled={busy} onClick={queueAll}>
            {t("Scan all pages")}
          </Button>
        </div>
      </div>
      <ErrorNotice message={error} />
      {loading && !data && <Loading />}
      {data && (
        <ScrollableTable label={t("Pages table")} aria-busy={loading}>
          <table className="bwa-table">
            <caption>
              {data.total}{" "}
              {t(
                "pages available for scanning, including the homepage and saved previews",
              )}
            </caption>
            <thead>
              <tr>
                <th scope="col">
                  <input
                    type="checkbox"
                    aria-label={t("Select pages on this results page")}
                    checked={
                      items.length > 0 &&
                      items.every((item) => selected[item.key])
                    }
                    onChange={(e) =>
                      setSelected((old) => {
                        const next = { ...old };
                        items.forEach((item) =>
                          e.target.checked
                            ? (next[item.key] = item)
                            : delete next[item.key],
                        );
                        return next;
                      })
                    }
                  />
                </th>
                <th scope="col">{t("Page")}</th>
                <th scope="col">{t("Last scan")}</th>
                <th scope="col">{t("Findings")}</th>
                <th scope="col">{t("Actions")}</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.key}>
                  <td>
                    <input
                      type="checkbox"
                      aria-label={`${t("Select")} ${item.title}`}
                      checked={!!selected[item.key]}
                      onChange={(e) =>
                        setSelected((old) => {
                          const next = { ...old };
                          e.target.checked
                            ? (next[item.key] = item)
                            : delete next[item.key];
                          return next;
                        })
                      }
                    />
                  </td>
                  <th scope="row">
                    <strong>{item.title}</strong>
                    <span className="bwa-cell-meta">
                      {item.type} · {item.status}
                    </span>
                  </th>
                  <td>
                    {item.last_attempt?.status === "failed" ? (
                      <>
                        <Badge tone="critical">
                          {t("Last attempt failed")}
                        </Badge>
                        <span className="bwa-cell-meta">
                          {date(item.last_attempt.created_at)}
                        </span>
                      </>
                    ) : item.scan ? (
                      <>
                        <Freshness fresh={item.scan.fresh} />
                        <span className="bwa-cell-meta">
                          {date(item.scan.created_at)} · {item.scan.viewport}
                        </span>
                      </>
                    ) : (
                      <Badge>{t("Not scanned")}</Badge>
                    )}
                  </td>
                  <td>
                    {item.scan ? (
                      <button
                        className="bwa-text-button"
                        onClick={() => showIssues(item.key)}
                      >
                        <Summary summary={item.scan.summary} />
                        {item.last_attempt?.status === "failed" && (
                          <span className="bwa-cell-meta">
                            {t("Previous completed scan")}
                          </span>
                        )}
                      </button>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td>
                    <div className="bwa-table-actions">
                      <Button
                        secondary
                        disabled={busy}
                        onClick={() => enqueue([item])}
                      >
                        {t("Scan page")}
                      </Button>
                      {(item.scan || item.last_attempt) && (
                        <Button
                          subtle
                          onClick={() =>
                            viewReport(item.last_attempt?.id || item.scan.id)
                          }
                        >
                          {t("Report")}
                        </Button>
                      )}
                      <Button subtle onClick={() => reviewPage(item.key)}>
                        {t("Manual review")}
                      </Button>
                      {["post", "page"].includes(item.type) && (
                        <Button
                          subtle
                          onClick={() => repairPage({ target: item })}
                        >
                          {t("Repair content")}
                        </Button>
                      )}
                      {item.edit_url && (
                        <a href={item.edit_url}>{t("Edit page")} ↗</a>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!items.length && (
            <Empty title={t("No matching pages")}>
              {t("Try a different title or create a page in WordPress.")}
            </Empty>
          )}
        </ScrollableTable>
      )}
      <Pagination data={data} change={setPage} />
      <p className="bwa-scope-note">
        {t(
          "Scans include the rendered header, footer, theme, and page content. Published pages are scanned while signed in; drafts use saved previews. Archives and interactive states outside this inventory need separate evaluation.",
        )}
      </p>
    </>
  );
}

function download(name, data, type) {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function csvCell(value) {
  let text = String(value ?? "");
  if (/^[\s]*[=+\-@]/.test(text) || /^[\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

function Issues({ tick, filters, setFilters, openIssue }) {
  const [page, setPage] = useState(1);
  const [exporting, setExporting] = useState(false);
  const [exportError, setExportError] = useState("");
  const parameters = new URLSearchParams(filters).toString();
  const { data, loading, error } = useResource(
    `/issues?${parameters}&page=${page}`,
    tick,
  );
  useEffect(() => setPage(1), [parameters]);
  const set = (key, value) => setFilters((old) => ({ ...old, [key]: value }));
  async function exportCsv() {
    setExporting(true);
    setExportError("");
    try {
      const rows = [
        [
          "Page",
          "Page URL",
          "Rule",
          "Impact",
          "Result",
          "Review decision",
          "Summary",
          "Element",
          "Notes",
          "Scan date",
          "Evidence state",
          "Assessment scope",
        ],
      ];
      let current = 1;
      let pages = 1;
      do {
        const response = await api(
          `/issues?${parameters}&per_page=200&page=${current}`,
        );
        pages = response.pages;
        for (const item of response.items)
          rows.push([
            item.target.title,
            item.target.url,
            item.rule_id,
            item.impact,
            item.kind,
            item.disposition,
            item.details.help,
            JSON.stringify(item.details.target),
            item.note,
            item.created_at,
            item.fresh ? "Recorded page state" : "Stale",
            "Automated findings only. Manual testing is required. Accessibility and legal compliance are not established by this export.",
          ]);
        current++;
      } while (current <= pages);
      download(
        "accessibility-findings.csv",
        "\uFEFF" + rows.map((row) => row.map(csvCell).join(",")).join("\r\n"),
        "text/csv;charset=utf-8",
      );
    } catch (e) {
      setExportError(e.message);
    } finally {
      setExporting(false);
    }
  }
  return (
    <>
      <div className="bwa-toolbar bwa-filters">
        <label>
          {t("Find a rule or element")}
          <input
            type="search"
            value={filters.search || ""}
            onChange={(e) => set("search", e.target.value)}
          />
        </label>
        <label>
          {t("Impact")}
          <select
            value={filters.impact || ""}
            onChange={(e) => set("impact", e.target.value)}
          >
            <option value="">{t("All impacts")}</option>
            {["critical", "serious", "moderate", "minor", "unknown"].map(
              (value) => (
                <option key={value}>{value}</option>
              ),
            )}
          </select>
        </label>
        <label>
          {t("Result")}
          <select
            value={filters.kind || ""}
            onChange={(e) => set("kind", e.target.value)}
          >
            <option value="">{t("Findings & review")}</option>
            <option value="violations">{t("Automated findings")}</option>
            <option value="incomplete">{t("Needs human review")}</option>
          </select>
        </label>
        <label>
          {t("Decision")}
          <select
            value={filters.disposition || ""}
            onChange={(e) => set("disposition", e.target.value)}
          >
            <option value="">{t("All decisions")}</option>
            <option value="open">{t("Open")}</option>
            <option value="accepted">{t("Accepted with reason")}</option>
            <option value="false_positive">{t("Disputed finding")}</option>
          </select>
        </label>
        <Button
          secondary
          onClick={exportCsv}
          disabled={exporting || !data?.total}
        >
          {exporting ? t("Exporting…") : t("Export filtered CSV")}
        </Button>
      </div>
      {filters.target_key && (
        <p className="bwa-filter-note">
          {t("Showing one page.")}{" "}
          <Button subtle onClick={() => set("target_key", "")}>
            {t("Show all pages")}
          </Button>
        </p>
      )}
      <ErrorNotice message={error || exportError} />
      {loading && !data && <Loading />}
      {data && (
        <ScrollableTable label={t("Issues table")} aria-busy={loading}>
          <table className="bwa-table">
            <caption>
              {data.total}{" "}
              {t(
                "matching findings from the latest completed scan of each page",
              )}
            </caption>
            <thead>
              <tr>
                <th scope="col">{t("Impact")}</th>
                <th scope="col">{t("Finding")}</th>
                <th scope="col">{t("Page")}</th>
                <th scope="col">{t("Evidence")}</th>
                <th scope="col">{t("Review")}</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((item) => (
                <tr key={item.id}>
                  <td>
                    <Badge tone={item.impact}>{item.impact}</Badge>
                  </td>
                  <th scope="row">
                    <button
                      className="bwa-text-button"
                      onClick={() => openIssue(item)}
                    >
                      {item.details.help}
                    </button>
                    <span className="bwa-cell-meta bwa-mono">
                      {item.rule_id}
                    </span>
                    {item.kind === "incomplete" && (
                      <Badge tone="amber">{t("Needs human review")}</Badge>
                    )}
                  </th>
                  <td>{item.target.title}</td>
                  <td>
                    <Freshness fresh={item.fresh} />
                  </td>
                  <td>
                    <Badge tone={item.disposition === "open" ? "" : "blue"}>
                      {item.disposition === "open"
                        ? t("Open")
                        : item.disposition === "accepted"
                          ? t("Accepted")
                          : t("Disputed")}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!data.items.length && (
            <Empty title={t("No matching findings")}>
              {t(
                "Run a scan or change the filters. A clear automated result still needs human review.",
              )}
            </Empty>
          )}
        </ScrollableTable>
      )}
      <Pagination data={data} change={setPage} />
      <p className="bwa-scope-note">
        {t(
          "Each row represents a rule and an affected element. Accepting or disputing a finding records a decision; it does not mark the page accessible. A rescan determines whether the issue is still detected.",
        )}
      </p>
    </>
  );
}

function IssueDetail({ item, onClose, changed, enqueue, repairPage }) {
  const [disposition, setDisposition] = useState(item.disposition);
  const [note, setNote] = useState(item.note);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  async function save(event) {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      await api(`/issues/${item.id}`, {
        method: "PATCH",
        data: { disposition, note },
      });
      setSaved(true);
      changed();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      title={item.details.help}
      onRequestClose={onClose}
      className="bwa-admin-modal"
    >
      <div className="bwa-admin bwa-detail">
        <div className="bwa-inline">
          <Badge tone={item.impact}>{item.impact}</Badge>
          <Badge>{item.rule_id}</Badge>
          <Freshness fresh={item.fresh} />
        </div>
        <p>{item.details.description}</p>
        <p>
          <strong>{t("Page:")}</strong> {item.target.title}
        </p>
        <div className="bwa-rule-tags">
          {item.details.tags
            .filter((tag) => /^(wcag|best-practice)/.test(tag))
            .map((tag) => (
              <Badge key={tag}>{tag}</Badge>
            ))}
        </div>
        <h3>{t("What needs attention")}</h3>
        <p className="bwa-preserve">
          {item.details.failureSummary ||
            t(
              "This result needs human evaluation. Read the rule guidance and inspect the element in context.",
            )}
        </p>
        <h3>{t("Affected element")}</h3>
        <pre tabIndex="0" aria-label={t("Element selector")}>
          <code>{JSON.stringify(item.details.target, null, 2)}</code>
        </pre>
        <pre tabIndex="0" aria-label={t("Element HTML snippet")}>
          <code>{item.details.html}</code>
        </pre>
        <a
          href={item.details.helpUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          {t("Read the rule and repair guidance at Deque")} ↗
        </a>
        <div className="bwa-detail-actions">
          {item.content_repair && (
            <Button
              onClick={() => {
                onClose();
                repairPage({ target: item.target, hint: item.content_repair });
              }}
            >
              {item.content_repair.kind === "heading"
                ? t("Repair heading")
                : item.content_repair.kind === "link"
                  ? t("Repair link")
                  : t("Repair form label")}
            </Button>
          )}
          {item.repair_url ? (
            <a className="bwa-button" href={item.repair_url}>
              {t("Open image repair")}
            </a>
          ) : (
            item.target.edit_url && (
              <a className="bwa-button" href={item.target.edit_url}>
                {t("Open page editor")}
              </a>
            )
          )}
          <Button
            secondary
            onClick={() => {
              onClose();
              enqueue([item.target]);
            }}
          >
            {t("Rescan page")}
          </Button>
        </div>
        <p className="bwa-muted">
          {item.repair_url
            ? t(
                "This element maps to a native Gutenberg Image block. Review its purpose before saving a repair.",
              )
            : t(
                "This element may belong to page content, a theme, or another plugin. Use its owning editor or settings; source ownership has not been verified for an automatic repair.",
              )}
        </p>
        <hr />
        <h3>{t("Record a review decision")}</h3>
        <label htmlFor="bwa-issue-decision">{t("Decision")}</label>
        <select
          id="bwa-issue-decision"
          value={disposition}
          onChange={(e) => {
            setDisposition(e.target.value);
            setSaved(false);
          }}
          disabled={!item.fresh || busy}
        >
          <option value="open">{t("Keep open")}</option>
          <option value="accepted">{t("Accept with a reason")}</option>
          <option value="false_positive">{t("Dispute this finding")}</option>
        </select>
        <label htmlFor="bwa-issue-note">{t("Reason and evidence")}</label>
        <textarea
          id="bwa-issue-note"
          value={note}
          onChange={(e) => {
            setNote(e.target.value);
            setSaved(false);
          }}
          rows="3"
          maxLength="2000"
          disabled={!item.fresh || busy}
        />
        <ErrorNotice message={error} />
        {saved && (
          <p role="status" className="bwa-success">
            {t("Review decision saved.")}
          </p>
        )}
        <Button
          onClick={save}
          aria-disabled={busy}
          disabled={!item.fresh || (disposition !== "open" && !note.trim())}
        >
          {busy ? t("Saving…") : t("Save decision")}
        </Button>
      </div>
    </Modal>
  );
}

function Repairs({ tick, repairPage }) {
  const [page, setPage] = useState(1);
  const { data, loading, error } = useResource(
    `/repair-history?page=${page}`,
    tick,
  );
  return (
    <>
      <p className="bwa-section-description">
        {t(
          "Repairs are saved in WordPress content. Review heading, link, and form-label repairs here; image repairs open in Gutenberg. Recheck the saved result or undo while the repaired block still matches.",
        )}
      </p>
      <ErrorNotice message={error} />
      {loading && !data && <Loading />}
      {data?.items.length ? (
        <ScrollableTable label={t("Repair history table")}>
          <table className="bwa-table">
            <caption>{t("Recorded content repairs")}</caption>
            <thead>
              <tr>
                <th scope="col">{t("Page / repair")}</th>
                <th scope="col">{t("Repair state")}</th>
                <th scope="col">{t("Rendered recheck")}</th>
                <th scope="col">{t("Actions")}</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((record) => (
                <tr key={record.id}>
                  <th scope="row">
                    {record.target.title}
                    <span className="bwa-cell-meta">
                      {record.purpose === "decorative"
                        ? t("Confirmed decorative")
                        : record.summary || record.alt}
                      {record.kind !== "image" && ` · ${record.kind}`}
                    </span>
                    <span className="bwa-cell-meta">
                      {date(record.created)}
                    </span>
                  </th>
                  <td>
                    <Badge>
                      {record.state === "undone"
                        ? t("Undone")
                        : record.current
                          ? t("Saved")
                          : t("Block changed · undo paused")}
                    </Badge>
                  </td>
                  <td>
                    {record.state === "undone" ? (
                      t("Undone")
                    ) : record.current &&
                      record.evidence &&
                      record.evidence_fresh ? (
                      <Badge
                        tone={
                          record.evidence.status === "passed" ? "teal" : "amber"
                        }
                      >
                        {record.evidence.status}
                      </Badge>
                    ) : (
                      t("Needs recheck")
                    )}
                  </td>
                  <td>
                    {record.kind !== "image" ? (
                      <Button
                        secondary
                        onClick={() =>
                          repairPage({
                            target: record.target,
                            recordId: record.id,
                          })
                        }
                      >
                        {t("Review repair")}
                      </Button>
                    ) : (
                      <a
                        className="bwa-button bwa-button--secondary"
                        href={record.target.edit_url}
                      >
                        {t("Open image repairs")}
                      </a>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </ScrollableTable>
      ) : (
        data && (
          <Empty title={t("Your first verified repair belongs here")}>
            {t(
              "Choose Repair content from Pages to review headings, links, or form labels. Native image repairs are available in Gutenberg. Every repair keeps its recheck and undo connected to the page.",
            )}
          </Empty>
        )
      )}
      <Pagination data={data} change={setPage} />
    </>
  );
}

function Reports({ tick, reportId, viewReport, changed }) {
  const [page, setPage] = useState(1);
  const { data, loading, error } = useResource(`/scans?page=${page}`, tick);
  if (reportId) return <Report key={reportId} id={reportId} tick={tick} changed={changed} back={() => viewReport(null)} />;
  return (
    <>
      <p className="bwa-section-description">
        {t(
          "Inspect scan history, download complete JSON evidence, or print a report. CSV exports for the latest findings are available in Issues.",
        )}
      </p>
      <ErrorNotice message={error} />
      {loading && !data && <Loading />}
      {data?.items.length ? (
        <ScrollableTable label={t("Reports table")}>
          <table className="bwa-table">
            <caption>
              {data.total} {t("stored scan reports")}
            </caption>
            <thead>
              <tr>
                <th scope="col">{t("Page")}</th>
                <th scope="col">{t("Scan context")}</th>
                <th scope="col">{t("Results")}</th>
                <th scope="col">{t("Report")}</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((scan) => (
                <tr key={scan.id}>
                  <th scope="row">
                    {scan.target.title}
                    <span className="bwa-cell-meta">
                      {date(scan.created_at)}
                    </span>
                  </th>
                  <td>
                    {profileName(scan.profile)}
                    <span className="bwa-cell-meta">
                      {scan.viewport} · {scan.target.context}
                    </span>
                  </td>
                  <td>
                    {scan.status === "failed" ? (
                      <Badge tone="critical">{t("Could not scan")}</Badge>
                    ) : (
                      <>
                        <Summary summary={scan.summary} />
                        <span className="bwa-cell-meta">
                          <Freshness fresh={scan.fresh} />
                        </span>
                      </>
                    )}
                  </td>
                  <td>
                    <Button secondary onClick={() => viewReport(scan.id)}>
                      {t("View report")}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </ScrollableTable>
      ) : (
        data && (
          <Empty title={t("No reports yet")}>
            {t(
              "Scan a page to save its findings, rule results, and test context here.",
            )}
          </Empty>
        )
      )}
      <Pagination data={data} change={setPage} />
    </>
  );
}

function Report({ id, back, tick, changed }) {
  const { data, error } = useResource(`/scans/${id}`);
  if (!data) return error ? <ErrorNotice message={error} /> : <Loading />;
  return (
    <article className="bwa-report">
      <div className="bwa-toolbar bwa-no-print">
        <Button subtle onClick={back}>
          ← {t("All reports")}
        </Button>
        <div className="bwa-inline">
          <Button
            secondary
            onClick={() =>
              download(
                `accessibility-report-${id}.json`,
                JSON.stringify(data, null, 2),
                "application/json",
              )
            }
          >
            {t("Download JSON")}
          </Button>
          <Button onClick={() => window.print()}>
            {t("Print / save PDF")}
          </Button>
        </div>
      </div>
      <div className="bwa-report-title">
        <p className="bwa-kicker">
          Accessibility.build · {t("Accessibility report")}
        </p>
        <h2>{data.target.title}</h2>
        <p>{data.report.context.target.url}</p>
        <p>
          {date(data.created_at)} · axe-core{" "}
          {data.report.engine?.version || t("not completed")} ·{" "}
          {profileName(data.profile)} · {data.viewport}
        </p>
        <Freshness fresh={data.fresh} />
      </div>
      <p className="bwa-scope-note">
        {data.report.context.scope}{" "}
        {t(
          "This report supports monitoring and repair; it does not establish full accessibility or legal compliance. Zero automated findings does not mean an accessible site. Manual keyboard, screen-reader, zoom, content, and interaction testing are still required. Results describe the recorded signed-in browser state and viewport; later changes need another review.",
        )}
      </p>
      <BaselineComparison report={data} tick={tick} changed={changed} />
      {data.status === "failed" ? (
        <ErrorNotice message={data.report.error} />
      ) : (
        <>
          <div className="bwa-metrics">
            {[
              [data.summary.violations, "Automated findings"],
              [data.summary.incomplete, "Need human review"],
              [data.summary.passed_rules, "Rules with passing elements"],
              [data.summary.inapplicable_rules, "Rules not applicable"],
            ].map(([value, label]) => (
              <div key={label}>
                <strong>{value}</strong>
                <span>{t(label)}</span>
              </div>
            ))}
          </div>
          {data.report.frames.unavailable > 0 && (
            <p className="bwa-alert">
              {data.report.frames.unavailable}{" "}
              {t(
                "embedded frames could not load the checker and need separate review.",
              )}
            </p>
          )}
          {[
            ["violations", "Automated findings"],
            ["incomplete", "Needs human review"],
            ["passes", "Passing elements by rule"],
            ["inapplicable", "Not applicable"],
          ].map(([kind, label]) => (
            <section className="bwa-surface bwa-report-section" key={kind}>
              <h3>
                {t(label)} ({data.report[kind].length})
              </h3>
              {!data.report[kind].length ? (
                <p>{t("No rules in this category for this scan.")}</p>
              ) : (
                <ul className="bwa-report-rules">
                  {data.report[kind].map((rule) => (
                    <li key={rule.id}>
                      <strong>{rule.help}</strong>
                      <span className="bwa-cell-meta bwa-mono">
                        {rule.id} · {rule.nodes_count} {t("elements")}
                      </span>
                      {rule.nodes.length > 0 && (
                        <details>
                          <summary>{t("Inspect findings")}</summary>
                          {rule.nodes.slice(0, 20).map((node, index) => (
                            <div className="bwa-report-node" key={index}>
                              <p className="bwa-preserve">
                                {node.failureSummary}
                              </p>
                              <pre tabIndex="0">
                                <code>
                                  {JSON.stringify(node.target)}
                                  {"\n"}
                                  {node.html}
                                </code>
                              </pre>
                            </div>
                          ))}
                          {rule.nodes.length > 20 && (
                            <p>
                              {t(
                                "Showing the first 20 elements here. The JSON download contains every recorded finding.",
                              )}
                            </p>
                          )}
                        </details>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </>
      )}
      <section className="bwa-surface bwa-report-section">
        <h3>{t("Manual testing records")}</h3>
        <p>{t("Guided sessions have their own dates and history. Export the complete manual history for this page separately from this automated scan.")}</p>
        <ManualExports targetKey={data.target.key} />
        <p className="bwa-muted">
          {t(
            "The earlier checklist notes below are preserved as historical context. Guided testing sessions are available in Manual checks and the manual history exports above.",
          )}
        </p>
        {Object.entries(data.manual.records).length ? (
          Object.entries(data.manual.records).map(([key, record]) => (
            <div className="bwa-report-node" key={key}>
              <strong>
                {t(manualChecks.find(([id]) => id === key)?.[1] || key)}
              </strong>
              <p>
                {record.state.replaceAll("_", " ")} · {date(record.updated_at)}{" "}
                ·{" "}
                {record.fresh
                  ? t("Recorded page state")
                  : t("Needs review again")}
              </p>
              <p>{record.note}</p>
            </div>
          ))
        ) : (
          <p>{t("No earlier checklist notes for this page. Guided sessions are recorded separately in Manual checks.")}</p>
        )}
      </section>
      {data.decisions.length > 0 && (
        <section className="bwa-surface bwa-report-section">
          <h3>{t("Recorded decisions for this scan")}</h3>
          {data.decisions.map((decision, index) => (
            <p key={index}>
              <strong>{decision.rule_id}</strong> · {decision.disposition} —{" "}
              {decision.note}
            </p>
          ))}
        </section>
      )}
    </article>
  );
}

function Settings({ tick, changed }) {
  const { data, error } = useResource("/settings", tick);
  const [form, setForm] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [saveError, setSaveError] = useState("");
  useEffect(() => {
    if (data) setForm(data);
  }, [data]);
  async function save(event) {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    setSaveError("");
    setMessage("");
    try {
      await api("/settings", { method: "POST", data: form });
      setMessage(t("Settings saved. New scans will use these choices."));
      changed();
    } catch (e) {
      setSaveError(e.message);
    } finally {
      setBusy(false);
    }
  }
  if (!form) return error ? <ErrorNotice message={error} /> : <Loading />;
  return (
    <div className="bwa-two-columns">
      <form className="bwa-surface bwa-settings" onSubmit={save}>
        <h2>{t("Scan preferences")}</h2>
        <label htmlFor="bwa-profile">{t("Rule profile")}</label>
        <select
          id="bwa-profile"
          value={form.profile}
          onChange={(e) => setForm({ ...form, profile: e.target.value })}
        >
          <option value="all">
            {t("All enabled axe rules · WCAG and best practices")}
          </option>
          <option value="wcag22aa">{t("WCAG 2.2 Level A / AA")}</option>
        </select>
        <p className="bwa-muted">
          {t(
            "The full profile uses axe’s enabled rules without limiting them to WCAG tags. Experimental and other disabled-by-default rules are not force-enabled.",
          )}
        </p>
        <label htmlFor="bwa-viewport">{t("Page viewport")}</label>
        <select
          id="bwa-viewport"
          value={form.viewport}
          onChange={(e) => setForm({ ...form, viewport: e.target.value })}
        >
          <option value="desktop">{t("Desktop · 1366 × 900")}</option>
          <option value="mobile">{t("Mobile · 390 × 844")}</option>
        </select>
        <label htmlFor="bwa-delay">
          {t("Extra wait after page load (milliseconds)")}
        </label>
        <input
          id="bwa-delay"
          type="number"
          min="0"
          max="5000"
          step="100"
          value={form.settle_ms}
          onChange={(e) =>
            setForm({ ...form, settle_ms: Number(e.target.value) })
          }
        />
        <p className="bwa-muted">
          {t(
            "Allow time for content to settle before checking it. Scans do not open menus, submit forms, or test every dynamic state.",
          )}
        </p>
        <label htmlFor="bwa-retention">
          {t("Completed reports to keep per page")}
        </label>
        <input
          id="bwa-retention"
          type="number"
          min="1"
          max="10"
          value={form.history_limit}
          onChange={(e) =>
            setForm({ ...form, history_limit: Number(e.target.value) })
          }
        />
        <p className="bwa-muted">
          {t(
            "Keep 1–10 completed reports and the latest failed attempt per page. Reducing this removes older audit reports when saved. Image repair history is preserved.",
          )}
        </p>
        <ErrorNotice message={saveError} />
        {message && (
          <p role="status" className="bwa-success">
            {message}
          </p>
        )}
        <Button type="submit" aria-disabled={busy}>
          {busy ? t("Saving…") : t("Save settings")}
        </Button>
      </form>
      <section className="bwa-surface bwa-principles">
        <p className="bwa-kicker">{t("Free by design")}</p>
        <h2>{t("Your site. Your evidence.")}</h2>
        <ul>
          <li>
            {t(
              "All scanning runs in your browser using the bundled axe-core engine.",
            )}
          </li>
          <li>
            {t("Findings and review records stay in this WordPress database.")}
          </li>
          <li>
            {t("No account, API key, paid tier, scan credits, or telemetry.")}
          </li>
          <li>
            {t("Normal visitor pages load no plugin scanner or overlay.")}
          </li>
          <li>
            {t(
              "The admin workspace requires WordPress administrator permissions.",
            )}
          </li>
          <li>
            {t(
              "Keep this admin tab open while a scan queue is running. Closing it pauses work; resume the saved queue on this browser.",
            )}
          </li>
        </ul>
        <p>
          {t(
            "Reports contain page text, selectors, and HTML snippets. Share them with the same care as the pages they describe.",
          )}
        </p>
        <p>
          {t(
            "Saved content repairs persist after deactivation. Audit and review data are retained on uninstall; permanently deleting a post removes its audit data.",
          )}
        </p>
        <p className="bwa-mono">
          Build with Accessibility {bwaAdmin.version}
          <br />
          axe-core {bwaAdmin.axeVersion} · MPL-2.0
        </p>
      </section>
    </div>
  );
}

function ScanRun({ item, onResult, onPause }) {
  const frame = useRef(null);
  const [config, setConfig] = useState(null);
  const [phase, setPhase] = useState(t("Preparing the saved page…"));
  useEffect(() => {
    let alive = true;
    let accepted = false;
    let ticket;
    let timer;
    async function complete(payload) {
      if (!alive || accepted) return;
      accepted = true;
      clearTimeout(timer);
      setPhase(t("Saving the results on your site…"));
      try {
        const result = await api(`/scan-runs/${ticket.token}`, {
          method: "POST",
          data: payload,
        });
        if (alive) onResult({ ...result, error: payload.error || "" });
      } catch (e) {
        if (alive) onResult({ status: "failed", error: e.message });
      }
    }
    const receive = (event) => {
      if (
        !alive ||
        !ticket ||
        event.origin !== window.location.origin ||
        event.source !== frame.current?.contentWindow ||
        event.data?.source !== "bwa-axe-scan" ||
        event.data.token !== ticket.token
      )
        return;
      if (event.data.phase) {
        setPhase(t("Running axe-core on the rendered page…"));
        return;
      }
      if (["completed", "failed"].includes(event.data.status))
        complete({
          status: event.data.status,
          report: event.data.report,
          error: event.data.error,
        });
    };
    window.addEventListener("message", receive);
    api("/scan-runs", { method: "POST", data: { target: item.key } })
      .then((value) => {
        if (!alive) return;
        if (new URL(value.url).origin !== window.location.origin)
          throw new Error(
            t(
              "The site and WordPress admin use different origins. Open administration on the site’s origin before scanning.",
            ),
          );
        ticket = value;
        setConfig(value);
        setPhase(t("Loading the page and its styles…"));
        timer = setTimeout(
          () =>
            complete({
              status: "failed",
              error: t(
                "The page did not complete its scan. A frame policy, cache, slow resource, or missing theme hook may have prevented the checker from running. No pass was recorded.",
              ),
            }),
          75000,
        );
      })
      .catch((e) => {
        if (alive) onResult({ status: "failed", error: e.message });
      });
    return () => {
      alive = false;
      clearTimeout(timer);
      window.removeEventListener("message", receive);
    };
  }, [item.id]);
  return (
    <Modal
      title={`${t("Scanning")}: ${item.title}`}
      onRequestClose={onPause}
      className="bwa-admin-modal bwa-scan-modal"
    >
      <div className="bwa-admin">
        <p role="status" className="bwa-scan-status">
          <Spinner />
          {phase}
        </p>
        <p className="bwa-muted">
          {t(
            "This checks the saved page as you. Keep this window open. The preview keeps the selected viewport width, so it may scroll horizontally inside its frame.",
          )}
        </p>
        <Button secondary onClick={onPause}>
          {t("Pause queue")}
        </Button>
        {config && (
          <>
            <p>
              <Badge tone="blue">{profileName(config.profile)}</Badge>{" "}
              <Badge>
                {config.width} × {config.height}
              </Badge>
            </p>
            <div className="bwa-scan-viewport">
              <iframe
                ref={frame}
                title={t("Rendered page being scanned")}
                src={config.url}
                width={config.width}
                height={config.height}
                style={{
                  width: config.width,
                  minWidth: config.width,
                  height: config.height,
                }}
                referrerPolicy="same-origin"
              />
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

function readQueue() {
  try {
    const queue = JSON.parse(localStorage.getItem(queueKey) || "[]");
    return Array.isArray(queue)
      ? queue.filter(
          (item) =>
            typeof item.key === "string" &&
            /^(home|\d+)$/.test(item.key) &&
            typeof item.title === "string" &&
            typeof item.id === "string" &&
            ["pending", "completed", "failed"].includes(item.status),
        )
      : [];
  } catch {
    return [];
  }
}

function App() {
  const initial = window.location.hash.slice(1);
  const [section, setSection] = useState(
    sections.some(([id]) => id === initial) ? initial : "overview",
  );
  const [tick, setTick] = useState(0);
  const [filters, setFilters] = useState({});
  const [manualTarget, setManualTarget] = useState("home");
  const [reportId, setReportId] = useState(null);
  const [issue, setIssue] = useState(null);
  const [contentRepair, setContentRepair] = useState(null);
  const [queue, setQueue] = useState(readQueue);
  const [running, setRunning] = useState(false);
  const [current, setCurrent] = useState(null);
  const [collecting, setCollecting] = useState(false);
  const [error, setError] = useState("");
  const heading = useRef(null);
  const queueHeading = useRef(null);
  const changed = () => setTick((value) => value + 1);
  function navigate(id) {
    setSection(id);
    window.history.replaceState(null, "", `#${id}`);
    requestAnimationFrame(() => heading.current?.focus());
  }
  useEffect(() => {
    const change = () => {
      const value = window.location.hash.slice(1);
      if (sections.some(([id]) => id === value)) setSection(value);
    };
    window.addEventListener("hashchange", change);
    return () => window.removeEventListener("hashchange", change);
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem(queueKey, JSON.stringify(queue));
    } catch {
      setError(
        t(
          "This browser cannot save the queue. Keep the tab open until scanning finishes.",
        ),
      );
    }
  }, [queue]);
  useEffect(() => {
    if (!running || current) return;
    const next = queue.find((item) => item.status === "pending");
    if (next) setCurrent(next);
    else {
      setRunning(false);
      wp.a11y.speak(t("Scan queue finished. Review the saved results."));
      requestAnimationFrame(() => queueHeading.current?.focus());
    }
  }, [queue, running, current]);
  useEffect(() => {
    const warn = (event) => {
      if (running) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [running]);
  function enqueue(items) {
    if (running || collecting) return;
    setQueue((old) => {
      const existing = new Set(
        old.filter((item) => item.status === "pending").map((item) => item.key),
      );
      return [
        ...old,
        ...items
          .filter((item) => !existing.has(item.key))
          .map((item, index) => ({
            id: `${Date.now()}-${index}-${Math.random().toString(36).slice(2)}`,
            key: item.key,
            title: item.title,
            status: "pending",
            error: "",
          })),
      ];
    });
    setRunning(true);
    setError("");
  }
  async function queueAll() {
    if (running || collecting) return;
    setCollecting(true);
    setError("");
    try {
      const items = [];
      let page = 1;
      let pages = 1;
      do {
        const result = await api(`/targets?per_page=100&page=${page}`);
        items.push(...result.items);
        pages = result.pages;
        page++;
      } while (page <= pages);
      setCollecting(false);
      enqueue(items);
    } catch (e) {
      setError(e.message);
      setCollecting(false);
    }
  }
  function result(value) {
    const id = current.id;
    setQueue((items) =>
      items.map((item) =>
        item.id === id
          ? { ...item, status: value.status, error: value.error || "" }
          : item,
      ),
    );
    setCurrent(null);
    changed();
  }
  function pause() {
    setRunning(false);
    setCurrent(null);
    wp.a11y.speak(t("Queue paused. Resume to scan the remaining pages."));
    requestAnimationFrame(() => queueHeading.current?.focus());
  }
  function viewReport(id) {
    setReportId(id);
    navigate("reports");
  }
  const pending = queue.filter((item) => item.status === "pending").length;
  const completed = queue.length - pending;
  return (
    <div className="bwa-admin">
      <header className="bwa-admin-brand">
        <div className="bwa-brand-lockup">
          <img src={bwaAdmin.logo} width="40" height="40" alt="" />
          <div>
            <strong>Accessibility.build</strong>
            <span>{t("Build with Accessibility")}</span>
          </div>
        </div>
        <div className="bwa-site-identity">
          <strong>{bwaAdmin.siteName}</strong>
          <Badge tone="teal">{t("Completely free")}</Badge>
        </div>
      </header>
      <nav className="bwa-admin-nav" aria-label={t("Accessibility workspace")}>
        {sections.map(([id, label]) => (
          <button
            key={id}
            type="button"
            aria-current={section === id ? "page" : undefined}
            onClick={() => navigate(id)}
          >
            {t(label)}
          </button>
        ))}
      </nav>
      <main>
        <div className="bwa-page-heading">
          <div>
            <p className="bwa-kicker">{t("Accessibility workspace")}</p>
            <h1 tabIndex="-1" ref={heading}>
              {t(sections.find(([id]) => id === section)[1])}
            </h1>
          </div>
          <span className="bwa-engine">
            axe-core {bwaAdmin.axeVersion} <span aria-hidden="true">/</span>{" "}
            {t("Local processing")}
          </span>
        </div>
        <ErrorNotice message={error} />
        {collecting && (
          <p role="status">
            <Spinner />
            {t("Collecting the page inventory…")}
          </p>
        )}
        {!!queue.length && (
          <section className="bwa-queue" aria-label={t("Scan queue")}>
            <div className="bwa-section-heading">
              <div>
                <h2 ref={queueHeading} tabIndex="-1">
                  {running
                    ? t("Scan queue running")
                    : pending
                      ? t("Scan queue paused")
                      : t("Scan queue finished")}
                </h2>
                <p>
                  {completed} / {queue.length} {t("processed")} ·{" "}
                  {queue.filter((item) => item.status === "failed").length}{" "}
                  {t("could not scan")}
                </p>
              </div>
              <div className="bwa-inline">
                {pending > 0 && !running && (
                  <Button onClick={() => setRunning(true)}>
                    {t("Resume queue")}
                  </Button>
                )}
                {!running && (
                  <Button secondary onClick={() => { setQueue([]); requestAnimationFrame(() => heading.current?.focus()); }}>
                    {t("Clear queue")}
                  </Button>
                )}
              </div>
            </div>
            <progress
              value={completed}
              max={queue.length}
              aria-label={t("Pages processed")}
            />
            {queue.some((item) => item.status === "failed") && (
              <details>
                <summary>{t("Review pages that could not be scanned")}</summary>
                <ul>
                  {queue
                    .filter((item) => item.status === "failed")
                    .map((item) => (
                      <li key={item.id}>
                        <strong>{item.title}:</strong> {item.error}
                      </li>
                    ))}
                </ul>
              </details>
            )}
          </section>
        )}
        {section === "overview" && (
          <Overview
            tick={tick}
            navigate={navigate}
            queueAll={queueAll}
            busy={running || collecting}
            openIssue={setIssue}
            viewReport={viewReport}
          />
        )}
        {section === "pages" && (
          <Pages
            tick={tick}
            enqueue={enqueue}
            queueAll={queueAll}
            busy={running || collecting}
            showIssues={(key) => {
              setFilters({ target_key: key });
              navigate("issues");
            }}
            reviewPage={(key) => {
              setManualTarget(key);
              navigate("manual");
            }}
            viewReport={viewReport}
            repairPage={setContentRepair}
          />
        )}
        {section === "recheck" && (
          <RecheckInbox
            tick={tick}
            enqueue={enqueue}
            busy={running || collecting}
            viewReport={viewReport}
            reviewPage={(key) => {
              setManualTarget(key);
              navigate("manual");
            }}
          />
        )}
        {section === "issues" && (
          <Issues
            tick={tick}
            filters={filters}
            setFilters={setFilters}
            openIssue={setIssue}
          />
        )}
        {section === "manual" && (
          <ManualSessions
            targetKey={manualTarget}
            setTargetKey={setManualTarget}
            tick={tick}
            changed={changed}
          />
        )}
        {section === "repairs" && (
          <Repairs tick={tick} repairPage={setContentRepair} />
        )}
        {section === "reports" && (
          <Reports tick={tick} reportId={reportId} viewReport={viewReport} changed={changed} />
        )}
        {section === "settings" && <Settings tick={tick} changed={changed} />}
      </main>
      <footer className="bwa-admin-footer">
        <strong>{t("Free tools. Real improvements.")}</strong>
        <span>
          {t("No account, credits, telemetry, or visitor overlay.")} · v
          {bwaAdmin.version}
        </span>
      </footer>
      {issue && (
        <IssueDetail
          item={issue}
          onClose={() => setIssue(null)}
          changed={changed}
          enqueue={enqueue}
          repairPage={setContentRepair}
        />
      )}
      {contentRepair && (
        <ContentRepairs
          {...contentRepair}
          onClose={() => setContentRepair(null)}
          changed={changed}
          rescan={enqueue}
        />
      )}
      {running && current && (
        <ScanRun
          key={current.id}
          item={current}
          onResult={result}
          onPause={pause}
        />
      )}
    </div>
  );
}
createRoot(document.getElementById("bwa-admin-root")).render(<App />);
