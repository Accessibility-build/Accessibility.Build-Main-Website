/* Loaded only in an authenticated, expiring repair preview. */
const config = window.bwaContentCheck;
const t = (message) => wp.i18n.__(message, "build-with-accessibility");
const text = (element) => element.textContent.trim();
const visible = (element) => {
  if (
    element.closest('[hidden], [aria-hidden="true"], [inert]') ||
    !element.getClientRects().length
  )
    return false;
  const bounds = element.getBoundingClientRect();
  if (bounds.width <= 1 || bounds.height <= 1) return false;
  for (let node = element; node; node = node.parentElement) {
    const style = getComputedStyle(node);
    if (
      ["hidden", "collapse"].includes(style.visibility) ||
      Number(style.opacity) === 0 ||
      style.clip !== "auto" ||
      style.clipPath !== "none"
    )
      return false;
  }
  return true;
};

async function inspect() {
  if (!config || window.parent === window) return;
  let result;
  try {
    if (document.fonts?.ready)
      await Promise.race([
        document.fonts.ready,
        new Promise((resolve) => setTimeout(resolve, 3000)),
      ]);
    const matches = document.querySelectorAll(
      `[data-bwa-repair="${CSS.escape(config.token)}"]`,
    );
    if (matches.length !== 1)
      throw new Error(
        t(
          "The saved page did not expose exactly one matching element. Its template or another plugin may have changed the output.",
        ),
      );
    const element = matches[0],
      target = config.target;
    if (!visible(element))
      throw new Error(
        t(
          "The repaired element is hidden or clipped in this page state. Check its visible state separately.",
        ),
      );
    let reason = "";
    if (
      element.hasAttribute("aria-label") ||
      element.hasAttribute("aria-labelledby") ||
      element.hasAttribute("role")
    )
      reason = t(
        "Rendered naming or role attributes override this repair. Review the theme or plugin that adds them.",
      );
    if (
      target.kind === "heading" &&
      (element.tagName !== `H${target.level}` || text(element) !== target.text)
    )
      reason = t(
        "The rendered heading level or text differs from the approved repair.",
      );
    if (
      target.kind === "link" &&
      (element.tagName !== "A" ||
        text(element) !== target.text ||
        element.getAttribute("href") !== target.href)
    )
      reason = t(
        "The rendered link text or destination differs from the approved repair.",
      );
    if (target.kind === "label") {
      const labels = [...(element.labels || [])];
      if (
        element.id !== target.control_id ||
        document.querySelectorAll(`[id="${CSS.escape(target.control_id)}"]`)
          .length !== 1 ||
        labels.length !== 1 ||
        labels[0].htmlFor !== element.id ||
        text(labels[0]) !== target.text
      )
        reason = t(
          "The control does not have exactly one correctly associated label matching the approved text.",
        );
      else if (!visible(labels[0]))
        reason = t(
          "The label is hidden. This flow requires a visible label beside the control.",
        );
    }
    if (reason) result = { status: "failed", reason };
    else {
      const rules =
        target.kind === "heading"
          ? ["empty-heading", "heading-order"]
          : target.kind === "link"
            ? ["link-name"]
            : [
                "label",
                "select-name",
                "label-title-only",
                "form-field-multiple-labels",
              ];
      const report = await axe.run(document, {
        runOnly: { type: "rule", values: rules },
        elementRef: true,
      });
      const affects = (rule) =>
        rule.nodes.some(
          (node) => node.element === element || element.contains(node.element),
        );
      const failed = report.violations.filter(affects),
        incomplete = report.incomplete.filter(affects);
      result = failed.length
        ? {
            status: "failed",
            reason: failed.map((rule) => rule.help).join(" "),
          }
        : incomplete.length
          ? {
              status: "inconclusive",
              reason:
                t(
                  "The saved change is present, but axe needs human review for this element: ",
                ) + incomplete.map((rule) => rule.help).join(" "),
            }
          : {
              status: "passed",
              reason:
                target.kind === "heading"
                  ? t(
                      "The approved heading text and level are present and the selected heading checks pass. Review the page outline and meaning in context.",
                    )
                  : target.kind === "link"
                    ? t(
                        "The approved visible link text is present, its destination is unchanged, and the link-name check passes. Confirm that the wording describes its destination.",
                      )
                    : t(
                        "The approved visible label is associated with exactly one control and the selected label checks pass. Review instructions, grouped fields, and error messages separately.",
                      ),
            };
    }
  } catch (error) {
    result = {
      status: "inconclusive",
      reason:
        error.message ||
        t("The diagnostic could not finish. No pass was recorded."),
    };
  }
  window.parent.postMessage(
    { source: "bwa-content-recheck", token: config.token, result },
    window.location.origin,
  );
}
if (document.readyState === "complete") inspect();
else window.addEventListener("load", inspect, { once: true });
