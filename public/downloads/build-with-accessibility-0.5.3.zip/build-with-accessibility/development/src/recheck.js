/* Loaded only in an authorized diagnostic page. Nothing is submitted or clicked. */
const { __ } = window.wp.i18n;
const config = window.bwaCheck;
let reported = false;

function inspect() {
    if (reported || !config || window.parent === window) return;
    reported = true;
    const matches = document.querySelectorAll(`img[data-bwa-image="${CSS.escape(config.token)}"]`);
    let result;
    if (matches.length !== 1) {
        result = { status: 'inconclusive', reason: __('The page did not expose exactly one matching image. Its template, cache, or another plugin may have changed the output.', 'build-with-accessibility') };
    } else {
        const img = matches[0];
        const customName = img.hasAttribute('aria-label') || img.hasAttribute('aria-labelledby');
        const hidden = img.closest('[hidden], [aria-hidden="true"], [inert]') || img.getClientRects().length === 0 || getComputedStyle(img).visibility === 'hidden';
        const interactive = img.closest('a, button, [role="button"], [tabindex]');
        const altMatches = img.hasAttribute('alt') && img.getAttribute('alt') === config.alt;
        const role = img.getAttribute('role');
        if (hidden) {
            result = { status: 'inconclusive', reason: __('The matching image is hidden in this page state. Its visible use needs a separate check.', 'build-with-accessibility') };
        } else if (customName || (config.purpose === 'informative' && role && role !== 'img')) {
            result = { status: 'failed', reason: __('Rendered accessibility attributes override the image alternative. Review the theme or plugin that adds them.', 'build-with-accessibility') };
        } else if (!altMatches || (config.purpose === 'decorative' && (interactive || (role && role !== 'presentation' && role !== 'none')))) {
            result = { status: 'failed', reason: __('The rendered image does not match the approved alternative or decorative purpose.', 'build-with-accessibility') };
        } else {
            result = { status: 'passed', reason: config.purpose === 'decorative'
                ? __('The rendered image has an empty alternative and is not an interactive control. Its decorative purpose remains your editorial decision.', 'build-with-accessibility')
                : __('The approved alternative is present on the rendered image. Its accuracy and usefulness still need human judgment.', 'build-with-accessibility') };
        }
    }
    window.parent.postMessage({ source: 'bwa-image-recheck', token: config.token, result }, window.location.origin);
}

function schedule() { requestAnimationFrame(() => requestAnimationFrame(inspect)); }
if (document.readyState === 'complete') schedule();
else window.addEventListener('load', schedule, { once: true });
