const { useEffect, useRef, useState } = wp.element;

// Safari does not automatically put scrolling containers in the tab order.
// Add a named keyboard stop only when the table actually overflows.
export function ScrollableTable({ children, label, ...props }) {
  const container = useRef(null);
  const [overflow, setOverflow] = useState(false);
  useEffect(() => {
    const element = container.current;
    const measure = () => setOverflow(element.scrollWidth > element.clientWidth + 1);
    measure();
    const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(measure) : null;
    observer?.observe(element);
    if (element.firstElementChild) observer?.observe(element.firstElementChild);
    window.addEventListener('resize', measure);
    return () => { observer?.disconnect(); window.removeEventListener('resize', measure); };
  }, [children]);
  function scrollWithKeyboard(event) {
    if (!overflow || event.target !== event.currentTarget || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
    // WebKit can focus an overflow region without scrolling it on arrow keys.
    // Handle only the region itself; never intercept controls inside the table.
    event.preventDefault();
    event.currentTarget.scrollBy({ left: event.key === 'ArrowRight' ? 40 : -40, behavior: 'auto' });
  }
  return <div ref={container} className="bwa-table-wrap" tabIndex={overflow ? 0 : undefined} role={overflow ? 'region' : undefined} aria-label={overflow ? label : undefined} onKeyDown={scrollWithKeyboard} {...props}>{children}</div>;
}
