/* WordPress supplies the runtime; no external services, React copy, or account SDK. */
const { useState, useEffect, useCallback, useRef, useMemo } = wp.element;
const { useSelect, select, dispatch } = wp.data;
const { Button, TextareaControl, Notice, Spinner, Modal } = wp.components;
const { PluginSidebar } = wp.editor;
const { __, sprintf, _n } = wp.i18n;
const { serialize, parse } = wp.blocks;
const api = wp.apiFetch;
const t = (text) => __(text, 'build-with-accessibility');

let guardedSave = null;
api.use((options, next) => {
    if (guardedSave && options.path?.split('?')[0] === guardedSave.path && ['POST', 'PUT', 'PATCH'].includes(options.method?.toUpperCase())) {
        options = { ...options, headers: { ...options.headers, 'X-BWA-Repair': guardedSave.id, 'X-BWA-Token': guardedSave.token } };
    }
    return next(options);
});

function imageInventory(blocks, path = [], result = { images: [], shared: 0 }) {
    blocks.forEach((block, index) => {
        const currentPath = [...path, index];
        if (['core/block', 'core/template-part', 'core/query', 'core/post-template', 'core/navigation'].includes(block.name)) { result.shared++; return; }
        if (block.name === 'core/image') result.images.push({ block, path: currentPath });
        else imageInventory(block.innerBlocks || [], currentPath, result);
    });
    return result;
}

function blockAt(blocks, path) {
    let block;
    for (const index of path) { block = blocks[index]; if (!block) return null; blocks = block.innerBlocks || []; }
    return block;
}

function withAlternative(blocks, path, attributes) {
    const [index, ...rest] = path;
    return blocks.map((block, i) => i !== index ? block : rest.length
        ? { ...block, innerBlocks: withAlternative(block.innerBlocks, rest, attributes) }
        : { ...block, attributes: { ...block.attributes, ...attributes } });
}

function alternativeAttributes(alt, decorative) {
    return { alt, ...(wp.blocks.getBlockType('core/image').attributes.isDecorative ? { isDecorative: decorative } : {}) };
}

function pathEqual(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
function announce(message) { wp.a11y.speak(message, 'polite'); }
function errorText(error) { return error?.message || t('The operation did not finish. Check your connection and reload the saved post before trying again.'); }
function endpoint(postId, suffix = '') { return `/bwa/v1/posts/${postId}/repairs${suffix}`; }

function Mark() {
    return <svg viewBox="0 0 48 48" width="24" height="24" aria-hidden="true" focusable="false"><circle cx="24" cy="24" r="21" fill="none" stroke="currentColor" strokeWidth="2.5"/><path d="m15 36 9-24 9 24M19 27h10M14 21q10-5 20 0M14 29q10 5 20 0" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}

function Recheck({ postId, record, onClose, onDone }) {
    const frame = useRef(null);
    const [check, setCheck] = useState(null);
    const [result, setResult] = useState(null);
    const [error, setError] = useState('');
    useEffect(() => {
        let alive = true;
        let timer;
        let accepted = false;
        let config;
        const receive = async (event) => {
            if (!alive || accepted || !config || event.origin !== window.location.origin || event.source !== frame.current?.contentWindow || event.data?.source !== 'bwa-image-recheck' || event.data.token !== config.token) return;
            accepted = true;
            clearTimeout(timer);
            try {
                const evidence = await api({ path: endpoint(postId, `/${record.id}/recheck`), method: 'PUT', data: { token: config.token, result: event.data.result } });
                if (!alive) return;
                setResult(evidence);
                announce(evidence.status === 'passed' ? t('The image alternative passed its rendered-page recheck.') : t('The image needs further review.'));
                onDone();
            } catch (e) { if (alive) setError(errorText(e)); }
        };
        window.addEventListener('message', receive);
        api({ path: endpoint(postId, `/${record.id}/recheck`), method: 'POST' }).then((value) => {
            if (!alive) return;
            if (new URL(value.url, window.location.href).origin !== window.location.origin) throw new Error(t('The preview uses a different site address. Use the same address for WordPress administration and the site before rechecking.'));
            config = value;
            setCheck(value);
            timer = setTimeout(async () => {
                if (!alive || accepted) return;
                accepted = true;
                const timeoutResult = { status: 'inconclusive', reason: t('The page did not complete the recheck. A cache, page policy, slow resource, or theme may have prevented the diagnostic from loading. Try again after checking the page. No pass was recorded.') };
                try {
                    const evidence = await api({ path: endpoint(postId, `/${record.id}/recheck`), method: 'PUT', data: { token: config.token, result: timeoutResult } });
                    if (alive) { setResult(evidence); onDone(); announce(t('Recheck could not confirm the image.')); }
                } catch (e) { if (alive) setError(errorText(e)); }
            }, 20000);
        }).catch((e) => { if (alive) setError(errorText(e)); });
        return () => { alive = false; clearTimeout(timer); window.removeEventListener('message', receive); };
    }, [postId, record.id]);
    return <Modal title={t('Recheck the saved image')} onRequestClose={onClose} className="bwa-modal">
        <div className="bwa">
            <p className="bwa-note">{t('This loads the saved page as you, without clicking controls or submitting forms. It checks this image’s alternative, not the whole page or its anonymous cached version.')}</p>
            {error && <Notice status="error" isDismissible={false}>{error}</Notice>}
            {!error && !result && <p role="status"><Spinner /> {t('Opening the page and checking the matching image…')}</p>}
            {result && <div className={`bwa-result bwa-result--${result.status}`} role="status"><h3>{result.status === 'passed' ? t('Image alternative rechecked') : result.status === 'failed' ? t('The rendered image needs attention') : t('Recheck could not confirm the image')}</h3><p>{result.reason}</p><p className="bwa-caption">{sprintf(t('Checked in: %s'), check.context === 'saved draft preview' ? t('saved draft preview') : t('logged-in page'))}</p></div>}
            <Button variant="secondary" onClick={onClose}>{t('Return to image repairs')}</Button>
            {check && <iframe ref={frame} className="bwa-page-preview" title={t('Saved page used for the image recheck')} src={check.url} referrerPolicy="same-origin" />}
        </div>
    </Modal>;
}

function App() {
    const editor = useSelect((get) => ({
        blocks: get('core/block-editor').getBlocks(),
        postId: get('core/editor').getCurrentPostId(),
        postType: get('core/editor').getCurrentPostType(),
        dirty: get('core/editor').isEditedPostDirty(),
        saving: get('core/editor').isSavingPost(),
        locked: get('core/editor').isPostLocked(),
        status: get('core/editor').getCurrentPostAttribute('status'),
        content: get('core/editor').getEditedPostContent(),
    }), []);
    const [records, setRecords] = useState([]);
    const [repairNotice, setRepairNotice] = useState('');
    const [selectedId, setSelectedId] = useState(null);
    const [purpose, setPurpose] = useState('informative');
    const [alt, setAlt] = useState('');
    const [busy, setBusy] = useState(false);
    const [notice, setNotice] = useState(null);
    const [recheck, setRecheck] = useState(null);
    // PluginSidebar renders through WordPress SlotFill. Focus when its heading
    // actually mounts, rather than racing the portal with a parent effect.
    const heading = useCallback((node) => { node?.focus(); }, []);
    const historyHeading = useRef(null);
    const imageButtons = useRef({});
    const deepLinkHandled = useRef(false);
    const inventory = useMemo(() => imageInventory(editor.blocks), [editor.blocks]);
    const needsFormatSave = useMemo(() => !editor.dirty && serialize(editor.blocks).trim() !== (editor.content || '').trim(), [editor.blocks, editor.content, editor.dirty]);
    const selected = inventory.images.find(({ block }) => block.clientId === selectedId);
    const unavailable = busy || editor.saving || editor.locked || !!repairNotice;
    const linked = !!(selected?.block.attributes.href || selected?.block.attributes.lightbox?.enabled);
    const bindings = !!selected?.block.attributes.metadata?.bindings;
    const invalid = selected?.block.isValid === false || bindings;

    async function refresh() {
        if (!editor.postId || editor.status === 'auto-draft') return;
        const data = await api({ path: endpoint(editor.postId) });
        setRepairNotice(data.repair_notice || '');
        if (data.repair_notice) setSelectedId(null);
        setRecords(data.records.filter((record) => !record.kind || record.kind === 'image'));
        const link = window.bwaSettings.imageLink;
        if (!deepLinkHandled.current && link && select('core/block-editor').getBlocks().length) {
            deepLinkHandled.current = true;
            const item = imageInventory(select('core/block-editor').getBlocks()).images.find((image) => pathEqual(image.path, link.path));
            dispatch('core/interface').enableComplementaryArea('core', 'build-with-accessibility/bwa-image-repair');
            if (!data.repair_notice && item && data.source_hash === link.source_hash) review(item);
            else setNotice({ type: 'warning', message: t('The page changed since this finding was recorded. Review the current images before making a repair.') });
        }
        return data.records;
    }
    useEffect(() => { refresh().catch((e) => setNotice({ type: 'error', message: errorText(e) })); }, [editor.postId, editor.saving, inventory.images.length]);

    function review(item) {
        const record = records.find((r) => r.state === 'saved' && r.current && pathEqual(r.path, item.path));
        setSelectedId(item.block.clientId);
        setAlt(item.block.attributes.alt || '');
        setPurpose(record?.purpose || (item.block.attributes.isDecorative ? 'decorative' : 'informative'));
        setNotice(null);
        // Keep keyboard focus in the review sidebar. The default caret position
        // asks Gutenberg to focus its canvas and races with the review fields.
        dispatch('core/block-editor').selectBlock(item.block.clientId, null);
    }

    function requireClean() {
        if (select('core/editor').isEditedPostDirty() || editor.status === 'auto-draft' || needsFormatSave) throw new Error(t('Save existing edits first. The image repair will then save only the change you review here.'));
        if (select('core/editor').isPostLocked() || select('core/editor').isSavingPost()) throw new Error(t('WordPress is saving or another author holds the post lock. Wait before repairing the image.'));
    }

    async function saveNative(prepared, clientId, attributes) {
        if (prepared.no_op) return;
        const type = select('core').getPostType(editor.postType);
        const restBase = type?.rest_base || (editor.postType === 'page' ? 'pages' : 'posts');
        guardedSave = { ...prepared, path: `/wp/v2/${restBase}/${editor.postId}` };
        dispatch('core/editor').lockPostAutosaving('bwa-image-repair');
        try {
            dispatch('core/block-editor').updateBlockAttributes(clientId, attributes);
            await dispatch('core/editor').savePost();
            if (select('core/editor').didPostSaveRequestFail()) throw new Error(t('WordPress did not confirm the repair save. Your proposed change remains in the editor. Check the save error and reload the saved post before retrying.'));
        } finally {
            guardedSave = null;
            dispatch('core/editor').unlockPostAutosaving('bwa-image-repair');
        }
    }

    async function repair() {
        setBusy(true); setNotice(null);
        try {
            requireClean();
            const blocks = select('core/block-editor').getBlocks();
            const current = imageInventory(blocks).images.find(({ block }) => block.clientId === selectedId);
            if (!current || current.block.isValid === false || current.block.attributes.metadata?.bindings) throw new Error(t('This image cannot be edited safely here. Review it in the normal block controls.'));
            const value = purpose === 'decorative' ? '' : alt.trim();
            const attributes = alternativeAttributes(value, purpose === 'decorative');
            const prepared = await api({ path: endpoint(editor.postId), method: 'POST', data: {
                before_content: select('core/editor').getEditedPostContent(),
                after_content: serialize(withAlternative(blocks, current.path, attributes)), path: current.path, purpose,
            } });
            await saveNative(prepared, current.block.clientId, attributes);
            const latest = await refresh();
            if (!latest?.some((r) => r.id === prepared.id && r.state === 'saved')) throw new Error(t('The save did not match the approved repair. Review the saved content before continuing.'));
            const message = prepared.no_op ? t('Image purpose recorded. Run a recheck to confirm the saved page output.') : t('Image repair saved in WordPress. It will remain if this plugin is disabled. Run a recheck next.');
            setNotice({ type: 'success', message }); announce(message); setSelectedId(null);
            requestAnimationFrame(() => historyHeading.current?.focus());
        } catch (e) { setNotice({ type: 'error', message: errorText(e) }); announce(errorText(e)); }
        finally { setBusy(false); }
    }

    async function undo(record) {
        setBusy(true); setNotice(null);
        try {
            requireClean();
            const blocks = select('core/block-editor').getBlocks();
            const block = blockAt(blocks, record.path);
            if (!block || block.name !== 'core/image' || block.isValid === false) throw new Error(t('The original image moved or changed. Undo is paused to protect your work.'));
            const previous = parse(record.before)[0];
            const value = previous.attributes.alt || '';
            const attributes = alternativeAttributes(value, !!previous.attributes.isDecorative);
            const prepared = await api({ path: endpoint(editor.postId, `/${record.id}/undo`), method: 'POST', data: {
                before_content: select('core/editor').getEditedPostContent(), after_content: serialize(withAlternative(blocks, record.path, attributes)),
            } });
            await saveNative(prepared, block.clientId, attributes);
            const latest = await refresh();
            if (!latest?.some((r) => r.id === record.id && r.state === 'undone')) throw new Error(t('WordPress did not confirm undo. Reload the saved post to inspect the result.'));
            const message = t('Repair undone. The previous image alternative is restored; other saved content is preserved.');
            setNotice({ type: 'success', message }); announce(message); setSelectedId(null);
            requestAnimationFrame(() => historyHeading.current?.focus());
        } catch (e) { setNotice({ type: 'error', message: errorText(e) }); announce(errorText(e)); }
        finally { setBusy(false); }
    }

    async function saveExisting() {
        setBusy(true); setNotice(null);
        try {
            if (needsFormatSave) dispatch('core/editor').editPost({ content: serialize(select('core/block-editor').getBlocks()) });
            await dispatch('core/editor').savePost();
            if (select('core/editor').didPostSaveRequestFail()) throw new Error(t('WordPress could not save the post. Resolve its save error before repairing images.'));
            await refresh();
        } catch (e) { setNotice({ type: 'error', message: errorText(e) }); }
        finally { setBusy(false); }
    }

    return <PluginSidebar name="bwa-image-repair" title={t('Build with Accessibility')} icon={<Mark />}>
        <div className="bwa bwa-panel" aria-busy={busy}>
            <header className="bwa-brand"><img src={window.bwaSettings.logo} alt="" width="36" height="36" /><div><strong>Accessibility.build</strong><span>{t('Free tools. Real improvements.')}</span></div></header>
            <div className="bwa-intro"><p className="bwa-eyebrow">{t('Gutenberg · Image repair')}</p><h2>{t('Give every image a purpose.')}</h2><p>{t('Review an image where it is used, save a meaningful alternative, then check the result.')}</p></div>
            <ol className="bwa-steps" aria-label={t('Repair workflow')}><li>{t('Review')}</li><li>{t('Save')}</li><li>{t('Recheck')}</li></ol>
            {repairNotice && <Notice status="warning" isDismissible={false}>{repairNotice}</Notice>}
            {notice && <Notice status={notice.type} isDismissible onRemove={() => setNotice(null)}>{notice.message}</Notice>}
            {(editor.dirty || editor.status === 'auto-draft' || needsFormatSave) && <div className="bwa-callout"><p>{needsFormatSave ? t('WordPress needs to save this content in its current block format before a focused image repair.') : t('Save your existing edits before starting a repair or undo.')}</p><Button variant="secondary" disabled={unavailable} onClick={saveExisting}>{t('Save existing edits')}</Button></div>}
            {editor.locked && <Notice status="warning" isDismissible={false}>{t('Another author is editing this post. Repairs are paused.')}</Notice>}
            {selected ? <section className="bwa-review" aria-labelledby="bwa-review-title">
                <Button variant="tertiary" onClick={() => { const id = selectedId; setSelectedId(null); requestAnimationFrame(() => imageButtons.current[id]?.focus()); }} disabled={busy}>{t('Back to images')}</Button>
                <h3 id="bwa-review-title" tabIndex="-1" ref={heading}>{sprintf(t('Review image %d'), inventory.images.indexOf(selected) + 1)}</h3>
                {selected.block.attributes.url && <div className="bwa-image"><img src={selected.block.attributes.url} alt={selected.block.attributes.alt || ''} /><span>{t('Image in this content placement')}</span></div>}
                {invalid && <Notice status="warning" isDismissible={false}>{t('This block is invalid or uses bound content. Use its normal editor controls; automatic repair is unavailable.')}</Notice>}
                <fieldset className="bwa-purpose" disabled={unavailable}><legend>{t('What does this image do here?')}</legend><label><input type="radio" name="bwa-image-purpose" value="informative" checked={purpose === 'informative'} onChange={() => setPurpose('informative')} />{t('It communicates information')}</label><label><input type="radio" name="bwa-image-purpose" value="decorative" checked={purpose === 'decorative'} onChange={() => setPurpose('decorative')} disabled={linked} />{t('It is decorative')}</label></fieldset>
                {linked && <p className="bwa-note">{t('This image is linked or opens a lightbox. Give the control a meaningful description instead of marking it decorative.')}</p>}
                {purpose === 'informative' ? <TextareaControl label={t('Alternative text')} help={t('Describe the information or link purpose this image adds in context. Avoid repeating nearby text.')} value={alt} onChange={setAlt} rows={4} disabled={unavailable} __nextHasNoMarginBottom /> : <p className="bwa-note">{t('Choose decorative only when removing this image would lose no information. The saved alternative will be empty.')}</p>}
                <div className="bwa-diff" aria-label={t('Proposed change')}><div><span>{t('Current alternative')}</span><p>{selected.block.attributes.alt || t('(empty)')}</p></div><div><span>{t('After this repair')}</span><p>{purpose === 'decorative' ? t('(empty — confirmed decorative)') : alt.trim() || t('Enter a description above.')}</p></div></div>
                <p className="bwa-caption">{t('Changes this Image block only. The Media Library description and other placements stay as they are.')}</p>
                <Button variant="primary" className="bwa-primary" onClick={repair} disabled={unavailable || editor.dirty || needsFormatSave || invalid || (purpose === 'informative' && !alt.trim()) || (purpose === 'decorative' && linked)}>{busy ? t('Saving repair…') : t('Save image repair')}</Button>
            </section> : <section className="bwa-inventory" aria-labelledby="bwa-images-title">
                <h3 id="bwa-images-title">{sprintf(_n('%d image in this content', '%d images in this content', inventory.images.length, 'build-with-accessibility'), inventory.images.length)}</h3>
                {!inventory.images.length && <p>{t('Add a native Image block to this post or page to start. Template images and third-party image blocks are outside this first release.')}</p>}
                <ul className="bwa-image-list">{inventory.images.map((item, index) => {
                    const reviewed = records.some((r) => r.state === 'saved' && r.current && r.purpose === 'decorative' && pathEqual(r.path, item.path));
                    return <li key={item.block.clientId}><button ref={(node) => { imageButtons.current[item.block.clientId] = node; }} type="button" disabled={unavailable} onClick={() => review(item)} aria-label={sprintf(t('Review image %d'), index + 1)}><span className="bwa-image-number" aria-hidden="true">{index + 1}</span><span><strong>{item.block.attributes.alt || (reviewed ? t('Confirmed decorative') : t('Review image purpose'))}</strong><small>{item.block.attributes.alt ? t('Alternative text present · review meaning') : reviewed ? t('Decorative choice recorded') : t('Empty alternative · needs a human decision')}</small></span><span className="bwa-arrow" aria-hidden="true">→</span></button></li>;
                })}</ul>
                {!!inventory.shared && <p className="bwa-note">{t('Shared or dynamically rendered content is present. Images in patterns, templates, navigation, and Query Loops need manual review in this alpha.')}</p>}
            </section>}
            <section className="bwa-history" aria-labelledby="bwa-history-title"><div className="bwa-section-title"><h3 id="bwa-history-title" tabIndex="-1" ref={historyHeading}>{t('Repair history')}</h3><Button variant="tertiary" onClick={() => refresh().catch((e) => setNotice({ type: 'error', message: errorText(e) }))} disabled={unavailable}>{t('Refresh')}</Button></div>
                {!records.length && <p className="bwa-note">{t('Saved repairs and their rechecks will appear here. Everything is kept on this WordPress site.')}</p>}
                {records.map((record) => {
                    const active = record.state === 'saved' && record.current;
                    const fresh = record.display_state !== 'needs_recheck' && record.display_state !== 'changed';
                    const passed = active && fresh && record.evidence?.status === 'passed';
                    const label = record.state === 'undone' ? t('Undone') : record.state === 'save_changed' ? t('Save needs review') : !record.current ? t('Image changed · undo paused') : passed ? t('Alternative rechecked') : record.evidence?.status === 'failed' && fresh ? t('Recheck found a problem') : t('Saved · needs recheck');
                    return <article className="bwa-receipt" key={record.id}><span className={`bwa-status ${passed ? 'bwa-status--passed' : ''}`}>{label}</span><p className="bwa-receipt-alt">{record.purpose === 'decorative' ? t('Confirmed decorative image') : record.alt}</p><time className="bwa-caption" dateTime={record.created}>{new Date(record.created).toLocaleString()}</time>
                        {record.evidence && active && fresh && <><p className="bwa-note">{record.evidence.reason}</p><p className="bwa-caption">{sprintf(t('Checked %s'), new Date(record.evidence.checked_at).toLocaleString())} · {record.evidence.context === 'saved draft preview' ? t('saved draft preview') : t('logged-in page')}</p></>}
                        {!fresh && active && <p className="bwa-note">{t('The post changed after the last check. Recheck its current output.')}</p>}
                        {active && <div className="bwa-actions"><Button variant="secondary" onClick={() => setRecheck(record)} disabled={unavailable || editor.dirty}>{t('Recheck saved page')}</Button><Button variant="tertiary" onClick={() => undo(record)} disabled={unavailable || editor.dirty || needsFormatSave}>{t('Undo repair')}</Button></div>}
                    </article>;
                })}
            </section>
            <footer className="bwa-footer"><strong>{t('Always free. Stored on your site.')}</strong><p>{t('No account, API key, or telemetry. These checks help monitor image alternatives; they do not establish full accessibility or legal compliance. Manual testing remains required, even after a successful recheck.')}</p></footer>
            {recheck && <Recheck postId={editor.postId} record={recheck} onClose={() => setRecheck(null)} onDone={() => refresh().catch((e) => setNotice({ type: 'error', message: errorText(e) }))} />}
        </div>
    </PluginSidebar>;
}

wp.plugins.registerPlugin('build-with-accessibility', { render: App, icon: Mark });
