// No remote assets or scripts in exported reports. All evidence is escaped text.
export const outcomeLabels = {
  not_tested: "Not tested",
  blocked: "Blocked",
  issue_found: "Issue found",
  no_issue_observed: "No issue observed in these steps",
  not_applicable: "Not applicable (reason recorded)",
};
const escape = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const paragraph = (label, value) => `<p><strong>${escape(label)}:</strong> ${escape(value || "Not recorded")}</p>`;

export function manualHtml(data, language = "en") {
  const sessions = data.sessions.map((session) => {
    const evidence = session.evidence;
    return `<article><h2>${escape(evidence.guide.title)} · ${escape(evidence.scope)}</h2>
      ${paragraph("Record", `Session #${session.id} · ${session.latest_in_export ? "Latest session for this review in this export" : "Historical session"}`)}
      ${paragraph("Recorded at (UTC)", session.created_at)}${paragraph("Tester", evidence.tester)}
      ${paragraph("Page at testing", evidence.target_title)}${paragraph("Page address at testing", evidence.target_url)}
      ${paragraph("Browser, device and display settings", evidence.browser)}${paragraph("Assistive technology", evidence.assistive_technology)}
      ${paragraph("Outcome", outcomeLabels[session.outcome])}${paragraph("Next review date", session.review_date ? `${session.review_date} (site date; due status evaluated in ${data.timezone})` : "Not scheduled")}
      ${paragraph("Tracked page/site state at export", session.fresh ? "Matches this record; this is not an accessibility approval" : "Changed since this record; repeat relevant tests")}
      ${paragraph("Review due at export", session.due ? "Yes" : "No")}
      ${paragraph("Guide version", evidence.guide.version)}
      ${evidence.steps.map((step) => `<section><h3>${escape(step.title)}</h3>${paragraph("Instructions", step.instruction)}${paragraph("Expected behaviour", step.expected)}${paragraph("Observed outcome", outcomeLabels[step.outcome])}${paragraph("Observation or reason", step.note)}</section>`).join("")}
      ${paragraph("Session notes", evidence.notes)}${paragraph("Evidence references", evidence.references)}
      ${paragraph("Earlier note followed up", evidence.legacy_check)}
      ${paragraph("Testing limits", evidence.limitation)}</article>`;
  }).join("");
  const legacy = Object.entries(data.legacy).map(([check, record]) => `<section><h3>${escape(check)}</h3>${paragraph("Earlier outcome", record.state)}${paragraph("Recorded at", record.updated_at)}${paragraph("Author ID", record.author)}${paragraph("Note", record.note)}</section>`).join("");
  return `<!doctype html><html lang="${escape(language)}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Manual testing history · ${escape(data.target.title)}</title><style>body{font:17px/1.65 system-ui,sans-serif;color:#17212f;background:#fff;max-width:64rem;margin:2rem auto;padding:0 1.25rem}h1,h2,h3{line-height:1.25}article{border-top:2px solid #40566c;padding:1.5rem 0;break-before:auto}section{margin:1.5rem 0;padding-left:1rem;border-left:3px solid #d3dce5}p{white-space:pre-wrap;overflow-wrap:anywhere}a{color:#174fa3}strong{font-weight:700}@media print{body{margin:0}h2,h3{break-after:avoid}}</style></head><body><main><h1>Manual testing history</h1><p>Accessibility.build · Completely free WordPress accessibility workspace</p>${paragraph("Page", data.target.title)}${paragraph("Exported at (UTC)", data.exported_at)}${paragraph("Site timezone", data.timezone)}${paragraph("Sessions included", data.total)}${paragraph("Export scope", `All retained manual sessions for this page through session #${data.through}. Later sessions are not included. Historical results do not describe the current page.`)}${paragraph("Testing limits", data.assessment.limitation)}${sessions || "<p>No guided sessions have been saved for this page.</p>"}${legacy ? `<h2>Earlier review notes</h2><p>Preserved from the earlier checklist. Browser, assistive technology and exact steps were not structured fields in these records.</p>${legacy}` : ""}</main></body></html>`;
}

export function manualCsv(data) {
  const cell = (value) => {
    let text = String(value ?? "");
    if (/^[\s]*[=+\-@]/.test(text) || /^[\t\r\n]/.test(text)) text = `'${text}`;
    return `"${text.replaceAll('"', '""')}"`;
  };
  const rows = [["Session ID", "Review ID", "Latest session in export", "Page at testing", "Page address", "Guide", "Guide version", "State or task", "Recorded at UTC", "Tester", "Browser / device", "Assistive technology", "Session outcome", "Review date", "Site timezone at export", "Matches tracked state at export", "Review due at export", "Step", "Instructions", "Expected behaviour", "Step outcome", "Observation", "Session notes", "Evidence references", "Testing limits"]];
  for (const session of data.sessions) {
    const e = session.evidence;
    for (const step of e.steps) rows.push([session.id, session.review_key, session.latest_in_export, e.target_title, e.target_url, e.guide.title, e.guide.version, e.scope, session.created_at, e.tester, e.browser, e.assistive_technology, outcomeLabels[session.outcome], session.review_date, data.timezone, session.fresh, session.due, step.title, step.instruction, step.expected, outcomeLabels[step.outcome], step.note, e.notes, e.references, data.assessment.limitation]);
  }
  for (const [check, record] of Object.entries(data.legacy)) rows.push(["Legacy note", "", "", data.target.title, "", check, "", "Not structured in earlier version", record.updated_at, record.author ? `User #${record.author}` : "Not recorded", "", "", record.state, "", data.timezone, "Not evaluated", "Not scheduled", "Earlier note", "", "", record.state, record.note, "", "", data.assessment.limitation]);
  return "\uFEFF" + rows.map((row) => row.map(cell).join(",")).join("\r\n");
}
