# Corresponding build source

The runtime is already built; Node is not required to install or use the plugin. To reproduce these assets, run `npm ci` in this development folder, then `npm run build -- --assets=../assets`. All dependencies here are development-only. Full project, test, and local-WordPress instructions accompany the source repository.
