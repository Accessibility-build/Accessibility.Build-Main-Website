<?php
/** Request-local evidence caches. Never reuse freshness-sensitive data across requests. */
defined( 'ABSPATH' ) || exit;

final class BWA_Cache {
    const GROUP = 'bwa_evidence';
    private static $request_id;

    public static function epoch_key(): string {
        if ( null === self::$request_id ) {
            self::$request_id = wp_generate_uuid4();
            wp_cache_add_non_persistent_groups( array( self::GROUP ) );
        }
        // The random request namespace remains safe even when a cache drop-in
        // ignores non-persistent groups. Blog IDs also isolate switch_to_blog().
        return 'epoch:' . get_current_blog_id() . ':' . self::$request_id;
    }

    public static function key( string $operation, array $arguments = array() ): string {
        $epoch_key = self::epoch_key();
        $epoch = wp_cache_get( $epoch_key, self::GROUP );
        if ( ! is_string( $epoch ) ) {
            $epoch = wp_generate_uuid4();
            wp_cache_set( $epoch_key, $epoch, self::GROUP, MINUTE_IN_SECONDS );
        }
        return hash( 'sha256', wp_json_encode( array( $epoch_key, $epoch, get_current_user_id(), $operation, $arguments ) ) );
    }

    public static function can_store( $value ): bool {
        global $wpdb;
        // A database error must never become cached empty evidence. Bound each
        // value so full reports cannot overwhelm a persistent cache drop-in.
        return '' === $wpdb->last_error && strlen( (string) wp_json_encode( $value ) ) <= 512 * KB_IN_BYTES;
    }
}
