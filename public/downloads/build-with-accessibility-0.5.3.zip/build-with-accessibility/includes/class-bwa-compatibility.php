<?php
/** Track published builder sources and keep private diagnostics out of optimizers. */
defined( 'ABSPATH' ) || exit;

final class BWA_Compatibility {
    private const SOURCE_KEYS = array( '_elementor_edit_mode', '_elementor_data', '_elementor_page_settings', '_fl_builder_enabled', '_fl_builder_data', '_fl_builder_data_settings', 'panels_data', 'brizy_enabled', 'brizy', 'brizy-compiled-sections', '_wp_page_template', '_thumbnail_id' );
    private const SHARED_TYPES = array( 'elementor_library', 'fl-builder-template', 'editor-template', 'brizy-global-block' );

    public static function init(): void {
        // Autoptimize decides whether to buffer before template_redirect. Opt out
        // early only for a nonce-protected editor/admin preview. The full ticket,
        // actor, source and queried-page guards still run before loading scripts.
        add_filter( 'autoptimize_filter_noptimize', static function ( $skip ) { return $skip || self::private_preview(); } );
        foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
            add_action( $hook, array( __CLASS__, 'changed_meta' ), 10, 3 );
        }
        add_action( 'save_post', array( __CLASS__, 'changed_shared' ) );
        add_action( 'before_delete_post', array( __CLASS__, 'changed_shared' ) );
        foreach ( array( 'added_option', 'updated_option', 'deleted_option' ) as $hook ) {
            add_action( $hook, static function ( $option ) {
                if ( in_array( $option, array( 'elementor_active_kit', 'elementor_css_print_method', 'siteorigin_panels_settings' ), true ) ) { self::changed_environment(); }
            } );
        }
    }

    /** Only published source fields: draft layouts, generated CSS and repair receipts are excluded. */
    public static function source( int $post_id ): array {
        $values = array();
        foreach ( self::SOURCE_KEYS as $key ) {
            if ( metadata_exists( 'post', $post_id, $key ) ) { $values[ $key ] = get_post_meta( $post_id, $key, true ); }
        }
        return $values;
    }

    public static function changed_meta( $meta_id, int $post_id, string $key ): void {
        if ( ! in_array( $key, self::SOURCE_KEYS, true ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) { return; }
        BWA_Audits::changed_home_content( $post_id );
        self::changed_shared( $post_id );
    }

    public static function changed_shared( int $post_id ): void {
        if ( in_array( get_post_type( $post_id ), self::SHARED_TYPES, true ) && 'auto-draft' !== get_post_status( $post_id ) ) { self::changed_environment(); }
    }

    private static function changed_environment(): void {
        update_option( 'bwa_compatibility_revision', wp_generate_uuid4(), false );
    }

    public static function render_context( int $post_id ): string {
        return hash( 'sha256', wp_json_encode( array( self::source( $post_id ), BWA_Audits::environment() ) ) );
    }

    public static function owner( int $post_id ): string {
        if ( 'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true ) ) { return 'Elementor'; }
        if ( get_post_meta( $post_id, '_fl_builder_enabled', true ) ) { return 'Beaver Builder'; }
        $panels = get_post_meta( $post_id, 'panels_data', true );
        if ( is_array( $panels ) && ! empty( $panels['widgets'] ) ) { return 'SiteOrigin'; }
        if ( get_post_meta( $post_id, 'brizy_enabled', true ) ) { return 'Brizy'; }
        return '';
    }

    public static function repair_notice( int $post_id ): string {
        $owner = self::owner( $post_id );
        /* translators: %s: the page builder that owns the rendered content. */
        return $owner ? sprintf( __( '%s controls this page’s content. Make repairs in that builder, then run a new page scan and any relevant manual checks. Native block repairs and undo are paused to protect the builder’s content.', 'build-with-accessibility' ), $owner ) : '';
    }

    public static function guard( int $post_id ) {
        $notice = self::repair_notice( $post_id );
        return $notice ? new WP_Error( 'bwa_builder_owned', $notice, array( 'status' => 409 ) ) : true;
    }

    private static function private_preview(): bool {
        if ( current_user_can( 'manage_options' ) && is_string( $_GET['bwa_audit'] ?? null ) && is_string( $_GET['_bwa_audit_nonce'] ?? null ) ) {
            $token = sanitize_text_field( wp_unslash( $_GET['bwa_audit'] ) );
            if ( preg_match( '/^[a-f0-9-]{36}$/', $token ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwa_audit_nonce'] ) ), 'bwa_audit_' . $token ) ) { return true; }
        }
        if ( is_string( $_GET['bwa_check'] ?? null ) && is_string( $_GET['bwa_post'] ?? null ) && is_string( $_GET['_bwa_nonce'] ?? null ) ) {
            $id = sanitize_text_field( wp_unslash( $_GET['bwa_check'] ) );
            if ( preg_match( '/^[a-f0-9-]{36}$/', $id ) && current_user_can( 'edit_post', absint( $_GET['bwa_post'] ) ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwa_nonce'] ) ), 'bwa_check_' . $id ) ) { return true; }
        }
        return false;
    }

    /** Capability and nonce checks must pass. A valid ticket is still required to run axe. */
    public static function diagnostic(): void {
        if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
        if ( ! defined( 'DONOTMINIFY' ) ) { define( 'DONOTMINIFY', true ); }
        if ( ! defined( 'LITESPEED_NO_PAGEOPTM' ) ) { define( 'LITESPEED_NO_PAGEOPTM', true ); }
        add_filter( 'autoptimize_filter_noptimize', '__return_true' );
        do_action( 'litespeed_control_set_nocache', 'Authenticated accessibility diagnostic' );
        if ( function_exists( 'wpfc_exclude_current_page' ) ) { wpfc_exclude_current_page(); }
        nocache_headers();
        header( 'Referrer-Policy: same-origin' );
    }
}
