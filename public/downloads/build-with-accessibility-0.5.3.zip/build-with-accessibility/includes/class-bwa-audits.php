<?php
/** Local audit storage, authenticated browser runs, and the administration API. */
defined( 'ABSPATH' ) || exit;

final class BWA_Audits {
    const DB_VERSION = '3';
    const MANUAL_IDS = array( 'keyboard', 'focus', 'zoom', 'screen_reader', 'forms', 'meaning', 'media', 'dynamic' );

    public static function init(): void {
        add_action( 'admin_init', static function () {
            if ( get_option( 'bwa_db_version' ) !== self::DB_VERSION && current_user_can( 'manage_options' ) ) {
                self::install();
            }
        } );
        add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
        add_action( 'template_redirect', array( __CLASS__, 'diagnostic' ), 0 );
        add_action( 'before_delete_post', array( __CLASS__, 'delete_target' ) );
        add_action( 'save_post', array( __CLASS__, 'changed_home_content' ) );
        foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
            add_action( $hook, static function ( $meta_id, $post_id, $meta_key ) {
                if ( is_string( $meta_key ) && str_starts_with( $meta_key, '_bwa_' ) ) {
                    wp_cache_delete( BWA_Cache::epoch_key(), BWA_Cache::GROUP );
                }
            }, 10, 3 );
        }
    }

    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        dbDelta( "CREATE TABLE {$wpdb->prefix}bwa_scans (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            target_key varchar(40) NOT NULL,
            run_token varchar(36) NOT NULL,
            status varchar(20) NOT NULL,
            source_hash varchar(64) NOT NULL,
            content_hash varchar(64) NOT NULL DEFAULT '',
            environment_hash varchar(64) NOT NULL,
            profile varchar(20) NOT NULL,
            viewport varchar(20) NOT NULL,
            comparison_context text NULL,
            created_at datetime NOT NULL,
            author bigint(20) unsigned NOT NULL,
            summary longtext NOT NULL,
            report longtext NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY run_token (run_token),
            KEY target_status (target_key,status,id)
        ) $charset;" );
        dbDelta( "CREATE TABLE {$wpdb->prefix}bwa_issues (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            scan_id bigint(20) unsigned NOT NULL,
            target_key varchar(40) NOT NULL,
            fingerprint varchar(64) NOT NULL,
            rule_id varchar(100) NOT NULL,
            impact varchar(20) NOT NULL,
            kind varchar(20) NOT NULL,
            disposition varchar(20) NOT NULL DEFAULT 'open',
            note text NOT NULL,
            details longtext NOT NULL,
            PRIMARY KEY  (id),
            KEY scan_id (scan_id),
            KEY target_fingerprint (target_key,fingerprint),
            KEY kind_impact (kind,impact)
        ) $charset;" );
        BWA_Monitoring::install( $charset );
        BWA_Manual::install( $charset );
        // Older rows intentionally have no comparison context. A nullable column
        // also permits adding this field to populated SQLite installations.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read actual custom-table definitions after dbDelta; schema verification cannot use cached data.
        $columns = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $wpdb->prefix . 'bwa_scans' ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read actual custom-table definitions after dbDelta; schema verification cannot use cached data.
        $baseline_table = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix . 'bwa_baselines' ) ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read actual custom-table definitions after dbDelta; schema verification cannot use cached data.
        $manual_table = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix . 'bwa_manual_sessions' ) ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read actual custom-table definitions after dbDelta; schema verification cannot use cached data.
        $manual_columns = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $wpdb->prefix . 'bwa_manual_sessions' ) );
        if ( in_array( 'legacy_check', $manual_columns, true ) && in_array( 'comparison_context', $columns, true ) && $baseline_table === $wpdb->prefix . 'bwa_baselines' && $manual_table === $wpdb->prefix . 'bwa_manual_sessions' ) {
            update_option( 'bwa_db_version', self::DB_VERSION, false );
        }
    }

    public static function permission(): bool { return current_user_can( 'manage_options' ); }

    public static function changed_home_content( int $post_id ): void {
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ! in_array( get_post_type( $post_id ), self::types(), true ) ) { return; }
        // Timestamps alone miss multiple saves within the same second.
        update_option( 'bwa_home_content_revision', wp_generate_uuid4(), false );
    }

    private static function error( string $message, int $status = 422 ): WP_Error {
        return new WP_Error( 'bwa_audit', $message, array( 'status' => $status ) );
    }

    public static function routes(): void {
        $routes = array(
            '/workspace' => array( 'GET', 'overview' ),
            '/targets' => array( 'GET', 'targets' ),
            '/scan-runs' => array( 'POST', 'start' ),
            '/scan-runs/(?P<token>[a-f0-9-]{36})' => array( 'POST', 'finish' ),
            '/issues' => array( 'GET', 'issues' ),
            '/issues/(?P<id>\d+)' => array( 'PATCH', 'triage' ),
            '/scans' => array( 'GET', 'scans' ),
            '/scans/(?P<id>\d+)' => array( 'GET', 'scan' ),
            '/repair-history' => array( 'GET', 'repairs' ),
        );
        foreach ( $routes as $path => $route ) {
            register_rest_route( 'bwa/v1', $path, array( 'methods' => $route[0], 'callback' => array( __CLASS__, $route[1] ), 'permission_callback' => array( __CLASS__, 'permission' ) ) );
        }
        foreach ( array( '/settings' => 'settings_route', '/manual/(?P<target>home|\d+)' => 'manual' ) as $path => $callback ) {
            register_rest_route( 'bwa/v1', $path, array( 'methods' => 'GET,POST', 'callback' => array( __CLASS__, $callback ), 'permission_callback' => array( __CLASS__, 'permission' ) ) );
        }
    }

    public static function settings(): array {
        return array_merge( array( 'profile' => 'all', 'viewport' => 'desktop', 'settle_ms' => 500, 'history_limit' => 3 ), (array) get_option( 'bwa_settings', array() ) );
    }

    public static function settings_route( WP_REST_Request $request ) {
        if ( 'POST' === $request->get_method() ) {
            $value = $request->get_json_params();
            if ( ! is_array( $value ) || ! in_array( $value['profile'] ?? '', array( 'all', 'wcag22aa' ), true ) || ! in_array( $value['viewport'] ?? '', array( 'desktop', 'mobile' ), true ) || ! is_int( $value['settle_ms'] ?? null ) || $value['settle_ms'] < 0 || $value['settle_ms'] > 5000 || ! is_int( $value['history_limit'] ?? null ) || $value['history_limit'] < 1 || $value['history_limit'] > 10 ) {
                return self::error( __( 'Choose a valid scan profile, viewport, wait time, and history limit.', 'build-with-accessibility' ) );
            }
            update_option( 'bwa_settings', array_intersect_key( $value, self::settings() ), false );
            global $wpdb;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read current custom scan targets before applying retention; no core API represents these records.
            foreach ( $wpdb->get_col( "SELECT DISTINCT target_key FROM {$wpdb->prefix}bwa_scans" ) as $key ) {
                self::prune( $key );
            }
        }
        return self::settings();
    }

    private static function read_error(): WP_Error {
        return self::error( __( 'Stored accessibility records could not be read. Restore database access and refresh; no checks have been marked complete.', 'build-with-accessibility' ), 503 );
    }

    private static function types(): array {
        return array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment' ) ) );
    }

    public static function separate_home(): bool {
        // A static front page is already represented by its owning Page entry.
        return 'page' !== get_option( 'show_on_front' ) || ! get_option( 'page_on_front' );
    }

    public static function target( string $key ) {
        if ( 'home' === $key ) {
            return array( 'key' => 'home', 'id' => 0, 'title' => __( 'Homepage', 'build-with-accessibility' ), 'type' => 'homepage', 'status' => 'publish', 'url' => home_url( '/' ), 'edit_url' => '', 'context' => 'Signed-in homepage', 'source_hash' => hash( 'sha256', wp_json_encode( array( get_option( 'show_on_front' ), get_option( 'page_on_front' ), get_option( 'page_for_posts' ), get_lastpostmodified( 'GMT' ), get_option( 'bwa_home_content_revision', '' ) ) ) ), 'content_hash' => '' );
        }
        $post = ctype_digit( $key ) ? get_post( (int) $key ) : null;
        if ( ! $post || ! in_array( $post->post_type, self::types(), true ) || ! in_array( $post->post_status, array( 'publish', 'private', 'draft', 'pending', 'future' ), true ) || ! current_user_can( 'edit_post', $post->ID ) ) {
            return self::error( __( 'This page is unavailable or you do not have permission to scan it.', 'build-with-accessibility' ), 403 );
        }
        $public = is_post_publicly_viewable( $post );
        $source = array( $post->post_content, $post->post_title, $post->post_excerpt, $post->post_status, get_permalink( $post ), $post->ID === (int) get_option( 'page_for_posts' ) ? get_option( 'bwa_home_content_revision', '' ) : null );
        $builder_source = BWA_Compatibility::source( $post->ID );
        if ( $builder_source ) { $source[] = $builder_source; }
        return array(
            'key' => (string) $post->ID, 'id' => $post->ID, 'title' => get_the_title( $post ) ?: __( '(Untitled)', 'build-with-accessibility' ),
            'type' => $post->post_type, 'status' => $post->post_status, 'url' => $public ? get_permalink( $post ) : get_preview_post_link( $post ),
            'edit_url' => get_edit_post_link( $post->ID, 'raw' ), 'context' => $public ? 'Signed-in page' : 'Saved draft/private preview',
            'source_hash' => hash( 'sha256', wp_json_encode( $source ) ),
            'content_hash' => BWA_Images::hash( $post->post_content ),
        );
    }

    public static function environment(): string {
        $theme = wp_get_theme();
        $plugins = array();
        foreach ( (array) get_option( 'active_plugins', array() ) as $file ) {
            $plugins[ $file ] = file_exists( WP_PLUGIN_DIR . '/' . $file ) ? filemtime( WP_PLUGIN_DIR . '/' . $file ) : 0;
        }
        $entities = get_posts( array( 'post_type' => array( 'wp_global_styles', 'wp_template', 'wp_template_part' ), 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) );
        $entity_sources = array_map( static fn( $post ) => array( $post->ID, $post->post_content ), $entities );
        return hash( 'sha256', wp_json_encode( array( get_bloginfo( 'version' ), BWA_AXE_VERSION, $theme->get_stylesheet(), $theme->get( 'Version' ), get_theme_mods(), wp_get_custom_css(), $entity_sources, $plugins, get_site_option( 'active_sitewide_plugins', array() ), get_bloginfo( 'name' ), get_bloginfo( 'description' ), get_option( 'show_on_front' ), get_option( 'page_on_front' ), get_option( 'page_for_posts' ), get_option( 'posts_per_page' ), get_option( 'bwa_compatibility_revision', '' ) ) ) );
    }

    private static function latest( string $key, bool $fresh = false ): ?array {
        global $wpdb;
        $cache_key = BWA_Cache::key( 'latest-scan', array( $key ) );
        $found = false;
        $row = $fresh ? null : wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom scan index; bounded request cache for views, with fresh reads explicitly selected by write guards.
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT id,target_key,status,source_hash,content_hash,environment_hash,profile,viewport,created_at,summary FROM {$wpdb->prefix}bwa_scans WHERE target_key=%s AND status='completed' ORDER BY id DESC LIMIT 1", $key ), ARRAY_A );
            if ( ! $fresh && BWA_Cache::can_store( $row ) ) { wp_cache_set( $cache_key, $row, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        return $row;
    }

    private static function last_attempt( string $key ): ?array {
        global $wpdb;
        $cache_key = BWA_Cache::key( 'last-attempt', array( $key ) );
        $found = false;
        $row = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom scan index; raw results use a bounded request cache.
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT id,status,created_at FROM {$wpdb->prefix}bwa_scans WHERE target_key=%s AND status IN ('completed','failed') ORDER BY id DESC LIMIT 1", $key ), ARRAY_A );
            if ( BWA_Cache::can_store( $row ) ) { wp_cache_set( $cache_key, $row, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        if ( $row ) { $row['id'] = (int) $row['id']; $row['created_at'] .= 'Z'; }
        return $row;
    }

    private static function fresh( array $scan, array $target, ?string $environment = null ): bool {
        return $scan['source_hash'] === $target['source_hash'] && $scan['environment_hash'] === ( $environment ?? self::environment() );
    }

    public static function targets( WP_REST_Request $request ) {
        global $wpdb;
        $page = max( 1, (int) $request->get_param( 'page' ) );
        $size = max( 1, min( 100, (int) ( $request->get_param( 'per_page' ) ?: 25 ) ) );
        $search = sanitize_text_field( (string) $request->get_param( 'search' ) );
        $include_home = self::separate_home() && ( '' === $search || false !== stripos( __( 'Homepage', 'build-with-accessibility' ), $search ) );
        $query = new WP_Query( array( 'post_type' => self::types(), 'post_status' => array( 'publish', 'private', 'draft', 'pending', 'future' ), 'posts_per_page' => $size, 'paged' => $page, 's' => $search, 'orderby' => 'ID', 'order' => 'DESC' ) );
        $items = array();
        if ( 1 === $page && $include_home ) { $items[] = self::target( 'home' ); }
        foreach ( $query->posts as $post ) {
            $target = self::target( (string) $post->ID );
            if ( ! is_wp_error( $target ) ) { $items[] = $target; }
        }
        $environment = self::environment();
        foreach ( $items as &$item ) {
            $last = self::latest( $item['key'] );
            if ( $wpdb->last_error ) { return self::read_error(); }
            $item['last_attempt'] = self::last_attempt( $item['key'] );
            if ( $wpdb->last_error ) { return self::read_error(); }
            $item['scan'] = $last ? array( 'id' => (int) $last['id'], 'summary' => json_decode( $last['summary'], true ), 'created_at' => $last['created_at'] . 'Z', 'fresh' => self::fresh( $last, $item, $environment ), 'profile' => $last['profile'], 'viewport' => $last['viewport'] ) : null;
        }
        return array( 'items' => $items, 'total' => (int) $query->found_posts + ( $include_home ? 1 : 0 ), 'pages' => max( 1, (int) $query->max_num_pages ), 'page' => $page );
    }

    public static function overview() {
        global $wpdb;
        $cache_key = BWA_Cache::key( 'overview', array() );
        $raw = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Aggregate of custom scan records; raw results are request-cached and permissions/freshness recalculated.
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT s.id,s.target_key,s.source_hash,s.environment_hash,s.summary FROM %i s INNER JOIN (SELECT target_key, MAX(id) AS scan_id FROM %i WHERE status='completed' GROUP BY target_key) l ON l.scan_id=s.id",
                $wpdb->prefix . 'bwa_scans', $wpdb->prefix . 'bwa_scans'
            ), ARRAY_A );
            $raw = array( $rows );
            if ( BWA_Cache::can_store( $raw ) ) { wp_cache_set( $cache_key, $raw, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        list( $rows ) = $raw;
        if ( ! is_array( $rows ) || $wpdb->last_error ) { return self::read_error(); }
        $totals = array( 'scanned' => 0, 'stale' => 0, 'violations' => 0, 'incomplete' => 0, 'critical' => 0, 'serious' => 0 );
        $environment = self::environment();
        foreach ( $rows as $row ) {
            if ( 'home' === $row['target_key'] && ! self::separate_home() ) { continue; }
            $target = self::target( $row['target_key'] );
            if ( is_wp_error( $target ) ) { continue; }
            ++$totals['scanned'];
            if ( ! self::fresh( $row, $target, $environment ) ) { ++$totals['stale']; }
            $summary = json_decode( $row['summary'], true );
            foreach ( array( 'violations', 'incomplete', 'critical', 'serious' ) as $key ) { $totals[ $key ] += $summary[ $key ] ?? 0; }
        }
        $totals['pages'] = self::separate_home() ? 1 : 0;
        foreach ( self::types() as $type ) {
            $counts = wp_count_posts( $type );
            foreach ( array( 'publish', 'private', 'draft', 'pending', 'future' ) as $status ) { $totals['pages'] += (int) ( $counts->$status ?? 0 ); }
        }
        $request = new WP_REST_Request( 'GET' );
        $request->set_param( 'per_page', 5 );
        $request->set_param( 'disposition', 'open' );
        $priority = self::issues( $request ); $recent = self::scans( $request );
        if ( is_wp_error( $priority ) ) { return $priority; }
        if ( is_wp_error( $recent ) ) { return $recent; }
        return array( 'totals' => $totals, 'priority' => $priority['items'], 'recent' => $recent['items'], 'settings' => self::settings(), 'axe_version' => BWA_AXE_VERSION );
    }

    public static function start( WP_REST_Request $request ) {
        $key = $request->get_param( 'target' );
        if ( ! is_string( $key ) ) { return self::error( __( 'Choose a page to scan.', 'build-with-accessibility' ) ); }
        $target = self::target( $key );
        if ( is_wp_error( $target ) ) { return $target; }
        $settings = self::settings();
        $token = wp_generate_uuid4();
        $ticket = array( 'target' => $target, 'actor' => get_current_user_id(), 'environment_hash' => self::environment(), 'settings' => $settings );
        set_transient( 'bwa_run_' . $token, $ticket, 5 * MINUTE_IN_SECONDS );
        $url = add_query_arg( array( 'bwa_audit' => $token, '_bwa_audit_nonce' => wp_create_nonce( 'bwa_audit_' . $token ) ), $target['url'] );
        return array( 'token' => $token, 'url' => $url, 'target' => $target, 'profile' => $settings['profile'], 'viewport' => $settings['viewport'], 'width' => 'mobile' === $settings['viewport'] ? 390 : 1366, 'height' => 'mobile' === $settings['viewport'] ? 844 : 900 );
    }

    private static function ticket( string $token ) {
        $ticket = get_transient( 'bwa_run_' . $token );
        if ( ! is_array( $ticket ) || $ticket['actor'] !== get_current_user_id() ) {
            return self::error( __( 'This scan session expired. Start a new scan.', 'build-with-accessibility' ), 409 );
        }
        $target = self::target( $ticket['target']['key'] );
        if ( is_wp_error( $target ) || $target['source_hash'] !== $ticket['target']['source_hash'] || self::environment() !== $ticket['environment_hash'] ) {
            return self::error( __( 'The page or site configuration changed during this scan. Scan it again to record current evidence.', 'build-with-accessibility' ), 409 );
        }
        return $ticket;
    }

    private static function short_text( $value, int $limit = 2000 ): string {
        return is_string( $value ) ? sanitize_textarea_field( mb_substr( $value, 0, $limit ) ) : '';
    }

    private static function evidence_text( $value, int $limit ): string {
        if ( ! is_string( $value ) ) { return ''; }
        // Rule explanations use literal tag names such as <ul> and <li>.
        // Preserve them as text; React escapes every display of this evidence.
        $text = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', wp_check_invalid_utf8( $value ) );
        return mb_substr( $text, 0, $limit );
    }

    private static function clean_report( $report ) {
        if ( ! is_array( $report ) || ( $report['engine']['version'] ?? '' ) !== BWA_AXE_VERSION || ( $report['engine']['name'] ?? '' ) !== 'axe-core' ) {
            return self::error( __( 'The scan did not return the bundled axe-core engine version.', 'build-with-accessibility' ) );
        }
        $out = array( 'engine' => array( 'name' => 'axe-core', 'version' => BWA_AXE_VERSION ), 'violations' => array(), 'incomplete' => array(), 'passes' => array(), 'inapplicable' => array(), 'frames' => array( 'total' => absint( $report['frames']['total'] ?? 0 ), 'unavailable' => absint( $report['frames']['unavailable'] ?? 0 ) ) );
        $count = 0;
        foreach ( array( 'violations', 'incomplete', 'passes', 'inapplicable' ) as $kind ) {
            if ( ! isset( $report[ $kind ] ) || ! is_array( $report[ $kind ] ) || count( $report[ $kind ] ) > 500 ) {
                return self::error( __( 'The scan returned an invalid rule collection.', 'build-with-accessibility' ) );
            }
            foreach ( $report[ $kind ] as $rule ) {
                if ( ! is_array( $rule ) || ! is_string( $rule['id'] ?? null ) || ! preg_match( '/^[a-z0-9-]{1,100}$/', $rule['id'] ) ) { return self::error( __( 'The scan contains an invalid rule.', 'build-with-accessibility' ) ); }
                $item = array( 'id' => $rule['id'], 'help' => self::evidence_text( $rule['help'] ?? '', 500 ), 'description' => self::evidence_text( $rule['description'] ?? '', 1000 ), 'tags' => array_values( array_map( 'sanitize_text_field', array_filter( array_slice( is_array( $rule['tags'] ?? null ) ? $rule['tags'] : array(), 0, 40 ), 'is_string' ) ) ), 'helpUrl' => 'https://dequeuniversity.com/rules/axe/' . substr( BWA_AXE_VERSION, 0, strrpos( BWA_AXE_VERSION, '.' ) ) . '/' . $rule['id'], 'nodes_count' => absint( $rule['nodes_count'] ?? 0 ), 'nodes' => array() );
                if ( in_array( $kind, array( 'violations', 'incomplete' ), true ) ) {
                    if ( ! is_array( $rule['nodes'] ?? null ) ) { return self::error( __( 'A finding is missing its affected elements.', 'build-with-accessibility' ) ); }
                    foreach ( $rule['nodes'] as $node ) {
                        if ( ++$count > 6000 || ! is_array( $node ) || ! is_array( $node['target'] ?? null ) || strlen( wp_json_encode( $node['target'] ) ) > 16000 ) { return self::error( __( 'This page returned too many findings to store in one scan. No partial pass was recorded.', 'build-with-accessibility' ), 413 ); }
                        $path = $node['block_path'] ?? null;
                        $item['nodes'][] = array(
                            'target' => json_decode( wp_json_encode( $node['target'] ), true ),
                            // Markup is evidence only. The admin renders it as escaped text.
                            'html' => is_string( $node['html'] ?? null ) ? mb_substr( $node['html'], 0, 6000 ) : '',
                            'failureSummary' => self::evidence_text( $node['failureSummary'] ?? '', 5000 ),
                            'impact' => in_array( $node['impact'] ?? '', array( 'critical', 'serious', 'moderate', 'minor' ), true ) ? $node['impact'] : 'unknown',
                            'block_path' => BWA_Images::valid_path( $path ) ? $path : null,
                            'repair_target' => is_string( $node['repair_target'] ?? null ) && strlen( $node['repair_target'] ) <= 200 && preg_match( '/^\d+(\.\d+)*:(heading|link|label):\d+$/', $node['repair_target'] ) ? $node['repair_target'] : null,
                        );
                    }
                    $item['nodes_count'] = count( $item['nodes'] );
                }
                $out[ $kind ][] = $item;
            }
        }
        return $out;
    }

    public static function finish( WP_REST_Request $request ) {
        global $wpdb;
        $token = (string) $request['token'];
        $ticket = self::ticket( $token );
        if ( is_wp_error( $ticket ) ) { return $ticket; }
        if ( strlen( $request->get_body() ) > 4 * MB_IN_BYTES ) { return self::error( __( 'The scan exceeds the local report size limit. No partial pass was recorded.', 'build-with-accessibility' ), 413 ); }
        $failed = 'failed' === $request->get_param( 'status' );
        $report = $failed ? array( 'error' => self::short_text( $request->get_param( 'error' ) ) ) : self::clean_report( $request->get_param( 'report' ) );
        if ( is_wp_error( $report ) ) { return $report; }
        $summary = array( 'violations' => 0, 'incomplete' => 0, 'critical' => 0, 'serious' => 0, 'moderate' => 0, 'minor' => 0, 'passed_rules' => count( $report['passes'] ?? array() ), 'inapplicable_rules' => count( $report['inapplicable'] ?? array() ) );
        $summary['unavailable_frames'] = $report['frames']['unavailable'] ?? 0;
        $summary['incomplete_rules'] = count( $report['incomplete'] ?? array() );
        foreach ( array( 'violations', 'incomplete' ) as $kind ) {
            foreach ( $report[ $kind ] ?? array() as $rule ) {
                $summary[ $kind ] += count( $rule['nodes'] );
                if ( 'violations' === $kind ) { foreach ( $rule['nodes'] as $node ) { if ( isset( $summary[ $node['impact'] ] ) ) { ++$summary[ $node['impact'] ]; } } }
            }
        }
        $key = $ticket['target']['key'];
        $previous = self::latest( $key, true );
        $report['context'] = array( 'target' => $ticket['target'], 'profile' => $ticket['settings']['profile'], 'viewport' => $ticket['settings']['viewport'], 'scope' => 'Rendered signed-in page; WordPress admin toolbar excluded. Hidden states and unavailable frames require review.' );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Store private scan/issue evidence or read current carry-forward decisions; writes invalidate the request cache.
        $inserted = $wpdb->insert( $wpdb->prefix . 'bwa_scans', array(
            'target_key' => $key, 'run_token' => $token, 'status' => $failed ? 'failed' : 'pending', 'source_hash' => $ticket['target']['source_hash'], 'content_hash' => $ticket['target']['content_hash'],
            'environment_hash' => $ticket['environment_hash'], 'profile' => $ticket['settings']['profile'], 'viewport' => $ticket['settings']['viewport'],
            'comparison_context' => wp_json_encode( BWA_Monitoring::context( $ticket['settings'], $ticket['target'] ) ),
            'created_at' => current_time( 'mysql', true ), 'author' => get_current_user_id(), 'summary' => wp_json_encode( $summary ), 'report' => wp_json_encode( $report ),
        ) );
        if ( false === $inserted ) { return self::error( __( 'WordPress could not store this scan. Check database access and try again.', 'build-with-accessibility' ), 500 ); }
        $scan_id = (int) $wpdb->insert_id;
        wp_cache_delete( BWA_Cache::epoch_key(), BWA_Cache::GROUP );
        foreach ( array( 'violations', 'incomplete' ) as $kind ) {
            foreach ( $report[ $kind ] ?? array() as $rule ) {
                foreach ( $rule['nodes'] as $node ) {
                    $fingerprint = hash( 'sha256', $kind . $rule['id'] . wp_json_encode( $node['target'] ) );
                    $decision = null;
                    if ( $previous && $previous['source_hash'] === $ticket['target']['source_hash'] && $previous['environment_hash'] === $ticket['environment_hash'] && $previous['profile'] === $ticket['settings']['profile'] && $previous['viewport'] === $ticket['settings']['viewport'] ) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Store private scan/issue evidence or read current carry-forward decisions; writes invalidate the request cache.
                        $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bwa_issues WHERE scan_id=%d AND fingerprint=%s LIMIT 1", $previous['id'], $fingerprint ), ARRAY_A );
                        if ( $old && ( json_decode( $old['details'], true )['html'] ?? '' ) === $node['html'] ) { $decision = $old; }
                    }
                    $details = array_merge( $node, array( 'help' => $rule['help'], 'description' => $rule['description'], 'helpUrl' => $rule['helpUrl'], 'tags' => $rule['tags'] ) );
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Store private scan/issue evidence or read current carry-forward decisions; writes invalidate the request cache.
                    if ( false === $wpdb->insert( $wpdb->prefix . 'bwa_issues', array( 'scan_id' => $scan_id, 'target_key' => $key, 'fingerprint' => $fingerprint, 'rule_id' => $rule['id'], 'impact' => $node['impact'], 'kind' => $kind, 'disposition' => $decision['disposition'] ?? 'open', 'note' => $decision['note'] ?? '', 'details' => wp_json_encode( $details ) ) ) ) {
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Store private scan/issue evidence or read current carry-forward decisions; writes invalidate the request cache.
                        $wpdb->delete( $wpdb->prefix . 'bwa_issues', array( 'scan_id' => $scan_id ) );
                        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Store private scan/issue evidence or read current carry-forward decisions; writes invalidate the request cache.
                        $wpdb->delete( $wpdb->prefix . 'bwa_scans', array( 'id' => $scan_id ) );
                        return self::error( __( 'Some findings could not be saved. The incomplete scan was discarded; try again.', 'build-with-accessibility' ), 500 );
                    }
                }
            }
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Store private scan/issue evidence or read current carry-forward decisions; writes invalidate the request cache.
        if ( ! $failed && false === $wpdb->update( $wpdb->prefix . 'bwa_scans', array( 'status' => 'completed' ), array( 'id' => $scan_id ) ) ) { return self::error( __( 'The scan could not be finalized. Try again.', 'build-with-accessibility' ), 500 ); }
        delete_transient( 'bwa_run_' . $token );
        self::prune( $key );
        wp_cache_delete( BWA_Cache::epoch_key(), BWA_Cache::GROUP );
        return array( 'id' => $scan_id, 'status' => $failed ? 'failed' : 'completed', 'summary' => $summary );
    }

    public static function prune( string $key ): void {
        global $wpdb;
        wp_cache_delete( BWA_Cache::epoch_key(), BWA_Cache::GROUP );
        foreach ( array( 'completed' => self::settings()['history_limit'], 'failed' => 1, 'pending' => 1 ) as $status => $keep ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Current retention selection and deletion in private evidence tables; invalidate cached views before cleanup.
            $ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM %i WHERE target_key=%s AND status=%s AND id NOT IN (SELECT scan_id FROM %i WHERE target_key=%s) ORDER BY id DESC LIMIT 100000 OFFSET %d", $wpdb->prefix . 'bwa_scans', $key, $status, $wpdb->prefix . 'bwa_baselines', $key, $keep ) );
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Current retention selection and deletion in private evidence tables; invalidate cached views before cleanup.
            foreach ( $ids as $id ) { $wpdb->delete( $wpdb->prefix . 'bwa_issues', array( 'scan_id' => $id ) ); $wpdb->delete( $wpdb->prefix . 'bwa_scans', array( 'id' => $id ) ); }
        }
    }

    public static function delete_target( int $post_id ): void {
        global $wpdb;
        self::changed_home_content( $post_id );
        if ( get_option( 'bwa_db_version' ) !== self::DB_VERSION ) { return; }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Delete private evidence belonging to this post; invalidate the request cache after cleanup.
        $wpdb->delete( $wpdb->prefix . 'bwa_issues', array( 'target_key' => (string) $post_id ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Delete private evidence belonging to this post; invalidate the request cache after cleanup.
        $wpdb->delete( $wpdb->prefix . 'bwa_scans', array( 'target_key' => (string) $post_id ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Delete private evidence belonging to this post; invalidate the request cache after cleanup.
        $wpdb->delete( $wpdb->prefix . 'bwa_baselines', array( 'target_key' => (string) $post_id ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Delete private evidence belonging to this post; invalidate the request cache after cleanup.
        $wpdb->delete( $wpdb->prefix . 'bwa_manual_sessions', array( 'target_key' => (string) $post_id ) );
        wp_cache_delete( BWA_Cache::epoch_key(), BWA_Cache::GROUP );
    }

    public static function issues( WP_REST_Request $request ) {
        global $wpdb;
        $page = max( 1, (int) $request->get_param( 'page' ) );
        $size = max( 1, min( 200, (int) ( $request->get_param( 'per_page' ) ?: 25 ) ) );
        $filters = array();
        foreach ( array( 'impact', 'kind', 'disposition', 'target_key', 'search' ) as $filter ) {
            $raw = $request->get_param( $filter );
            $filters[ $filter ] = is_string( $raw ) ? sanitize_text_field( $raw ) : '';
        }
        $include_home = self::separate_home() || 'home' === $filters['target_key'];
        $like = '%' . $wpdb->esc_like( $filters['search'] ) . '%';
        // Keep table identifiers, filter values, and paging in placeholders.
        // There is no user-controlled SQL fragment or column name.
        $cache_key = BWA_Cache::key( 'issue-list', array( $filters, $include_home, $page, $size ) );
        $raw = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        $read_error = false;
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Filtered custom issue/scan join; all identifiers/values are bound and raw results are request-cached.
            $total = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM %i i
                INNER JOIN (SELECT target_key, MAX(id) AS scan_id FROM %i WHERE status='completed' GROUP BY target_key) l ON l.scan_id=i.scan_id
                INNER JOIN %i s ON s.id=i.scan_id
                WHERE (%d=1 OR i.target_key<>'home')
                AND (%s='' OR i.impact=%s) AND (%s='' OR i.kind=%s)
                AND (%s='' OR i.disposition=%s) AND (%s='' OR i.target_key=%s)
                AND (%s='' OR i.rule_id LIKE %s OR i.details LIKE %s)",
                $wpdb->prefix . 'bwa_issues', $wpdb->prefix . 'bwa_scans', $wpdb->prefix . 'bwa_scans', (int) $include_home,
                $filters['impact'], $filters['impact'], $filters['kind'], $filters['kind'],
                $filters['disposition'], $filters['disposition'], $filters['target_key'], $filters['target_key'],
                $filters['search'], $like, $like
            ) );
            $read_error = $read_error || '' !== $wpdb->last_error;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Filtered custom issue/scan join; all identifiers/values are bound and raw results are request-cached.
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT i.*, s.source_hash, s.content_hash, s.environment_hash, s.created_at FROM %i i
                INNER JOIN (SELECT target_key, MAX(id) AS scan_id FROM %i WHERE status='completed' GROUP BY target_key) l ON l.scan_id=i.scan_id
                INNER JOIN %i s ON s.id=i.scan_id
                WHERE (%d=1 OR i.target_key<>'home')
                AND (%s='' OR i.impact=%s) AND (%s='' OR i.kind=%s)
                AND (%s='' OR i.disposition=%s) AND (%s='' OR i.target_key=%s)
                AND (%s='' OR i.rule_id LIKE %s OR i.details LIKE %s)
                ORDER BY CASE i.impact WHEN 'critical' THEN 0 WHEN 'serious' THEN 1 WHEN 'moderate' THEN 2 WHEN 'minor' THEN 3 ELSE 4 END, i.id DESC LIMIT %d OFFSET %d",
                $wpdb->prefix . 'bwa_issues', $wpdb->prefix . 'bwa_scans', $wpdb->prefix . 'bwa_scans', (int) $include_home,
                $filters['impact'], $filters['impact'], $filters['kind'], $filters['kind'],
                $filters['disposition'], $filters['disposition'], $filters['target_key'], $filters['target_key'],
                $filters['search'], $like, $like, $size, ( $page - 1 ) * $size
            ), ARRAY_A );
            $read_error = $read_error || '' !== $wpdb->last_error;
            $raw = array( $total, $rows );
            if ( ! $read_error && BWA_Cache::can_store( $raw ) ) { wp_cache_set( $cache_key, $raw, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        if ( $read_error ) { return self::read_error(); }
        list( $total, $rows ) = $raw;
        $environment = self::environment();
        $items = array();
        foreach ( $rows as $row ) {
            $target = self::target( $row['target_key'] );
            if ( is_wp_error( $target ) ) { continue; }
            $row['id'] = (int) $row['id'];
            $row['details'] = json_decode( $row['details'], true );
            $row['target'] = $target;
            $row['fresh'] = self::fresh( $row, $target, $environment );
            $row['created_at'] .= 'Z';
            $row['repair_url'] = null;
            $row['content_repair'] = null;
            if ( $row['fresh'] && in_array( $target['type'], array( 'post', 'page' ), true ) && ! empty( $row['details']['repair_target'] ) ) {
                $candidate = BWA_Content::find( get_post( $target['id'] )->post_content, $row['details']['repair_target'] );
                $rules = array( 'heading' => array( 'heading-order', 'empty-heading' ), 'link' => array( 'link-name' ), 'label' => array( 'label', 'select-name', 'label-title-only', 'form-field-multiple-labels' ) );
                if ( $candidate && $candidate['editable'] && in_array( $row['rule_id'], $rules[ $candidate['kind'] ], true ) ) { $row['content_repair'] = array( 'key' => $candidate['key'], 'kind' => $candidate['kind'], 'source_hash' => $row['content_hash'] ); }
            }
            if ( $row['fresh'] && in_array( $target['type'], array( 'post', 'page' ), true ) && BWA_Images::valid_path( $row['details']['block_path'] ?? null ) ) {
                $block = BWA_Images::at( parse_blocks( get_post( $target['id'] )->post_content ), $row['details']['block_path'] );
                if ( ! is_wp_error( BWA_Images::image( $block ) ) ) { $row['repair_url'] = add_query_arg( array( 'bwa_image' => implode( '.', $row['details']['block_path'] ), 'bwa_source' => $row['content_hash'] ), $target['edit_url'] ); }
            }
            $items[] = $row;
        }
        return array( 'items' => $items, 'total' => $total, 'page' => $page, 'pages' => max( 1, (int) ceil( $total / $size ) ) );
    }

    public static function triage( WP_REST_Request $request ) {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read current issue state and save its decision in the private table; verify the write and invalidate cached views.
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bwa_issues WHERE id=%d", $request['id'] ), ARRAY_A );
        if ( ! $row ) { return self::error( __( 'This finding is no longer available.', 'build-with-accessibility' ), 404 ); }
        $target = self::target( $row['target_key'] );
        $latest = self::latest( $row['target_key'], true );
        if ( is_wp_error( $target ) || ! $latest || $latest['id'] !== $row['scan_id'] || ! self::fresh( $latest, $target ) ) { return self::error( __( 'This finding is from an older page state. Rescan before recording a decision.', 'build-with-accessibility' ), 409 ); }
        $state = $request->get_param( 'disposition' );
        $note = self::short_text( $request->get_param( 'note' ) );
        if ( ! in_array( $state, array( 'open', 'accepted', 'false_positive' ), true ) || ( 'open' !== $state && '' === trim( $note ) ) ) { return self::error( __( 'Add a reason before accepting or disputing a finding.', 'build-with-accessibility' ) ); }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Read current issue state and save its decision in the private table; verify the write and invalidate cached views.
        $updated = $wpdb->update( $wpdb->prefix . 'bwa_issues', array( 'disposition' => $state, 'note' => $note ), array( 'id' => (int) $row['id'] ) );
        wp_cache_delete( BWA_Cache::epoch_key(), BWA_Cache::GROUP );
        if ( false === $updated ) { return self::error( __( 'The review decision could not be saved. Refresh and try again.', 'build-with-accessibility' ), 500 ); }
        return array( 'disposition' => $state, 'note' => $note );
    }

    public static function scans( WP_REST_Request $request ) {
        global $wpdb;
        $page = max( 1, (int) $request->get_param( 'page' ) );
        $size = max( 1, min( 100, (int) ( $request->get_param( 'per_page' ) ?: 20 ) ) );
        $raw_target = $request->get_param( 'target' );
        $target_filter = is_string( $raw_target ) ? sanitize_text_field( $raw_target ) : '';
        $cache_key = BWA_Cache::key( 'scan-list', array( $target_filter, $page, $size ) );
        $raw = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        $read_error = false;
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Paginated custom scan history; raw results use a bounded request cache.
            $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE status IN ('completed','failed') AND (%s='' OR target_key=%s)", $wpdb->prefix . 'bwa_scans', $target_filter, $target_filter ) );
            $read_error = $read_error || '' !== $wpdb->last_error;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Paginated custom scan history; raw results use a bounded request cache.
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,target_key,status,source_hash,environment_hash,profile,viewport,created_at,summary FROM %i WHERE status IN ('completed','failed') AND (%s='' OR target_key=%s) ORDER BY id DESC LIMIT %d OFFSET %d", $wpdb->prefix . 'bwa_scans', $target_filter, $target_filter, $size, ( $page - 1 ) * $size ), ARRAY_A );
            $read_error = $read_error || '' !== $wpdb->last_error;
            $raw = array( $total, $rows );
            if ( ! $read_error && BWA_Cache::can_store( $raw ) ) { wp_cache_set( $cache_key, $raw, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        if ( $read_error ) { return self::read_error(); }
        list( $total, $rows ) = $raw;
        $environment = self::environment();
        $items = array();
        foreach ( $rows as $row ) {
            $target = self::target( $row['target_key'] );
            if ( is_wp_error( $target ) ) { continue; }
            $row['id'] = (int) $row['id']; $row['target'] = $target; $row['summary'] = json_decode( $row['summary'], true ); $row['fresh'] = self::fresh( $row, $target, $environment ); $row['created_at'] .= 'Z';
            $items[] = $row;
        }
        return array( 'items' => $items, 'total' => $total, 'page' => $page, 'pages' => max( 1, (int) ceil( $total / $size ) ) );
    }

    public static function scan( WP_REST_Request $request ) {
        global $wpdb;
        $cache_key = BWA_Cache::key( 'report', array( (int) $request['id'] ) );
        $row = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Private report/decision records have no core API; report caching is bounded and access/freshness rechecked.
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bwa_scans WHERE id=%d AND status IN ('completed','failed')", $request['id'] ), ARRAY_A );
            if ( BWA_Cache::can_store( $row ) ) { wp_cache_set( $cache_key, $row, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        if ( ! $row ) { return self::error( __( 'This report is unavailable or was removed by your retention settings.', 'build-with-accessibility' ), 404 ); }
        $target = self::target( $row['target_key'] );
        if ( is_wp_error( $target ) ) { return $target; }
        unset( $row['run_token'] );
        $row['summary'] = json_decode( $row['summary'], true ); $row['report'] = json_decode( $row['report'], true ); $row['target'] = $target; $row['fresh'] = self::fresh( $row, $target ); $row['created_at'] .= 'Z';
        $manual_request = new WP_REST_Request( 'GET' ); $manual_request->set_param( 'target', $target['key'] );
        $row['manual'] = self::manual( $manual_request );
        $row['manual_sessions'] = array( 'summary' => BWA_Manual::tasks( $target, self::environment() ), 'export_route' => '/bwa/v1/manual-sessions/' . $target['key'] . '/export', 'note' => 'Guided sessions have separate timestamps and page-scoped history exports in Manual checks. They are not observations made by this automated scan.' );
        $row['assessment'] = array(
            'conformance' => 'not_assessed',
            'manual_testing_required' => true,
            'purpose' => 'Monitor detectable barriers and support reviewed repairs.',
            'limitations' => 'Passing automated checks does not establish full accessibility or legal compliance. Manual keyboard, screen-reader, zoom, content, and interaction testing are required. Repeat relevant tests after changes. Results cover only the recorded page, browser state, and viewport.',
            'monitoring' => 'User-initiated browser scans; the admin tab must remain open. No unattended background monitoring.',
        );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Private report/decision records have no core API; report caching is bounded and access/freshness rechecked.
        $row['decisions'] = $wpdb->get_results( $wpdb->prepare( "SELECT rule_id,fingerprint,disposition,note FROM {$wpdb->prefix}bwa_issues WHERE scan_id=%d AND disposition<>'open'", $row['id'] ), ARRAY_A );
        return $row;
    }

    public static function manual( WP_REST_Request $request ) {
        $key = (string) $request['target'];
        $target = self::target( $key );
        if ( is_wp_error( $target ) ) { return $target; }
        if ( 'POST' === $request->get_method() ) { return self::error( __( 'Earlier review notes are now read-only. Open Manual checks and save a guided session to preserve testing history.', 'build-with-accessibility' ), 410 ); }
        $records = 'home' === $key ? get_option( 'bwa_home_manual', array() ) : get_post_meta( (int) $key, '_bwa_manual', true );
        $records = is_array( $records ) ? $records : array();
        $environment = self::environment();
        foreach ( $records as &$record ) { $record['fresh'] = $record['source_hash'] === $target['source_hash'] && $record['environment_hash'] === $environment; }
        return array( 'target' => $target, 'environment_hash' => $environment, 'records' => $records );
    }

    public static function repairs( WP_REST_Request $request ) {
        global $wpdb;
        $page = max( 1, (int) $request->get_param( 'page' ) );
        $like = $wpdb->esc_like( BWA_Repairs::PREFIX ) . '%';
        $cache_key = BWA_Cache::key( 'repair-history', array( $page ) );
        $raw = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        $read_error = false;
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Core metadata APIs cannot paginate receipt rows across posts by meta_id; request cache invalidates on metadata hooks.
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id,meta_value FROM {$wpdb->postmeta} WHERE meta_key LIKE %s ORDER BY meta_id DESC LIMIT 25 OFFSET %d", $like, ( $page - 1 ) * 25 ), ARRAY_A );
            $read_error = $read_error || '' !== $wpdb->last_error;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Core metadata APIs cannot paginate receipt rows across posts by meta_id; request cache invalidates on metadata hooks.
            $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key LIKE %s", $like ) );
            $read_error = $read_error || '' !== $wpdb->last_error;
            $raw = array( $rows, $total );
            if ( ! $read_error && BWA_Cache::can_store( $raw ) ) { wp_cache_set( $cache_key, $raw, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        if ( $read_error ) { return self::read_error(); }
        list( $rows, $total ) = $raw;
        $items = array();
        foreach ( $rows as $row ) {
            $record = maybe_unserialize( $row['meta_value'] ); $target = self::target( (string) $row['post_id'] );
            if ( is_wp_error( $target ) || ! is_array( $record ) || ! isset( $record['id'], $record['state'], $record['path'], $record['after'] ) || 'pending' === $record['state'] ) { continue; }
            $items[] = array( 'id' => $record['id'], 'target' => $target, 'state' => $record['state'], 'kind' => $record['kind'] ?? 'image', 'summary' => $record['summary'] ?? $record['alt'] ?? '', 'purpose' => $record['purpose'] ?? '', 'alt' => $record['alt'] ?? '', 'created' => $record['created'], 'current' => BWA_Images::is_current( get_post( $target['id'] ), $record ), 'evidence' => $record['evidence'], 'evidence_fresh' => ! empty( $record['evidence'] ) && $record['evidence']['source_hash'] === $target['content_hash'] && ( ! isset( $record['evidence']['environment_hash'] ) || $record['evidence']['environment_hash'] === self::environment() ) );
        }
        return array( 'items' => $items, 'page' => $page, 'pages' => max( 1, (int) ceil( $total / 25 ) ) );
    }

    /** Only an explicit, same-site, authorized scan URL loads axe on the front end. */
    public static function diagnostic(): void {
        if ( ! self::permission() || ! is_string( $_GET['bwa_audit'] ?? null ) || ! is_string( $_GET['_bwa_audit_nonce'] ?? null ) ) { return; }
        $token = sanitize_text_field( wp_unslash( $_GET['bwa_audit'] ) );
        if ( ! preg_match( '/^[a-f0-9-]{36}$/', $token ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_bwa_audit_nonce'] ) ), 'bwa_audit_' . $token ) ) { return; }
        $ticket = self::ticket( $token );
        if ( is_wp_error( $ticket ) ) {
            // An authenticated preview can become stale while a builder or theme saves.
            // Return a useful retry reason instead of leaving the workspace waiting.
            BWA_Compatibility::diagnostic();
            add_action( 'wp_enqueue_scripts', static function () use ( $token, $ticket ) {
                wp_enqueue_script( 'bwa-scan', plugins_url( 'assets/scan.js', BWA_FILE ), array(), BWA_VERSION, true );
                wp_add_inline_script( 'bwa-scan', 'window.bwaScan=' . wp_json_encode( array( 'token' => $token, 'error' => $ticket->get_error_message() ) ) . ';', 'before' );
            } );
            return;
        }
        $target = $ticket['target'];
        if ( 'home' === $target['key'] ? ! is_front_page() : get_queried_object_id() !== $target['id'] ) { return; }
        BWA_Compatibility::diagnostic();
        if ( $target['id'] && ! BWA_Compatibility::owner( $target['id'] ) && in_array( $target['type'], array( 'post', 'page' ), true ) ) {
            add_filter( 'the_content', static function ( $content ) use ( $target ) {
                if ( get_the_ID() !== $target['id'] || BWA_Images::hash( $content ) !== $target['content_hash'] ) { return $content; }
                return BWA_Content::mark_scan( serialize_blocks( self::mark_blocks( parse_blocks( $content ) ) ) );
            }, 8 );
        }
        add_action( 'wp_enqueue_scripts', static function () use ( $token, $ticket ) {
            wp_enqueue_script( 'bwa-axe', plugins_url( 'assets/vendor/axe.min.js', BWA_FILE ), array(), BWA_AXE_VERSION, true );
            wp_enqueue_script( 'bwa-scan', plugins_url( 'assets/scan.js', BWA_FILE ), array( 'bwa-axe' ), BWA_VERSION, true );
            wp_add_inline_script( 'bwa-scan', 'window.bwaScan=' . wp_json_encode( array( 'token' => $token, 'settings' => $ticket['settings'], 'axeUrl' => plugins_url( 'assets/vendor/axe.min.js', BWA_FILE ) ) ) . ';', 'before' );
        } );
    }

    private static function mark_blocks( array $blocks, array $path = array() ): array {
        $index = 0;
        foreach ( $blocks as &$block ) {
            if ( null === $block['blockName'] && '' === trim( $block['innerHTML'] ) ) { continue; }
            $current = array_merge( $path, array( $index++ ) );
            if ( in_array( $block['blockName'], array( 'core/block', 'core/template-part', 'core/query', 'core/post-template', 'core/navigation' ), true ) ) { continue; }
            if ( 'core/image' === $block['blockName'] && ! is_wp_error( BWA_Images::image( $block ) ) ) {
                $html = new WP_HTML_Tag_Processor( $block['innerHTML'] );
                if ( $html->next_tag( 'IMG' ) ) {
                    $html->set_attribute( 'data-bwa-block-path', implode( '.', $current ) );
                    $block['innerHTML'] = $html->get_updated_html(); $block['innerContent'] = array( $block['innerHTML'] );
                }
            } else { $block['innerBlocks'] = self::mark_blocks( $block['innerBlocks'], $current ); }
        }
        return $blocks;
    }
}
