<?php
/** Focused repairs of static, post-owned headings, text links and form labels. */
defined( 'ABSPATH' ) || exit;

final class BWA_Content {
    const LEAVES = array( 'core/heading', 'core/paragraph', 'core/button', 'core/list-item', 'core/html' );
    const CONTAINERS = array( 'core/group', 'core/columns', 'core/column', 'core/buttons', 'core/list', 'core/list-item', 'core/quote', 'core/details' );

    public static function routes(): void {
        $base = '/posts/(?P<post_id>\d+)';
        foreach ( array( '/content-targets' => array( 'GET', 'listing' ), '/content-repairs' => array( 'POST', 'prepare' ), '/content-repairs/(?P<repair_id>[a-f0-9-]{36})/undo' => array( 'POST', 'undo' ) ) as $path => $route ) {
            register_rest_route( 'bwa/v1', $base . $path, array( 'methods' => $route[0], 'callback' => array( __CLASS__, $route[1] ), 'permission_callback' => array( 'BWA_Repairs', 'permission' ) ) );
        }
    }

    private static function text( string $html ): string { return html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ); }
    private static function escape( string $text ): string { return htmlspecialchars( $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8', true ); }
    private static function failure( string $message, int $status = 422 ): WP_Error { return BWA_Repairs::error( $message, $status ); }

    /** Token ordinals come from WordPress's parser, which skips raw-text contents. */
    private static function tags( string $html ): array {
        $p = new WP_HTML_Tag_Processor( $html ); $tags = array(); $inside_label = false;
        while ( $p->next_tag( array( 'tag_closers' => 'visit' ) ) ) {
            if ( $p->is_tag_closer() ) { if ( 'LABEL' === $p->get_tag() ) { $inside_label = false; } continue; }
            $attrs = array();
            foreach ( $p->get_attribute_names_with_prefix( '' ) ?? array() as $name ) { $attrs[ $name ] = $p->get_attribute( $name ); }
            $tags[] = array( 'index' => count( $tags ), 'tag' => $p->get_tag(), 'attrs' => $attrs, 'wrapped_label' => $inside_label );
            if ( 'LABEL' === $p->get_tag() ) { $inside_label = true; }
        }
        return $p->paused_at_incomplete_token() ? array() : $tags;
    }

    /** Locate an actual parsed opener without relying on private parser offsets.
     * A unique temporary attribute identifies it; the surrounding source must
     * match byte for byte. The marker is never included in saved content.
     */
    private static function opening( string $html, int $index ): ?array {
        $p = new WP_HTML_Tag_Processor( $html ); $n = 0;
        while ( $p->next_tag() ) {
            if ( $n++ !== $index ) { continue; }
            $marker = 'data-bwa-locate-' . str_replace( '-', '', wp_generate_uuid4() );
            $p->set_attribute( $marker, '1' ); $marked = $p->get_updated_html();
            preg_match_all( '~<[a-zA-Z][a-zA-Z0-9:-]*(?:[^>\'\"]|\"[^\"]*\"|\'[^\']*\')*>~s', $marked, $matches, PREG_OFFSET_CAPTURE );
            foreach ( $matches[0] as $match ) {
                if ( false === strpos( $match[0], $marker ) ) { continue; }
                // Raw-text openers such as textarea need a complete empty
                // element for the parser to expose their attributes.
                $verify = new WP_HTML_Tag_Processor( $match[0] . '</' . strtolower( $p->get_tag() ) . '>' );
                if ( ! $verify->next_tag() || $verify->get_tag() !== $p->get_tag() || '1' !== $verify->get_attribute( $marker ) ) { continue; }
                $expected_attrs = array(); $actual_attrs = array();
                foreach ( $p->get_attribute_names_with_prefix( '' ) ?? array() as $name ) { $expected_attrs[ $name ] = $p->get_attribute( $name ); }
                foreach ( $verify->get_attribute_names_with_prefix( '' ) ?? array() as $name ) { $actual_attrs[ $name ] = $verify->get_attribute( $name ); }
                ksort( $expected_attrs ); ksort( $actual_attrs );
                if ( $expected_attrs !== $actual_attrs ) { continue; }
                $start = $match[1]; $length = strlen( $match[0] ) - ( strlen( $marked ) - strlen( $html ) );
                if ( $length < 3 || substr( $html, 0, $start ) !== substr( $marked, 0, $start ) || substr( $html, $start + $length ) !== substr( $marked, $start + strlen( $match[0] ) ) ) { return null; }
                return array( 'start' => $start, 'length' => $length, 'html' => substr( $html, $start, $length ), 'end' => $start + $length );
            }
            return null;
        }
        return null;
    }

    private static function plain_pair( string $html, array $tag ): ?array {
        $open = self::opening( $html, $tag['index'] );
        if ( ! $open || ! preg_match( '~\A([^<]*)</' . preg_quote( $tag['tag'], '~' ) . '\s*>~i', substr( $html, $open['end'] ), $match ) ) { return null; }
        return array_merge( $open, array( 'inner' => $match[1], 'text' => self::text( $match[1] ), 'inner_length' => strlen( $match[1] ) ) );
    }

    private static function overridden( array $attrs ): bool {
        foreach ( array( 'aria-label', 'aria-labelledby', 'aria-hidden', 'role', 'hidden', 'inert', 'contenteditable' ) as $key ) { if ( array_key_exists( $key, $attrs ) ) { return true; } }
        return false;
    }

    public static function block_targets( array $block, array $path, string $content ): array {
        if ( ! in_array( $block['blockName'], self::LEAVES, true ) || $block['innerBlocks'] || ! empty( $block['attrs']['metadata']['bindings'] ) || strlen( $block['innerHTML'] ) > 200000 ) { return array(); }
        $html = $block['innerHTML']; $tags = self::tags( $html ); $items = array();
        $embedded = (bool) array_intersect( array_column( $tags, 'tag' ), array( 'SCRIPT', 'STYLE', 'TEMPLATE', 'SVG', 'MATH', 'IFRAME', 'OBJECT', 'NOSCRIPT' ) );
        foreach ( $tags as $tag ) {
            $kind = 'core/heading' === $block['blockName'] && preg_match( '/^H[1-6]$/', $tag['tag'] ) ? 'heading' : ( 'A' === $tag['tag'] && isset( $tag['attrs']['href'] ) && 'core/heading' !== $block['blockName'] ? 'link' : ( 'core/html' === $block['blockName'] && in_array( $tag['tag'], array( 'INPUT', 'SELECT', 'TEXTAREA' ), true ) && ! in_array( strtolower( $tag['attrs']['type'] ?? 'text' ), array( 'hidden', 'submit', 'reset', 'button', 'image' ), true ) ? 'label' : null ) );
            if ( ! $kind ) { continue; }
            $item = array( 'key' => implode( '.', $path ) . ':' . $kind . ':' . $tag['index'], 'path' => $path, 'index' => $tag['index'], 'kind' => $kind, 'block' => $block['blockName'], 'tag' => strtolower( $tag['tag'] ), 'text' => '', 'editable' => true, 'reason' => '' );
            if ( self::overridden( $tag['attrs'] ) ) { $item['reason'] = __( 'Custom naming, visibility, or role attributes need review in the editor first.', 'build-with-accessibility' ); }
            if ( 'heading' === $kind ) {
                $item['level'] = (int) substr( $tag['tag'], 1 );
                if ( ! preg_match( '~\A\s*(<h[1-6]\b(?:[^>\'\"]|\"[^\"]*\"|\'[^\']*\')*>)(.*)(</h[1-6]\s*>)\s*\z~is', $html, $match ) || 0 !== $tag['index'] ) { continue; }
                $item['text'] = self::text( $match[2] ); $item['plain'] = false === strpos( $match[2], '<' );
                if ( array_key_exists( 'content', $block['attrs'] ) ) { $item['reason'] = __( 'This heading stores its text in custom block attributes. Use the editor.', 'build-with-accessibility' ); }
            } elseif ( 'link' === $kind ) {
                $pair = self::plain_pair( $html, $tag );
                $item['text'] = $pair['text'] ?? ''; $item['href'] = (string) $tag['attrs']['href'];
                if ( ! $pair ) { $item['reason'] = __( 'This link contains formatting, an image, or other elements. Use its block editor to preserve them.', 'build-with-accessibility' ); }
            } else {
                $item['control_id'] = is_string( $tag['attrs']['id'] ?? null ) ? $tag['attrs']['id'] : '';
                $item['field_name'] = is_string( $tag['attrs']['name'] ?? null ) ? $tag['attrs']['name'] : '';
                $item['field_type'] = strtolower( $tag['attrs']['type'] ?? $tag['tag'] );
                $item['label_index'] = null;
                if ( $tag['wrapped_label'] ) { $item['reason'] = __( 'This control uses a wrapping label. Edit that label in its original block.', 'build-with-accessibility' ); }
                if ( $item['control_id'] ) {
                    $all = self::tags( $content ); $ids = array_filter( $all, static fn( $other ) => ( $other['attrs']['id'] ?? null ) === $item['control_id'] );
                    $labels = array_filter( $all, static fn( $other ) => 'LABEL' === $other['tag'] && ( $other['attrs']['for'] ?? null ) === $item['control_id'] );
                    $local = array_values( array_filter( $tags, static fn( $other ) => 'LABEL' === $other['tag'] && ( $other['attrs']['for'] ?? null ) === $item['control_id'] ) );
                    if ( count( $ids ) !== 1 || count( $labels ) > 1 || count( $local ) !== count( $labels ) ) { $item['reason'] = __( 'Duplicate IDs, multiple labels, or a label in another block need manual review.', 'build-with-accessibility' ); }
                    elseif ( count( $local ) === 1 ) {
                        $pair = self::plain_pair( $html, $local[0] ); $item['text'] = $pair['text'] ?? ''; $item['label_index'] = $local[0]['index'];
                        if ( ! $pair || self::overridden( $local[0]['attrs'] ) ) { $item['reason'] = __( 'The existing label contains custom markup or accessibility attributes. Edit it in the original block.', 'build-with-accessibility' ); }
                    }
                }
            }
            $item['editable'] = '' === $item['reason']; $items[] = $item;
            if ( $embedded ) { $items[ count( $items ) - 1 ]['editable'] = false; $items[ count( $items ) - 1 ]['reason'] = __( 'This block contains scripts, styles, or embedded markup. Use its original editor.', 'build-with-accessibility' ); }
        }
        return $items;
    }

    public static function inventory( string $content ): array {
        $items = array();
        $walk = static function ( array $blocks, array $path = array() ) use ( &$walk, &$items, $content ) {
            $index = 0;
            foreach ( $blocks as $block ) {
                if ( null === $block['blockName'] && '' === trim( $block['innerHTML'] ) ) { continue; }
                $current = array_merge( $path, array( $index++ ) );
                if ( ! empty( $block['attrs']['metadata']['bindings'] ) ) { continue; }
                foreach ( self::block_targets( $block, $current, $content ) as $item ) { $items[] = $item; }
                if ( in_array( $block['blockName'], self::CONTAINERS, true ) ) { $walk( $block['innerBlocks'], $current ); }
            }
        };
        $walk( parse_blocks( $content ) ); return $items;
    }

    public static function find( string $content, string $key ): ?array {
        foreach ( self::inventory( $content ) as $item ) { if ( $item['key'] === $key ) { return $item; } } return null;
    }

    private static function base( WP_REST_Request $request ) {
        $post = get_post( (int) $request['post_id'] );
        $guard = BWA_Compatibility::guard( $post->ID );
        if ( is_wp_error( $guard ) ) { return $guard; }
        if ( strlen( $post->post_content ) > 2 * MB_IN_BYTES || 'auto-draft' === $post->post_status || ! is_string( $request->get_param( 'source_hash' ) ) || ! hash_equals( BWA_Images::hash( $post->post_content ), $request->get_param( 'source_hash' ) ) ) { return self::failure( __( 'The saved page changed or is unavailable. Reload the repair list before continuing.', 'build-with-accessibility' ), 409 ); }
        if ( ! function_exists( 'wp_check_post_lock' ) ) { require_once ABSPATH . 'wp-admin/includes/post.php'; }
        if ( wp_check_post_lock( $post->ID ) ) { return self::failure( __( 'Another author is editing this page. Finish that editing session before making a repair.', 'build-with-accessibility' ), 409 ); }
        if ( ! current_user_can( 'unfiltered_html' ) && wp_kses_post( $post->post_content ) !== $post->post_content ) { return self::failure( __( 'Your role would remove other markup when saving this page. Ask an authorized administrator to review this repair.', 'build-with-accessibility' ), 403 ); }
        return $post;
    }

    public static function listing( WP_REST_Request $request ) {
        $post = get_post( (int) $request['post_id'] );
        if ( strlen( $post->post_content ) > 2 * MB_IN_BYTES ) { return self::failure( __( 'This page is too large for focused repairs. Use the editor.', 'build-with-accessibility' ), 413 ); }
        $records = BWA_Repairs::listing( $request );
        return array( 'source_hash' => $records['source_hash'], 'environment_hash' => BWA_Audits::environment(), 'targets' => BWA_Compatibility::owner( $post->ID ) ? array() : self::inventory( $post->post_content ), 'repair_notice' => $records['repair_notice'], 'edit_url' => get_edit_post_link( $post->ID, 'raw' ), 'records' => array_values( array_filter( $records['records'], static fn( $r ) => isset( $r['kind'] ) && 'image' !== $r['kind'] ) ), 'rest_path' => '/wp/v2/' . ( 'page' === $post->post_type ? 'pages' : 'posts' ) . '/' . $post->ID );
    }

    public static function prepare( WP_REST_Request $request ) {
        $post = self::base( $request ); if ( is_wp_error( $post ) ) { return $post; }
        $key = $request->get_param( 'target' );
        $item = is_string( $key ) ? self::find( $post->post_content, $key ) : null;
        if ( ! $item || ! $item['editable'] ) { return self::failure( $item['reason'] ?? __( 'This element is outside the supported static content. Use its owning editor.', 'build-with-accessibility' ) ); }
        $value = $request->get_param( 'text' );
        if ( ! is_string( $value ) || '' === trim( $value ) || mb_strlen( $value ) > 1000 || preg_match( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value ) ) { return self::failure( __( 'Enter meaningful text of no more than 1,000 characters.', 'build-with-accessibility' ) ); }
        $value = trim( $value ); $blocks = parse_blocks( $post->post_content ); $before = BWA_Images::at( $blocks, $item['path'] ); $after = $before; $html = $before['innerHTML'];
        if ( 'heading' === $item['kind'] ) {
            $level = $request->get_param( 'level' );
            if ( ! is_int( $level ) || $level < 1 || $level > 6 || ( ! $item['plain'] && $value !== trim( $item['text'] ) ) ) { return self::failure( __( 'Choose a heading level from 1 to 6. Rich heading text must be edited in Gutenberg.', 'build-with-accessibility' ) ); }
            preg_match( '~\A(\s*)(<h[1-6]\b(?:[^>\'\"]|\"[^\"]*\"|\'[^\']*\')*>)(.*)(</h[1-6]\s*>)(\s*)\z~is', $html, $parts );
            $open = preg_replace( '/\A<h[1-6]/i', '<h' . $level, $parts[2] ); $close = preg_replace( '/\A<\/h[1-6]/i', '</h' . $level, $parts[4] );
            $html = $parts[1] . $open . ( $value === trim( $item['text'] ) ? $parts[3] : self::escape( $value ) ) . $close . $parts[5];
            if ( 2 === $level ) { unset( $after['attrs']['level'] ); } else { $after['attrs']['level'] = $level; }
            $item['level'] = $level;
        } elseif ( 'link' === $item['kind'] ) {
            $pair = self::plain_pair( $html, array( 'index' => $item['index'], 'tag' => 'A' ) );
            if ( ! $pair ) { return self::failure( __( 'The link markup is no longer supported.', 'build-with-accessibility' ) ); }
            $html = substr_replace( $html, self::escape( $value ), $pair['end'], $pair['inner_length'] );
        } elseif ( null !== $item['label_index'] ) {
            $pair = self::plain_pair( $html, array( 'index' => $item['label_index'], 'tag' => 'LABEL' ) );
            if ( ! $pair ) { return self::failure( __( 'The label markup is no longer supported.', 'build-with-accessibility' ) ); }
            $html = substr_replace( $html, self::escape( $value ), $pair['end'], $pair['inner_length'] );
        } else {
            if ( ! $item['control_id'] ) {
                $item['control_id'] = 'bwa-field-' . str_replace( '-', '', wp_generate_uuid4() );
                $p = new WP_HTML_Tag_Processor( $html ); $i = 0;
                while ( $p->next_tag() ) { if ( $i++ === $item['index'] ) { $p->set_attribute( 'id', $item['control_id'] ); break; } }
                $html = $p->get_updated_html();
            }
            $open = self::opening( $html, $item['index'] ); if ( ! $open ) { return self::failure( __( 'The control could not be located safely.', 'build-with-accessibility' ) ); }
            $label = '<label for="' . self::escape( $item['control_id'] ) . '">' . self::escape( $value ) . '</label>';
            $html = substr_replace( $html, $label, $open['start'], 0 ); $item['index']++;
        }
        $after['innerHTML'] = $html; $after['innerContent'] = array( $html ); $item['text'] = $value;
        $next = serialize_blocks( BWA_Images::replace( $blocks, $item['path'], $after ) );
        if ( BWA_Images::hash( $next ) === BWA_Images::hash( $post->post_content ) ) { return self::failure( __( 'Choose a change before previewing a repair.', 'build-with-accessibility' ) ); }
        $record = array( 'id' => wp_generate_uuid4(), 'kind' => $item['kind'], 'path' => $item['path'], 'target' => $item, 'before' => serialize_block( $before ), 'after' => serialize_block( $after ), 'summary' => $value, 'state' => 'pending', 'created' => gmdate( 'c' ), 'author' => get_current_user_id(), 'evidence' => null, 'operation' => BWA_Repairs::operation( 'apply', $post->post_content, $next ) );
        BWA_Repairs::put( $post->ID, $record );
        return array( 'id' => $record['id'], 'token' => $record['operation']['token'], 'after_content' => $next, 'before' => $record['before'], 'after' => $record['after'], 'target' => $item );
    }

    public static function undo( WP_REST_Request $request ) {
        $post = self::base( $request ); if ( is_wp_error( $post ) ) { return $post; }
        $record = BWA_Repairs::get( $post->ID, (string) $request['repair_id'] );
        if ( ! $record || empty( $record['kind'] ) || 'image' === $record['kind'] || 'saved' !== $record['state'] || ! BWA_Images::is_current( $post, $record ) ) { return self::failure( __( 'The repaired block moved or changed, or this repair was already undone. Undo is paused to preserve newer work.', 'build-with-accessibility' ), 409 ); }
        $next = serialize_blocks( BWA_Images::replace( parse_blocks( $post->post_content ), $record['path'], parse_blocks( $record['before'] )[0] ) );
        $record['operation'] = BWA_Repairs::operation( 'undo', $post->post_content, $next ); BWA_Repairs::put( $post->ID, $record );
        return array( 'id' => $record['id'], 'token' => $record['operation']['token'], 'after_content' => $next );
    }

    public static function mark( string $content, array $record, string $token ): string {
        $blocks = parse_blocks( $content ); $block = BWA_Images::at( $blocks, $record['path'] );
        if ( ! $block || BWA_Images::hash( serialize_block( $block ) ) !== BWA_Images::hash( $record['after'] ) ) { return $content; }
        $p = new WP_HTML_Tag_Processor( $block['innerHTML'] ); $index = 0;
        while ( $p->next_tag() ) { if ( $index++ === $record['target']['index'] ) { $p->set_attribute( 'data-bwa-repair', $token ); break; } }
        $block['innerHTML'] = $p->get_updated_html(); $block['innerContent'] = array( $block['innerHTML'] );
        return serialize_blocks( BWA_Images::replace( $blocks, $record['path'], $block ) );
    }

    public static function mark_scan( string $content ): string {
        $blocks = parse_blocks( $content ); $groups = array();
        foreach ( self::inventory( $content ) as $item ) { if ( $item['editable'] ) { $groups[ implode( '.', $item['path'] ) ][] = $item; } }
        foreach ( $groups as $items ) {
            $block = BWA_Images::at( $blocks, $items[0]['path'] ); $by_index = array_column( $items, 'key', 'index' ); $p = new WP_HTML_Tag_Processor( $block['innerHTML'] ); $index = 0;
            while ( $p->next_tag() ) { if ( isset( $by_index[ $index ] ) ) { $p->set_attribute( 'data-bwa-repair-target', $by_index[ $index ] ); } ++$index; }
            $block['innerHTML'] = $p->get_updated_html(); $block['innerContent'] = array( $block['innerHTML'] ); $blocks = BWA_Images::replace( $blocks, $items[0]['path'], $block );
        }
        return serialize_blocks( $blocks );
    }
}
