<?php
/** Guided, append-only human testing records. Automated scans never write these records. */
defined( 'ABSPATH' ) || exit;

final class BWA_Manual {
    const OUTCOMES = array( 'not_tested', 'blocked', 'issue_found', 'no_issue_observed', 'not_applicable' );
    private static function limitation(): string {
        return __( 'Human observations cover only the recorded steps, page state and testing environment. These starter guides are not a complete WCAG audit and do not establish accessibility or legal compliance. Automated scans cannot complete manual tests. Repeat relevant tests after changes; external content and other pages in a journey may change without being detected.', 'build-with-accessibility' );
    }

    public static function init(): void { add_action( 'rest_api_init', array( __CLASS__, 'routes' ) ); }

    public static function install( string $charset ): void {
        global $wpdb;
        dbDelta( "CREATE TABLE {$wpdb->prefix}bwa_manual_sessions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            target_key varchar(40) NOT NULL,
            review_key varchar(36) NOT NULL,
            previous_id bigint(20) unsigned NOT NULL DEFAULT 0,
            request_key varchar(36) NOT NULL,
            request_hash varchar(64) NOT NULL,
            guide varchar(32) NOT NULL,
            legacy_check varchar(32) NOT NULL DEFAULT '',
            outcome varchar(24) NOT NULL,
            source_hash varchar(64) NOT NULL,
            environment_hash varchar(64) NOT NULL,
            review_date date NULL,
            created_at datetime NOT NULL,
            author bigint(20) unsigned NOT NULL,
            evidence longtext NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY request_key (request_key),
            UNIQUE KEY review_previous (review_key,previous_id),
            KEY target_id (target_key,id),
            KEY review_id (review_key,id)
        ) $charset;" );
    }

    public static function routes(): void {
        foreach ( array( '/manual-sessions/(?P<target>home|\d+)' => array( 'GET,POST', 'sessions' ), '/manual-sessions/(?P<target>home|\d+)/export' => array( 'GET', 'export' ) ) as $path => $route ) {
            register_rest_route( 'bwa/v1', $path, array( 'methods' => $route[0], 'callback' => array( __CLASS__, $route[1] ), 'permission_callback' => array( 'BWA_Audits', 'permission' ) ) );
        }
    }

    public static function guides(): array {
        // Local, versioned starter instructions. Save the wording with each session
        // so a later guide update cannot rewrite the historical testing scope.
        $guides = array(
            'keyboard' => array( __( 'Keyboard operation', 'build-with-accessibility' ), array(
                array( 'reach', __( 'Reach the controls', 'build-with-accessibility' ), __( 'Set the mouse aside. Use Tab and Shift+Tab through the named page state. Note any controls you cannot reach.', 'build-with-accessibility' ), __( 'Every essential control is reachable in a meaningful order.', 'build-with-accessibility' ) ),
                array( 'operate', __( 'Operate the controls', 'build-with-accessibility' ), __( 'Use Enter, Space and the appropriate arrow keys to operate links, buttons and composite controls. Test only safe actions.', 'build-with-accessibility' ), __( 'The tested functions can be completed with the keyboard.', 'build-with-accessibility' ) ),
                array( 'exit', __( 'Leave and return', 'build-with-accessibility' ), __( 'Enter and leave menus and dialogs. Try Escape where appropriate, then continue forward and backward.', 'build-with-accessibility' ), __( 'Focus is not trapped; closing an overlay returns focus to a sensible place.', 'build-with-accessibility' ) ),
            ) ),
            'focus' => array( __( 'Focus and reading order', 'build-with-accessibility' ), array(
                array( 'visible', __( 'Follow visible focus', 'build-with-accessibility' ), __( 'Tab through every control in the recorded state, including light and dark areas.', 'build-with-accessibility' ), __( 'You can tell which control has keyboard focus.', 'build-with-accessibility' ) ),
                array( 'order', __( 'Check the sequence', 'build-with-accessibility' ), __( 'Compare the focus sequence with the content and task sequence, including content revealed by interaction.', 'build-with-accessibility' ), __( 'The sequence preserves meaning and makes the task understandable.', 'build-with-accessibility' ) ),
                array( 'obscured', __( 'Check covered controls', 'build-with-accessibility' ), __( 'Check controls near sticky headers, banners and overlays while scrolling and zooming.', 'build-with-accessibility' ), __( 'Focused controls remain visible and usable.', 'build-with-accessibility' ) ),
            ) ),
            'zoom' => array( __( 'Zoom and reflow', 'build-with-accessibility' ), array(
                array( 'text', __( 'Enlarge text', 'build-with-accessibility' ), __( 'Increase text size to 200% where supported. Record how you changed the size.', 'build-with-accessibility' ), __( 'Text and controls remain available without clipping or loss of functionality.', 'build-with-accessibility' ) ),
                array( 'reflow', __( 'Review at a narrow width', 'build-with-accessibility' ), __( 'At a desktop viewport about 1280 CSS pixels wide, zoom to 400%, or test a 320 CSS pixel viewport. Record the actual viewport and zoom.', 'build-with-accessibility' ), __( 'Content reflows without unnecessary two-direction scrolling. Some content, such as complex tables, may need separate assessment.', 'build-with-accessibility' ) ),
                array( 'operate', __( 'Use the enlarged page', 'build-with-accessibility' ), __( 'Open navigation, dialogs and forms at the enlarged size. Check that their controls remain reachable.', 'build-with-accessibility' ), __( 'Essential tasks remain usable without hidden or overlapping controls.', 'build-with-accessibility' ) ),
            ) ),
            'screen_reader' => array( __( 'Screen-reader experience', 'build-with-accessibility' ), array(
                array( 'structure', __( 'Explore the structure', 'build-with-accessibility' ), __( 'With a screen reader you know how to use, navigate the title, headings and landmarks. Record its name and version.', 'build-with-accessibility' ), __( 'The structure describes the page and supports useful navigation.', 'build-with-accessibility' ) ),
                array( 'controls', __( 'Understand and use controls', 'build-with-accessibility' ), __( 'Navigate links, buttons and fields. Listen to their names, roles, instructions and states while completing a safe task.', 'build-with-accessibility' ), __( 'Controls have meaningful names and expose the information needed to use them.', 'build-with-accessibility' ) ),
                array( 'updates', __( 'Listen for changes', 'build-with-accessibility' ), __( 'Trigger a safe validation message, expanded section or other status change. Note what is announced and where focus goes.', 'build-with-accessibility' ), __( 'Important updates are discoverable without searching the whole page.', 'build-with-accessibility' ) ),
            ) ),
            'forms' => array( __( 'Forms and error recovery', 'build-with-accessibility' ), array(
                array( 'instructions', __( 'Understand each field', 'build-with-accessibility' ), __( 'Review visible labels, required fields, format instructions and keyboard access. Use test data on a staging site where possible.', 'build-with-accessibility' ), __( 'Each field has a clear purpose and the needed instructions.', 'build-with-accessibility' ) ),
                array( 'errors', __( 'Trigger and find errors', 'build-with-accessibility' ), __( 'Where safe, submit missing or invalid test information. Check keyboard focus and screen-reader access to the errors. Do not create real orders or send unwanted messages.', 'build-with-accessibility' ), __( 'Errors identify the affected fields, explain the problem and are easy to discover.', 'build-with-accessibility' ) ),
                array( 'recovery', __( 'Correct and complete', 'build-with-accessibility' ), __( 'Correct the test errors and check the confirmation in a safe test environment. If completion is unsafe, record this step as blocked.', 'build-with-accessibility' ), __( 'People can recover without losing unrelated entries and can understand the result.', 'build-with-accessibility' ) ),
            ) ),
            'meaning' => array( __( 'Images, links, and meaning', 'build-with-accessibility' ), array(
                array( 'images', __( 'Review images in context', 'build-with-accessibility' ), __( 'Compare each image with its alternative and surrounding content. Consider decorative, informative and linked images separately.', 'build-with-accessibility' ), __( 'Alternatives serve the purpose of that image placement; decorative images can correctly have an empty alternative.', 'build-with-accessibility' ) ),
                array( 'text', __( 'Review headings and links', 'build-with-accessibility' ), __( 'Read headings and links in their relevant context and review the heading hierarchy.', 'build-with-accessibility' ), __( 'Headings describe their sections and link purposes can be understood.', 'build-with-accessibility' ) ),
                array( 'sensory', __( 'Review instructions and colour', 'build-with-accessibility' ), __( 'Look for instructions that rely only on colour, shape, position or sound.', 'build-with-accessibility' ), __( 'The needed information is also available through an understandable alternative.', 'build-with-accessibility' ) ),
            ) ),
            'media' => array( __( 'Media and motion', 'build-with-accessibility' ), array(
                array( 'alternatives', __( 'Review media alternatives', 'build-with-accessibility' ), __( 'Check the relevant captions, transcripts and descriptions. Review accuracy and essential visual or audio information, not only whether a control exists.', 'build-with-accessibility' ), __( 'People can obtain the essential information through appropriate alternatives.', 'build-with-accessibility' ) ),
                array( 'controls', __( 'Operate media controls', 'build-with-accessibility' ), __( 'Use the keyboard and, when available, a screen reader to play, pause and operate the player.', 'build-with-accessibility' ), __( 'Controls can be found, understood and operated.', 'build-with-accessibility' ) ),
                array( 'motion', __( 'Review movement and timing', 'build-with-accessibility' ), __( 'Inspect autoplay, moving content and time limits. Try reduced-motion settings and available pause or extension controls.', 'build-with-accessibility' ), __( 'People have appropriate control over distracting movement and timing. Record anything needing specialist review.', 'build-with-accessibility' ) ),
            ) ),
            'dynamic' => array( __( 'Menus, dialogs, and other states', 'build-with-accessibility' ), array(
                array( 'open', __( 'Open the interaction', 'build-with-accessibility' ), __( 'Open the named menu, dialog, tab or accordion with the keyboard. Record exactly which state you tested.', 'build-with-accessibility' ), __( 'The trigger is usable and the opened state is conveyed.', 'build-with-accessibility' ) ),
                array( 'inside', __( 'Use the revealed content', 'build-with-accessibility' ), __( 'Navigate and operate the revealed controls. With a screen reader, check their names, states and announcements.', 'build-with-accessibility' ), __( 'Revealed content is reachable and understandable; hidden controls do not interfere.', 'build-with-accessibility' ) ),
                array( 'close', __( 'Close or switch state', 'build-with-accessibility' ), __( 'Close the overlay or switch tabs and continue the task. Check focus restoration and keyboard behaviour.', 'build-with-accessibility' ), __( 'The state change is understandable and focus remains in a useful place.', 'build-with-accessibility' ) ),
            ) ),
        );
        $out = array();
        foreach ( $guides as $id => $guide ) {
            $steps = array();
            foreach ( $guide[1] as $step ) { $steps[] = array( 'id' => $step[0], 'title' => $step[1], 'instruction' => $step[2], 'expected' => $step[3] ); }
            $out[ $id ] = array( 'id' => $id, 'version' => 1, 'title' => $guide[0], 'steps' => $steps, 'reference' => 'https://www.w3.org/WAI/test-evaluate/' );
        }
        return $out;
    }

    private static function error( string $text, int $status = 422 ): WP_Error { return new WP_Error( 'bwa_manual', $text, array( 'status' => $status ) ); }
    private static function text( $value, int $limit ): ?string {
        if ( ! is_string( $value ) || ( function_exists( 'mb_strlen' ) ? mb_strlen( $value ) : strlen( $value ) ) > $limit ) { return null; }
        return sanitize_textarea_field( $value );
    }
    private static function uuid( $value ): bool { return is_string( $value ) && 1 === preg_match( '/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/D', $value ); }
    public static function has_records( string $key ): bool {
        global $wpdb;
        $cache_key = BWA_Cache::key( 'manual-exists', array( $key ) );
        $exists = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Custom target-ownership lookup; request-cache the table result and evaluate earlier metadata separately.
            $exists = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM %i WHERE target_key=%s LIMIT 1', $wpdb->prefix . 'bwa_manual_sessions', $key ) );
            if ( BWA_Cache::can_store( $exists ) ) { wp_cache_set( $cache_key, $exists, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        return $exists || (bool) self::legacy( $key );
    }
    private static function target( string $key ) {
        // New static-homepage reviews belong to its Page. Keep an older homepage
        // review addressable when front-page settings change; never lose its history.
        if ( 'home' === $key && ! BWA_Audits::separate_home() && ! self::has_records( 'home' ) ) { $key = (string) get_option( 'page_on_front' ); }
        return BWA_Audits::target( $key );
    }
    public static function revision(): string {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Live maximum session ID protects inbox pagination; caching this concurrency marker would be unsafe.
        return (string) $wpdb->get_var( "SELECT COALESCE(MAX(id),0) FROM {$wpdb->prefix}bwa_manual_sessions" ) . ':' . wp_date( 'Y-m-d' ) . ':' . wp_timezone_string();
    }

    private static function decorate( array $row, array $target, string $environment, string $today ): array {
        unset( $row['request_key'], $row['request_hash'] );
        $row['id'] = (int) $row['id']; $row['previous_id'] = (int) $row['previous_id']; $row['author'] = (int) $row['author'];
        $row['created_at'] = str_replace( ' ', 'T', $row['created_at'] ) . 'Z';
        $row['evidence'] = json_decode( $row['evidence'], true );
        $row['fresh'] = $target['source_hash'] === $row['source_hash'] && $environment === $row['environment_hash'];
        $row['due'] = ! empty( $row['review_date'] ) && $row['review_date'] <= $today;
        $row['reasons'] = array();
        if ( ! $row['fresh'] ) { $row['reasons'][] = 'manual_changed'; }
        if ( $row['due'] ) { $row['reasons'][] = 'manual_due'; }
        if ( in_array( $row['outcome'], array( 'not_tested', 'blocked', 'issue_found' ), true ) ) { $row['reasons'][] = 'manual_open'; }
        return $row;
    }

    public static function tasks( array $target, string $environment ): array {
        global $wpdb;
        $cache_key = BWA_Cache::key( 'manual-tasks', array( $target['key'] ) );
        $raw = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Aggregate latest custom sessions per review; request-cache raw rows and recalculate due/freshness state.
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT s.id,s.outcome,s.source_hash,s.environment_hash,s.review_date,s.legacy_check FROM %i s INNER JOIN (SELECT MAX(id) AS id FROM %i WHERE target_key=%s GROUP BY review_key) last ON s.id=last.id", $wpdb->prefix . 'bwa_manual_sessions', $wpdb->prefix . 'bwa_manual_sessions', $target['key'] ), ARRAY_A );
            $raw = array( $rows );
            if ( BWA_Cache::can_store( $raw ) ) { wp_cache_set( $cache_key, $raw, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        list( $rows ) = $raw;
        if ( ! is_array( $rows ) || $wpdb->last_error ) { return array( 'count' => null, 'reviews' => null, 'reasons' => array( 'manual_unavailable' ) ); }
        $reasons = array(); $count = 0; $today = wp_date( 'Y-m-d' ); $followed_legacy = array();
        foreach ( $rows as $row ) {
            if ( ! empty( $row['legacy_check'] ) ) { $followed_legacy[] = $row['legacy_check']; }
            $pending = array();
            if ( $row['source_hash'] !== $target['source_hash'] || $row['environment_hash'] !== $environment ) { $pending[] = 'manual_changed'; }
            if ( $row['review_date'] && $row['review_date'] <= $today ) { $pending[] = 'manual_due'; }
            if ( in_array( $row['outcome'], array( 'not_tested', 'blocked', 'issue_found' ), true ) ) { $pending[] = 'manual_open'; }
            if ( $pending ) { ++$count; $reasons = array_merge( $reasons, $pending ); }
        }
        $legacy = self::legacy( $target['key'] );
        foreach ( $legacy as $check => $record ) {
            if ( in_array( $check, $followed_legacy, true ) ) { continue; }
            if ( ( $record['source_hash'] ?? '' ) !== $target['source_hash'] || ( $record['environment_hash'] ?? '' ) !== $environment || in_array( $record['state'] ?? '', array( 'not_started', 'needs_work' ), true ) ) {
                // Earlier notes are historical context only. A new session does not
                // silently claim to retest their unspecified state or environment.
                $reasons[] = 'manual_legacy'; ++$count;
            }
        }
        return array( 'count' => $count, 'reviews' => count( $rows ), 'reasons' => array_values( array_unique( $reasons ) ) );
    }

    public static function legacy( string $key ): array {
        $records = 'home' === $key ? get_option( 'bwa_home_manual', array() ) : get_post_meta( (int) $key, '_bwa_manual', true );
        return is_array( $records ) ? $records : array();
    }

    public static function sessions( WP_REST_Request $request ) {
        $target = self::target( (string) $request['target'] );
        if ( is_wp_error( $target ) ) { return $target; }
        if ( 'POST' === $request->get_method() ) { return self::save( $request, $target ); }
        global $wpdb;
        $page = max( 1, (int) $request->get_param( 'page' ) ); $review_page = max( 1, (int) $request->get_param( 'review_page' ) );
        $table = $wpdb->prefix . 'bwa_manual_sessions'; $environment = BWA_Audits::environment(); $today = wp_date( 'Y-m-d' );
        $review = $request->get_param( 'review_key' ) ?? '';
        if ( '' !== $review && ! self::uuid( $review ) ) { return self::error( __( 'Choose a valid review.', 'build-with-accessibility' ) ); }
        $cache_key = BWA_Cache::key( 'manual-history', array( $target['key'], $review, $page, $review_page ) );
        $raw = wp_cache_get( $cache_key, BWA_Cache::GROUP, false, $found );
        $read_error = false;
        if ( ! $found ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Paginate private manual history; bounded request cache for raw rows, with current permissions/context.
            $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE target_key=%s AND (%s='' OR review_key=%s)", $table, $target['key'], $review, $review ) );
            $read_error = $read_error || '' !== $wpdb->last_error;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Paginate private manual history; bounded request cache for raw rows, with current permissions/context.
            $review_total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT review_key) FROM %i WHERE target_key=%s AND (%s='' OR review_key=%s)", $table, $target['key'], $review, $review ) );
            $read_error = $read_error || '' !== $wpdb->last_error;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Paginate private manual history; bounded request cache for raw rows, with current permissions/context.
            $history = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE target_key=%s AND (%s='' OR review_key=%s) ORDER BY id DESC LIMIT 10 OFFSET %d", $table, $target['key'], $review, $review, ( $page - 1 ) * 10 ), ARRAY_A );
            $read_error = $read_error || '' !== $wpdb->last_error;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Paginate private manual history; bounded request cache for raw rows, with current permissions/context.
            $reviews = $wpdb->get_results( $wpdb->prepare( "SELECT s.* FROM %i s INNER JOIN (SELECT MAX(id) AS id FROM %i WHERE target_key=%s AND (%s='' OR review_key=%s) GROUP BY review_key) last ON s.id=last.id ORDER BY s.id DESC LIMIT 10 OFFSET %d", $table, $table, $target['key'], $review, $review, ( $review_page - 1 ) * 10 ), ARRAY_A );
            $read_error = $read_error || '' !== $wpdb->last_error;
            $raw = array( $total, $review_total, $history, $reviews );
            if ( ! $read_error && BWA_Cache::can_store( $raw ) ) { wp_cache_set( $cache_key, $raw, BWA_Cache::GROUP, MINUTE_IN_SECONDS ); }
        }
        list( $total, $review_total, $history, $reviews ) = $raw;
        if ( $read_error || ! is_array( $history ) || ! is_array( $reviews ) || $wpdb->last_error ) { return self::error( __( 'Manual history could not be read. Open the plugin admin page to finish any database upgrade, then retry. No reviews have been marked complete.', 'build-with-accessibility' ), 503 ); }
        $format = static fn( $row ) => self::decorate( $row, $target, $environment, $today );
        return array( 'target' => $target, 'environment_hash' => $environment, 'today' => $today, 'timezone' => wp_timezone_string(), 'guides' => self::guides(), 'items' => array_map( $format, $history ), 'total' => $total, 'page' => $page, 'pages' => max( 1, (int) ceil( $total / 10 ) ), 'reviews' => array_map( $format, $reviews ), 'review_total' => $review_total, 'review_page' => $review_page, 'review_pages' => max( 1, (int) ceil( $review_total / 10 ) ), 'tasks' => self::tasks( $target, $environment ), 'legacy' => self::legacy( $target['key'] ), 'limitation' => self::limitation() );
    }

    private static function save( WP_REST_Request $request, array $target ) {
        global $wpdb;
        if ( strlen( $request->get_body() ) > 131072 ) { return self::error( __( 'This session is too large. Shorten the notes and references.', 'build-with-accessibility' ), 413 ); }
        $value = $request->get_json_params(); $guides = self::guides();
        if ( ! is_array( $value ) || ! is_string( $value['guide'] ?? null ) || ! isset( $guides[ $value['guide'] ] ) || ! self::uuid( $value['review_key'] ?? null ) || ! self::uuid( $value['request_key'] ?? null ) || ! is_int( $value['previous_id'] ?? null ) || $value['previous_id'] < 0 ) { return self::error( __( 'Choose a valid guide and review session.', 'build-with-accessibility' ) ); }
        $guide = $guides[ $value['guide'] ]; $clean = array();
        if ( ( $value['guide_version'] ?? null ) !== $guide['version'] ) { return self::error( __( 'This testing guide changed. Refresh the guide before starting a new session.', 'build-with-accessibility' ), 409 ); }
        $legacy_check = $value['legacy_check'] ?? '';
        if ( ! is_string( $legacy_check ) || ( '' !== $legacy_check && ( $legacy_check !== $value['guide'] || ! isset( self::legacy( $target['key'] )[ $legacy_check ] ) ) ) ) { return self::error( __( 'Choose an existing earlier note for this guide.', 'build-with-accessibility' ) ); }
        foreach ( array( 'scope' => 300, 'browser' => 300, 'assistive_technology' => 300, 'notes' => 3000, 'references' => 2000 ) as $field => $limit ) {
            $clean[ $field ] = self::text( $value[ $field ] ?? '', $limit );
            if ( null === $clean[ $field ] ) { return self::error( __( 'Use plain text within the field limits.', 'build-with-accessibility' ) ); }
        }
        if ( '' === trim( $clean['scope'] ) ) { return self::error( __( 'Describe the page state or task you are reviewing.', 'build-with-accessibility' ) ); }
        $review_date = $value['review_date'] ?? '';
        if ( ! is_string( $review_date ) || ( '' !== $review_date && ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $review_date ) || ! checkdate( (int) substr( $review_date, 5, 2 ), (int) substr( $review_date, 8, 2 ), (int) substr( $review_date, 0, 4 ) ) ) ) ) { return self::error( __( 'Choose a valid review date.', 'build-with-accessibility' ) ); }
        if ( ! is_array( $value['steps'] ?? null ) || count( $value['steps'] ) !== count( $guide['steps'] ) ) { return self::error( __( 'Record an outcome for every guide step, including steps not tested.', 'build-with-accessibility' ) ); }
        $steps = array(); $states = array();
        foreach ( $guide['steps'] as $step ) {
            $answer = $value['steps'][ $step['id'] ] ?? null;
            $note = self::text( $answer['note'] ?? '', 2000 );
            if ( ! is_array( $answer ) || ! in_array( $answer['outcome'] ?? '', self::OUTCOMES, true ) || null === $note || ( 'not_tested' !== $answer['outcome'] && '' === trim( $note ) ) ) { return self::error( __( 'Choose each outcome and describe what you observed or why the step could not be tested.', 'build-with-accessibility' ) ); }
            $states[] = $answer['outcome']; $steps[] = array_merge( $step, array( 'outcome' => $answer['outcome'], 'note' => $note ) );
        }
        if ( array_diff( $states, array( 'not_tested' ) ) && ( '' === trim( $clean['browser'] ) || '' === trim( $clean['assistive_technology'] ) ) ) { return self::error( __( 'Record your browser/device and assistive technology. Enter None if none was used.', 'build-with-accessibility' ) ); }
        if ( array_diff( $states, array( 'not_tested' ) ) && true !== ( $value['confirmed'] ?? null ) ) { return self::error( __( 'Confirm that these results are your human observations in the recorded context.', 'build-with-accessibility' ) ); }
        $outcome = 'not_applicable';
        foreach ( array( 'issue_found', 'blocked', 'not_tested', 'no_issue_observed' ) as $candidate ) { if ( in_array( $candidate, $states, true ) ) { $outcome = $candidate; break; } }
        $table = $wpdb->prefix . 'bwa_manual_sessions';
        $request_hash = hash( 'sha256', wp_json_encode( array( $target['key'], get_current_user_id(), $value, $clean ) ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Append-only private evidence with live idempotency/concurrency reads; invalidate views after the guarded insert.
        $existing = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE request_key=%s', $table, $value['request_key'] ), ARRAY_A );
        $environment = BWA_Audits::environment();
        if ( $existing ) {
            if ( $existing['request_hash'] !== $request_hash ) { return self::error( __( 'This save identifier was already used for different evidence. Start a new save.', 'build-with-accessibility' ), 409 ); }
            return self::decorate( $existing, $target, $environment, wp_date( 'Y-m-d' ) );
        }
        if ( ( $value['source_hash'] ?? '' ) !== $target['source_hash'] || ( $value['environment_hash'] ?? '' ) !== $environment ) { return self::error( __( 'The page or tracked site settings changed during testing. Keep your notes, reload the current page, and repeat the affected tests before saving.', 'build-with-accessibility' ), 409 ); }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Append-only private evidence with live idempotency/concurrency reads; invalidate views after the guarded insert.
        $previous = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE review_key=%s ORDER BY id DESC LIMIT 1', $table, $value['review_key'] ), ARRAY_A );
        if ( ( $previous && ( (int) $previous['id'] !== $value['previous_id'] || $previous['target_key'] !== $target['key'] || $previous['guide'] !== $value['guide'] || json_decode( $previous['evidence'], true )['scope'] !== $clean['scope'] || ( json_decode( $previous['evidence'], true )['legacy_check'] ?? '' ) !== $legacy_check ) ) || ( ! $previous && 0 !== $value['previous_id'] ) ) { return self::error( __( 'A newer session exists or this review belongs to a different page or state. Refresh the review history before repeating it.', 'build-with-accessibility' ), 409 ); }
        $evidence = array_merge( $clean, array( 'legacy_check' => $legacy_check, 'guide' => $guide, 'steps' => $steps, 'tester' => wp_get_current_user()->display_name, 'target_title' => $target['title'], 'target_url' => 'home' === $target['key'] ? home_url( '/' ) : get_permalink( $target['id'] ), 'timezone' => wp_timezone_string(), 'limitation' => self::limitation() ) );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Append-only private evidence with live idempotency/concurrency reads; invalidate views after the guarded insert.
        $inserted = $wpdb->insert( $table, array( 'target_key' => $target['key'], 'review_key' => $value['review_key'], 'previous_id' => $value['previous_id'], 'request_key' => $value['request_key'], 'request_hash' => $request_hash, 'guide' => $value['guide'], 'legacy_check' => $legacy_check, 'outcome' => $outcome, 'source_hash' => $target['source_hash'], 'environment_hash' => $environment, 'review_date' => '' === $review_date ? null : $review_date, 'created_at' => current_time( 'mysql', true ), 'author' => get_current_user_id(), 'evidence' => wp_json_encode( $evidence ) ) );
        $insert_id = (int) $wpdb->insert_id;
        wp_cache_delete( BWA_Cache::epoch_key(), BWA_Cache::GROUP );
        if ( false === $inserted ) {
            // A unique previous-session link prevents concurrent reviewers from
            // replacing one another. Retry of the same request remains idempotent.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Append-only private evidence with live idempotency/concurrency reads; invalidate views after the guarded insert.
            $duplicate = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE request_key=%s', $table, $value['request_key'] ), ARRAY_A );
            if ( $duplicate && $duplicate['request_hash'] === $request_hash ) { return self::decorate( $duplicate, $target, $environment, wp_date( 'Y-m-d' ) ); }
            return self::error( __( 'The session could not be saved, or another reviewer saved first. Keep your notes and refresh before retrying.', 'build-with-accessibility' ), 409 );
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Append-only private evidence with live idempotency/concurrency reads; invalidate views after the guarded insert.
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id=%d', $table, $insert_id ), ARRAY_A );
        if ( ! is_array( $row ) ) { return self::error( __( 'The saved session could not be read. Retry the same save to recover it without creating a duplicate.', 'build-with-accessibility' ), 503 ); }
        return self::decorate( $row, $target, $environment, wp_date( 'Y-m-d' ) );
    }

    public static function export( WP_REST_Request $request ) {
        $target = self::target( (string) $request['target'] );
        if ( is_wp_error( $target ) ) { return $target; }
        global $wpdb;
        $table = $wpdb->prefix . 'bwa_manual_sessions';
        $read_error = false;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read a fixed export cutoff and current retained rows/counts directly; do not cache evidence completeness checks.
        $through = null === $request->get_param( 'through' ) ? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(MAX(id),0) FROM %i WHERE target_key=%s', $table, $target['key'] ) ) : max( 0, (int) $request->get_param( 'through' ) );
        $read_error = $read_error || '' !== $wpdb->last_error;
        $after = max( 0, (int) $request->get_param( 'after' ) ); $environment = BWA_Audits::environment(); $today = wp_date( 'Y-m-d' );
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read a fixed export cutoff and current retained rows/counts directly; do not cache evidence completeness checks.
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE target_key=%s AND id>%d AND id<=%d ORDER BY id ASC LIMIT 50', $table, $target['key'], $after, $through ), ARRAY_A );
        $read_error = $read_error || '' !== $wpdb->last_error;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Intentionally uncached: Read a fixed export cutoff and current retained rows/counts directly; do not cache evidence completeness checks.
        $total = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE target_key=%s AND id<=%d', $table, $target['key'], $through ) );
        $read_error = $read_error || '' !== $wpdb->last_error;
        if ( $read_error || ! is_array( $rows ) || $wpdb->last_error ) { return self::error( __( 'The complete manual history could not be read. Retry after the database is available; no partial export has been produced.', 'build-with-accessibility' ), 503 ); }
        $last = $rows ? (int) end( $rows )['id'] : $after;
        return array( 'schema' => 1, 'plugin_version' => BWA_VERSION, 'exported_at' => gmdate( 'c' ), 'target' => $target, 'environment_hash' => $environment, 'today' => $today, 'timezone' => wp_timezone_string(), 'through' => $through, 'total' => $total, 'next_after' => $last < $through && $rows ? $last : null, 'sessions' => array_map( static fn( $row ) => self::decorate( $row, $target, $environment, $today ), $rows ), 'legacy' => self::legacy( $target['key'] ), 'assessment' => array( 'conformance' => 'not_assessed', 'manual_testing_required' => true, 'limitation' => self::limitation() ) );
    }
}
