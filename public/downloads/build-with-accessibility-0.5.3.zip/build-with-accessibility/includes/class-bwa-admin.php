<?php
defined( 'ABSPATH' ) || exit;

final class BWA_Admin {
    public static function init(): void {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
    }

    public static function menu(): void {
        add_menu_page( __( 'Accessibility', 'build-with-accessibility' ), __( 'Accessibility', 'build-with-accessibility' ), 'manage_options', 'build-with-accessibility', array( __CLASS__, 'render' ), 'dashicons-universal-access-alt', 58 );
    }

    public static function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to open this workspace.', 'build-with-accessibility' ) );
        }
        echo '<div class="wrap" id="bwa-admin-root"><p>' . esc_html__( 'Loading your accessibility workspace…', 'build-with-accessibility' ) . '</p></div>';
    }

    public static function assets( string $hook ): void {
        if ( 'toplevel_page_build-with-accessibility' !== $hook || ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $asset = require BWA_DIR . '/assets/admin.asset.php';
        wp_enqueue_script( 'bwa-admin', plugins_url( 'assets/admin.js', BWA_FILE ), $asset['dependencies'], $asset['version'], true );
        wp_enqueue_style( 'bwa-admin', plugins_url( 'assets/admin.css', BWA_FILE ), array( 'wp-components' ), $asset['version'] );
        wp_add_inline_script( 'bwa-admin', 'window.bwaAdmin=' . wp_json_encode( array(
            'logo' => plugins_url( 'assets/brand-mark.svg', BWA_FILE ),
            'version' => BWA_VERSION, 'axeVersion' => BWA_AXE_VERSION,
            'siteName' => get_bloginfo( 'name' ), 'siteUrl' => home_url( '/' ),
            'userId' => get_current_user_id(),
        ) ) . ';', 'before' );
        wp_set_script_translations( 'bwa-admin', 'build-with-accessibility', BWA_DIR . '/languages' );
    }
}
