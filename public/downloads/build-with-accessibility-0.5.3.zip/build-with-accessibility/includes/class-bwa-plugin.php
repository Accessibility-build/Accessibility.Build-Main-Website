<?php
defined( 'ABSPATH' ) || exit;

final class BWA_Plugin {
    public static function init(): void {
        add_action( 'enqueue_block_editor_assets', array( __CLASS__, 'editor_assets' ) );
        add_action( 'rest_api_init', array( 'BWA_Repairs', 'routes' ) );
        add_action( 'rest_api_init', array( 'BWA_Content', 'routes' ) );
        foreach ( array( 'post', 'page' ) as $type ) {
            add_filter( 'rest_pre_insert_' . $type, array( 'BWA_Repairs', 'guard' ), 99, 2 );
            add_action( 'rest_after_insert_' . $type, array( 'BWA_Repairs', 'saved' ), 99, 2 );
        }
        add_action( 'template_redirect', array( __CLASS__, 'diagnostic' ), 0 );
        add_filter( 'plugin_action_links_' . plugin_basename( BWA_FILE ), array( __CLASS__, 'links' ) );
    }

    public static function links( array $links ): array {
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=build-with-accessibility' ) ) . '">' . esc_html__( 'Accessibility dashboard', 'build-with-accessibility' ) . '</a>' );
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'edit.php?post_type=page' ) ) . '">' . esc_html__( 'Open a page to repair images', 'build-with-accessibility' ) . '</a>' );
        return $links;
    }

    public static function editor_assets(): void {
        $screen = get_current_screen();
        if ( ! $screen || ! in_array( $screen->post_type, array( 'post', 'page' ), true ) || ! $screen->is_block_editor() ) {
            return;
        }
        $asset = require BWA_DIR . '/assets/editor.asset.php';
        wp_enqueue_script( 'bwa-editor', plugins_url( 'assets/editor.js', BWA_FILE ), $asset['dependencies'], $asset['version'], true );
        wp_enqueue_style( 'bwa-editor', plugins_url( 'assets/editor.css', BWA_FILE ), array( 'wp-components' ), $asset['version'] );
        $image_link = null;
        $image_hint = self::navigation_hint( 'bwa_image' );
        $source_hint = self::navigation_hint( 'bwa_source' );
        if ( preg_match( '/^\d+(\.\d+)*$/', $image_hint ) && preg_match( '/^[a-f0-9]{64}$/', $source_hint ) ) {
            $path = array_map( 'intval', explode( '.', $image_hint ) );
            if ( BWA_Images::valid_path( $path ) ) { $image_link = array( 'path' => $path, 'source_hash' => $source_hint ); }
        }
        // Gutenberg may normalize the URL before the plugin renders. Preserve
        // this read-only navigation hint; every eventual write is still guarded.
        wp_add_inline_script( 'bwa-editor', 'window.bwaSettings=' . wp_json_encode( array( 'version' => BWA_VERSION, 'logo' => plugins_url( 'assets/brand-mark.svg', BWA_FILE ), 'imageLink' => $image_link ) ) . ';', 'before' );
        wp_set_script_translations( 'bwa-editor', 'build-with-accessibility', BWA_DIR . '/languages' );
    }

    /** Read-only editor navigation; this hint never authorizes a content write. */
    private static function navigation_hint( string $key ): string {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Selects an editor element only; authenticated REST writes independently require a nonce, capability, and source precondition.
        if ( ! isset( $_GET[ $key ] ) || ! is_string( $_GET[ $key ] ) ) { return ''; }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only navigation, sanitized here and format-validated by the caller.
        return sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
    }

    /** Diagnostics run only on an explicitly requested, authenticated, short-lived preview. */
    public static function diagnostic(): void {
        if ( ! isset( $_GET['bwa_check'], $_GET['bwa_post'], $_GET['bwa_run'], $_GET['_bwa_nonce'] ) ) {
            return;
        }
        foreach ( array( 'bwa_check', 'bwa_post', 'bwa_run', '_bwa_nonce' ) as $key ) {
            if ( ! isset( $_GET[ $key ] ) || ! is_string( $_GET[ $key ] ) ) {
                return;
            }
        }
        $id = sanitize_text_field( wp_unslash( $_GET['bwa_check'] ) );
        $post_id = absint( $_GET['bwa_post'] );
        $token = sanitize_text_field( wp_unslash( $_GET['bwa_run'] ) );
        $nonce = sanitize_text_field( wp_unslash( $_GET['_bwa_nonce'] ) );
        if ( ! current_user_can( 'edit_post', $post_id ) || ! wp_verify_nonce( $nonce, 'bwa_check_' . $id ) || get_queried_object_id() !== $post_id ) {
            return;
        }
        $post = get_post( $post_id );
        $record = BWA_Repairs::get( $post_id, $id );
        $check = $record['check'] ?? null;
        if ( ! $record || 'saved' !== $record['state'] || ! $check || $check['expires'] < time() || $check['actor'] !== get_current_user_id() || ! hash_equals( $check['token'], $token ) || $check['source_hash'] !== BWA_Images::hash( $post->post_content ) ) {
            return;
        }
        if ( BWA_Compatibility::owner( $post_id ) || ( $check['context_hash'] ?? '' ) !== BWA_Compatibility::render_context( $post_id ) ) { return; }
        BWA_Compatibility::diagnostic();
        add_filter( 'the_content', static function ( $content ) use ( $post, $record, $token ) {
            if ( get_the_ID() !== $post->ID || BWA_Images::hash( $content ) !== BWA_Images::hash( $post->post_content ) ) {
                return $content;
            }
            return empty( $record['kind'] ) || 'image' === $record['kind'] ? BWA_Images::mark( $content, $record, $token ) : BWA_Content::mark( $content, $record, $token );
        }, 8 );
        add_action( 'wp_enqueue_scripts', static function () use ( $record, $token ) {
            if ( ! empty( $record['kind'] ) && 'image' !== $record['kind'] ) {
                wp_enqueue_script( 'bwa-axe', plugins_url( 'assets/vendor/axe.min.js', BWA_FILE ), array(), BWA_AXE_VERSION, true );
                wp_enqueue_script( 'bwa-content-recheck', plugins_url( 'assets/content-recheck.js', BWA_FILE ), array( 'bwa-axe', 'wp-i18n' ), BWA_VERSION, true );
                wp_add_inline_script( 'bwa-content-recheck', 'window.bwaContentCheck=' . wp_json_encode( array( 'token' => $token, 'target' => $record['target'] ) ) . ';', 'before' );
                wp_set_script_translations( 'bwa-content-recheck', 'build-with-accessibility', BWA_DIR . '/languages' );
                return;
            }
            wp_enqueue_script( 'bwa-recheck', plugins_url( 'assets/recheck.js', BWA_FILE ), array( 'wp-i18n' ), BWA_VERSION, true );
            wp_add_inline_script( 'bwa-recheck', 'window.bwaCheck=' . wp_json_encode( array( 'token' => $token, 'alt' => $record['alt'], 'purpose' => $record['purpose'] ) ) . ';', 'before' );
            wp_set_script_translations( 'bwa-recheck', 'build-with-accessibility', BWA_DIR . '/languages' );
        } );
    }
}
