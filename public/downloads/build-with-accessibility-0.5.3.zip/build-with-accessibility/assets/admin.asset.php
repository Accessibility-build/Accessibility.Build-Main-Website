<?php
return array( 'dependencies' => array( 'wp-api-fetch', 'wp-components', 'wp-element', 'wp-i18n', 'wp-a11y' ), 'version' => 'de3da8e97252' );
