<?php
return array( 'dependencies' => array( 'wp-api-fetch', 'wp-components', 'wp-element', 'wp-i18n', 'wp-a11y' ), 'version' => 'd314d2fd6794' );
